'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo principale
Questo è il modulo per accesso al sistema, contiene diverse funzioni, tra le più importanti ci sono quelle per
creare il DataFrame con i giorni di contesto per i modelli, la chiamata alla funziona per la creazioni delle medie mensili, lìavvio selettivo degli agenti.
'''


from config import carica_dataset,GIORNI_CONTESTO, OLLAMA_MODEL, USA_TMAX,USA_TMIN,USA_TABFINALE,USA_INTERPRETE,DATASET_PATH, DATA_INIZIO_PREVISIONE, PREVISIONI_GIORNI, MEDIE_FINALI_PATH,CONFRONTO_TMIN, CONFRONTO_TMAX,PREVISIONI_PATH, USA_REPORT_PREVISIONI, USA_REPORT_CONFRONTI,REAL_PATH
from confronti import confronta_previsioni
from agentimeteo import AgenteTmax, AgenteTmin, AgenteTabellaFinale, AgenteInterpreteLLM, AgenteReportPrevisioni, AgenteReportConfronti
from modelli import llm,descrizione_llm_attivo,llm_interprete
import datetime
import pandas as pd
import os

#controllo se esiste almeno un file con le previsioni
#questo è utile nei casi in cui voglio avviare il sistema senza agenti previsionali.
PREVISIONI_IN = os.path.isfile(PREVISIONI_PATH) 

#indica a terminale il nome del modello utilizzato
descrizione_llm_attivo()  




def esegui_per_dataset(df, mese_previsto, medie_finali_path, risultati_mae, real_path):
    #stampa a terminalre informazioni sul dataset, mostrando anche il range di date
    print(f"\n Elaborazione da dataset unico: {df['DATE'].min().strftime('%Y-%m-%d')} -> {df['DATE'].max().strftime('%Y-%m-%d')}")

    
    
    #costruzione del DataFrame con i giorni di contesto, il numero di giorni dipende dalla variabile GIORNI_CONTESTO,
    # vengono caricate soolo le colonne del dataset, necessarie per essere utilizzate dagli agenti
   
    ultimi = df.tail(GIORNI_CONTESTO)[[
        'DATE', 'TMIN °C', 'TMAX °C', 'TAVG °C',
        'NAO_INDEX',
        'TMIN TREND', 'TMIN SEASONALITY',
        'TMAX TREND', 'TMAX SEASONALITY',
        'TAVG TREND', 'TAVG SEASONALITY',
        'SEASON_NAME', 'WINDAVG km/h',
        'GUST km/h', 'VISIBILITY km',
        'HUMIDITY %', 'DEWPOINT °C',
        'PRESSURE mb','PHENOMENA'
    ]]
    tmin_ultimo = ultimi.iloc[-1]["TMIN °C"] #temperatura minima per ultimo giorno di contesto usata per il prompt dell' agente tmin
    tmax_ultimo = ultimi.iloc[-1]["TMAX °C"] #temperatura massima per ultimo giorno di contesto usata per il prompt dell' agente tmin
   
    #creazione riga con info di contesto per agente Tmax, viene passata al modello sotto forma di sequenza di stringhe solo con le info utili per l'agente tmax
    righe = [ 
        f"{row['DATE'].strftime('%Y-%m-%d')}, season={row['SEASON_NAME'].capitalize()}, Tmin={row['TMIN °C']}°C, Tmax={row['TMAX °C']}°C, Tavg={row['TAVG °C']}°C, NAO={row['NAO_INDEX']:.2f}, Trend Tmax={row['TMAX TREND']:.2f}, Season Tmax={row['TMAX SEASONALITY']:.2f}"
        f" WindAvg={row['WINDAVG km/h']}km/h, Gust={row['GUST km/h']}km/h, visibility={row['VISIBILITY km']}km, humidity={row['HUMIDITY %']}%, dewpoint={row['DEWPOINT °C']}°C, pressure={row['PRESSURE mb']}mb, phenomena={row['PHENOMENA']} "
        for _, row in ultimi.iterrows()
    ]  
    #riga con info di contesto per agente Tmin, viene passata al modello sotto forma di sequenza di stringhe solo con le info utili per l'agente tmin
    righe_min = [
        f"{row['DATE'].strftime('%Y-%m-%d')}, season={row['SEASON_NAME'].capitalize()}, Tmin={row['TMIN °C']}°C, Tmax={row['TMAX °C']}°C, Tavg={row['TAVG °C']}°C, NAO={row['NAO_INDEX']:.2f}, Trend Tmin={row['TMIN TREND']:.2f}, Season Tmin={row['TMIN SEASONALITY']:.2f}"
        f" WindAvg={row['WINDAVG km/h']}km/h, Gust={row['GUST km/h']}km/h, visibility={row['VISIBILITY km']}km, humidity={row['HUMIDITY %']}%, dewpoint={row['DEWPOINT °C']}°C, pressure={row['PRESSURE mb']}mb, phenomena={row['PHENOMENA']} "
        for _, row in ultimi.iterrows()
    ]
  #le due stringhe differiscono solo per trend e stagionalità è stata fatta questa separazione perchè il modello si bloccava
  #se venivano mandate troppe informazioni in un'unica stringa.

    #dati di contesto definitivi per singoli agenti, concatena le righe in blocchi testuali.
    dati_contesto = "\n".join(righe) 
    dati_contesto_min = "\n".join(righe_min)

    #crea la lista di date future da prevedere
    ultima_data = ultimi['DATE'].max() #questa data rappresenta l'ultimo giorno del dataframe, se non ci sono stati errori durante il processo
    # ultima_data coincide con DATA_INIZIO_PREVISIONE
    date_da_prevedere = [
        (ultima_data + datetime.timedelta(days=i)).strftime('%Y-%m-%d') #sommo ad ultima data un range di i giorni, sommo un timestamp ad un timedelta ed ottengo un timestamp
        for i in range(1, PREVISIONI_GIORNI + 1) # parto dal primo giorno successivo a ultima data e genero un numero di date pari a PREVISIONI_GIORNI
    ]   #se PREVISIONI_GIORNI=1 - il range risulta essere (1,8) e questo prodice esattamente 7 giorni da prevedere
        #partendo dal giorno dopo ultima_data




#****** SEZIONE AGENTI ******



# AGENTE TMAX

    #inizializzo variabile che memorizza il ristulato dell'agente.
    previsioni_tmax = None 
    # si entra nel blocco solo se la variabile USA_TMAX è True
    if USA_TMAX: 
        #istanzio la classe dell'agente Tmax 
        agente_max = AgenteTmax() 
        #considera ultima riga del dataframe e ricava il nome della stagione
        stagione_corrente = df.iloc[-1]['SEASON_NAME'].strip().lower() 
        #inizializzo variabile per contenere le medie mensili
        media_mese = None
        #se la variabile è valorizzata con il percorso del csv delle medie storiche 
        if MEDIE_FINALI_PATH:
            try:
                #lettura delle medie mensili dal file csv
                medie_df = pd.read_csv(medie_finali_path)
                #considera la prima riga in cui il risultato corrisponde al mese (TRUE/FALSE)
                media_mese = medie_df[medie_df["MESE"] == mese_previsto].iloc[0].to_dict() 
            except Exception as e: 
                # se non riesce stampa errore
                print(f" Errore nel caricamento medie da {medie_finali_path}: {e}")
                #invoco il metodo esegui dell'istanza agente_max passando i dati utili alla previsione
                # blocco di testo con i giorni di contesto, lista date future da prevedere, chiamata la modello, 
                # stagione, medie mensili e valore della tmax per l'ultimo giorno di contesto
        previsioni_tmax = agente_max.esegui(dati_contesto,date_da_prevedere,llm,stagione_corrente=stagione_corrente,media_mese=media_mese,tmax_ultimo=tmax_ultimo)
        
        #confronto tra temperature previste e reali se attivo da config
        # se previsioni_tmax è diverso da None
        if previsioni_tmax:
            #costruzione della stringa contenente l'intervallo di date da prevedere
            intervallo = f"{date_da_prevedere[0]}->{date_da_prevedere[-1]}" 
            if CONFRONTO_TMAX:# se il flag è True entro nel blocco
                #invoco la funzione confronta previsioni presente nel file confronti.py
                #passando tramite dict le previsioni per tmax, TMAX per indicare la variabile da confrontare e il
                #percorso del file csv che contiene le date realmente rilevate, o nel caso di questo progetto, simulate
                #da confrontare con quelle predette per lo stesso arco temporale. la funzione ritorna il valore mae
                mae = confronta_previsioni(dict(previsioni_tmax), "TMAX", real_path)
                #popola la lista risultati_mae che verrà utilizzata successivamente da esegui_per_dataset 
                risultati_mae.append({
                    "intervallo": intervallo,
                    "mese": mese_previsto,
                    "mae": mae
                })
            
# AGENTE TMIN

    #inizializzo variabile che memorizza il ristulato dell'agente.
    previsioni_tmin = None
    #entriamo in questo blocco solo se USA_TMIN è True 
    if USA_TMIN: 
        #istanzia la classe dell'agente
        agente_min = AgenteTmin() 
        #considera ultima riga del dataframe e ricava il nome della stagione
        stagione_corrente = df.iloc[-1]['SEASON_NAME'].strip().lower()
        #inizializzo variabile per contenere le medie mensili
        media_mese = None
        #se la variabile è valorizzata con il percorso del csv delle medie storiche
        if medie_finali_path: #lettura delle medie mensili 
            try:
                #legge il file csv
                medie_df = pd.read_csv(medie_finali_path)
                #considera la prima riga in cui il risultato corrisponde al mese (TRUE/FALSE)
                media_mese = medie_df[medie_df["MESE"] == mese_previsto].iloc[0].to_dict()
            except Exception as e:
                #se non riesce stampa un errore
                print(f" Errore nel caricamento medie da {medie_finali_path}: {e}")
                #invoco il metodo esegui dell'istanza agente_min passando i dati utili alla previsione
                # blocco di testo con i giorni di contesto, lista date future da prevedere, chiamata la modello, 
                # stagione, medie mensili e valore della tmin per l'ultimo giorno di contesto
        previsioni_tmin = agente_min.esegui(dati_contesto_min,date_da_prevedere,llm,stagione_corrente=stagione_corrente,tmin_ultimo=tmin_ultimo,media_mese=media_mese)
        

        #confronto tra temperature previste e reali se attivo da config
        # se previsioni_tmin è diverso da None
        #confronto tra temperature previste e reali se attivo da config
        if previsioni_tmin:
            #costruzione della stringa contenente l'intervallo di date da prevedere
            intervallo = f"{date_da_prevedere[0]}->{date_da_prevedere[-1]}"
            if CONFRONTO_TMIN: # il flag di confronto è attivo entro nel blocco
                #invoco la funzione confronta previsioni presente nel file confronti.py
                #passando tramite dict le previsioni per tmin, TMIN per indicare la variabile da confrontare e il
                #percorso del file csv che contiene le date realmente rilevate, o nel caso di questo progetto, simulate
                #da confrontare con quelle predette per lo stesso arco temporale. la funzione ritorna il valore mae
                mae = confronta_previsioni(dict(previsioni_tmin), "TMIN", real_path)
                #popola la lista risultati_mae che verrà utilizzata successivamente da esegui_per_dataset 
                risultati_mae.append({
                    "intervallo": intervallo,
                    "mese": mese_previsto,
                    "mae": mae
                })
            
            
    #AGENTE SINTESI PREVISIONI
    #entro nel blocco solo se tutti i flag sono True
    if USA_TABFINALE and USA_TMIN and USA_TMAX: 
        #istanzio oggetto della classe inviando il nome del modello, in questo caso l'agente non usa il modello
        #ma viene passato per poi essere aggiunto al log generato dall'agente.
        agente_tabella = AgenteTabellaFinale(modello=OLLAMA_MODEL)
        #chiamo il metodo principale dell'agente passando le date da prevedere e le previsioni generate da TMIN e TMAX
        agente_tabella.esegui(date_da_prevedere,previsioni_tmin,previsioni_tmax)

    

    # AGENTE REPORT PREVISIONI

    # se il flag per attivare/disattivare l'agente è True e se è presente un csv con le previsioni, entro nel blocco
    if USA_REPORT_PREVISIONI and PREVISIONI_IN: 
        try:
            #creo un'istanza per l'agente report previsioni
            AgenteReportPrevisioni().esegui()
            #l'agente chied all'utente se stampare un report pdf, se l'utente rifiuta il sistema cattura l'eccezione 
            #e con pass va avanti senza far terminare tutto il programma
        except SystemExit:
            pass  


    # AGENTE REPORT CONFRONTI
    # se il flag per attivare/disattivare l'agente è True e se è presente un csv con le previsioni, entro nel blocco
    if USA_REPORT_CONFRONTI and PREVISIONI_IN: 
        try:
            #creo un'itanza per l'agente report confronti
            AgenteReportConfronti().esegui()
            #l'agente chiede all'utente se stampare un report pdf, se l'utente rifiuta il sistema cattura l'eccezione 
            #e con pass va avanti senza far terminare tutto il programma
        except SystemExit:
            pass

    #AGENTE INTERPRETE

    # se il flag per attivare/disattivare l'agente è True e se è presente un csv con le previsioni, entro nel blocco
    if USA_INTERPRETE and PREVISIONI_IN: 
        #creo istanza agente interprete passando il percorso del file csv delle previsioni, e la funzione per invocare il modello
        agente_interprete = AgenteInterpreteLLM(path_csv_previsioni=PREVISIONI_PATH,llm_func=llm_interprete)
        #invoco l'interfaccia testuale dell'agente che attualmente è solo utilizzabile via terminale
        agente_interprete.interfaccia()

    

def main():

    
    #inizializza la lista che contiene i risultati mae
    risultati_mae = []

    # Caricamento dataset storico tramite la funzione carica_dataset in config e lo restituisce come un DataFrame pandas
    df = carica_dataset(DATASET_PATH)
    #converte la colonna DATE in datetime
    df['DATE'] = pd.to_datetime(df['DATE'])
    

    # Calcolo data inizio previsione
    #ricavo la data di inizio previsione, prima converto in datetime il contenuto della variabile DATA_INIZIO_PREVISIONE
    #poi con Timedelta aggiungo un giorno
    data_inizio = pd.to_datetime(DATA_INIZIO_PREVISIONE) + pd.Timedelta(days=1) #inizio previsioni
    #calcolo l'inizio della finestra temporale di contesto tramite il valore di GIORNI_CONTESTO
    #sottraggo alla data di inizio l'intervallo di date grande quanto GIORNI_CONTESTO
    inizio_finestra = data_inizio - pd.Timedelta(days=GIORNI_CONTESTO) 

    #estraggo tutte le righe  comprese tra data_inizio e data_fine
    df_finestra = df[(df["DATE"] >= inizio_finestra) & (df["DATE"] < data_inizio)].copy()

    #creo una lista con le date da prevedere, sommanda alla data iniziale i singoli giorni
    #il ciclo for è leggermente diverrso da quello usato nella parte iniziale del codice
    #non considera un range tra due estremi ma solo il valore relativo al numero di giorni da predire
    date_da_prevedere = [
        (data_inizio + pd.Timedelta(days=i)).strftime('%Y-%m-%d')
        for i in range(PREVISIONI_GIORNI)
    ]

  
    # Ricava il numero del mese 
    mese_previsto = data_inizio.month

    # creo un DataFrame più piccolo contenente le righe del dataset storico che corrispondono alle date da prevedere.
    df_reali = df[df["DATE"].isin(pd.to_datetime(date_da_prevedere))]

    #  controllo della presenza di dati reali ( o simulati) per il periodo selezionato se non ci sono i dati si ferma tutto 
    if df_reali.empty: #se non ci sono nel dataset righe corrispondenti a quella data, stampa un errore.
     print(f"ERRORE - Nessun dato reale nel dataset '{DATASET_PATH}' per le date {date_da_prevedere[0]} → {date_da_prevedere[-1]}.")
     return
      
    else:
    # Salvataggio del nuovo DataFrame per il confronto in un file CSV
     real_path = REAL_PATH
    df_reali.to_csv(real_path, index=False)

  

    # Calcolo medie mensili fino al giorno prima di inizio previsione utilizzando la funzione presente nel modulo delle medie
    from medie_mensili import genera_medie_mensili
    
    #alla funzione viene passato il percorso del dataset storico, la data di inizio previsione e il percorso in cui salvare le medie.
    genera_medie_mensili(percorso_input=DATASET_PATH, data_inizio_str=DATA_INIZIO_PREVISIONE,percorso_output=MEDIE_FINALI_PATH)

    # Questa funzione coordina gli agenti attivi passando i dati di contesto, il numero del mese,
    #il percorso delle medie, la lista in cui salvare i valori di accuratezza dei test e il percorso con il csv dei dati osservati/simulati
    #la funzione chima in sequenza gli agenti attivi, ad esempio : Agente Tmax -> Agente Timin -> Agente Sintesi
    esegui_per_dataset(df_finestra,mese_previsto,MEDIE_FINALI_PATH,risultati_mae,real_path)


    

#esegue il main visto che è lo script principale
if __name__ == "__main__":
    main()
