'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo Medie Mensili Storiche
Questo file genera le medie mensili storiche tenendo in considerazione tutti i mesi di tutti gli anni del dataset.
Il file calcola le medie fino al giorno prima dell'inizio della previsione scartando i giorni successivi.
Produce un file csv che verrà usato per rendere disponibili i valori delle medie all'interno del prompt tramite il modulo descrizioni.
'''

import pandas as pd


def genera_medie_mensili(percorso_input, data_inizio_str, percorso_output):
    # Creo un DataFrame a partire dal caricamento dataset storico
    df = pd.read_csv(percorso_input)
     #trasformo le date in datetime per manipolarle correttamente, se qualche valore non
     #è compatibile trasforma in NaN
    df["DATE"] = pd.to_datetime(df["DATE"], format="%Y-%m-%d", errors="coerce") 

    #Elimino le date NaN è solo un controllo di sicurezza, nel dataset dovrebbero essere tutte valorizzate
    df = df.dropna(subset=["DATE"]) 

  
    # considero le date fino al giorno DATA_INIZIO_PREVISIONE (file config.it) in questo modo 
    # non utilizzo per le medie le date che vanno oltre

    data_limite = pd.to_datetime(data_inizio_str)
    #controllo se le datae sono minori di data_limite
    df = df[df["DATE"] <= data_limite]

    if df.empty:
        print(" Nessun dato disponibile per il calcolo delle medie.")
        return

    #recupero anno e mesi dalla data
    df["ANNO"] = df["DATE"].dt.year
    df["MESE"] = df["DATE"].dt.month

    # Calcolo e salvataggio delle medie (usate al momento per le previsioni solo da TMAX e TMIN)
  
    #calcolo medie mensili per ogni anno
    medie = df.groupby(["ANNO", "MESE"])[["TAVG °C", "TMAX °C", "TMIN °C", "NAO_INDEX"]].mean().reset_index()

    #questa crea la media finale per ogni mese, ovvero prende la media per ogni mese calcolata precedentemente e ne fa la media per tutti gli anni
    #esempio prendo le medie annue di ogni gennaio e ne ricavo una media globale storica 
    medie_finali = medie.groupby("MESE")[["TAVG °C", "TMAX °C", "TMIN °C", "NAO_INDEX"]].mean().round(2).reset_index()

    #salvataggio del file csv
    medie_finali.to_csv(percorso_output, index=False)

   # stampo a terminale l'esito del processo
    ultima_data = df["DATE"].max().date()
    print("- Medie mensili calcolate fino al giorno:", ultima_data)
    print("- File generato:", percorso_output)


