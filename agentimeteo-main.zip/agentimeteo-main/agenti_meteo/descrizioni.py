'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo descrizioni
Il presente file contiene informazioni di supporto per gli agenti. 
Qui sono riportate una serie di descrizioni che arricchiscono i prompt fornendo informazioni di contesto al modello.
'''




#DESCRIZIONI STAGIONI, MESI, E MEDI PER TMAX E TMIN

#informazioni di base sulle temperature massime per ogni mese dell'anno. La funzione riceve una stringa con il mese che rappresenta la chiave del dict e restituisce il valore
#ovvero la descrizione
def descrizione_mese(mese: str) -> str: 
    descrizioni = {
        "January": "Gennaio le temperature massime sono basse.",
        "February": "Febbraio le temperature massime sono fredde.",
        "March": "Marzo le temperature massime sono miti.",
        "April": "Aprile le temperature massime sono miti.",
        "May": "Maggio le temperature massime sono alte.",
        "June": "Giugno le temperature massime sono calde.",
        "July": "Luglio le temperature massime sono molto elevate.",
        "August": "Agosto le temperature massime sono molto elevate.",
        "September": "Settembre le temperature massime sono miti.",
        "October": "Ottobre le temperature massime sono miti.",
        "November": "Novembre le temperature massime sono miti",
        "December": "Dicembre le temperature massime sono basse"
    }
    return descrizioni.get(mese, "") #restituisce il mese, se non trova corrispondenze non torna nulla ""



 #informazioni di base sulle temperature massime per ogni stagione dell'anno
def descrizione_stagione(stagione: str) -> str:
    stagione = stagione.strip().lower() 
    descrizioni = {
        "winter": "Ci troviamo in inverno. Le temperature massime tendono ad essere basse, con influenze importanti da irruzioni fredde e NAO negativa.",
        "spring": "Ci troviamo in primavera. Le temperature sono generalmente in crescita, ma possono subire sbalzi legati a instabilità atmosferica.",
        "summer": "Ci troviamo in estate. Le massime sono elevate e tendenzialmente stabili, salvo temporali o irruzioni fresche occasionali.",
        "autumn": "Ci troviamo in autunno. Le temperature massime tendono a calare gradualmente, spesso con fasi di instabilità e umidità."
    }
    return descrizioni.get(stagione, f"(Stagione sconosciuta: {stagione})")



#medie mensili annuali per temp massime
def descrizione_medie_climatologiche(media_mese: dict, mese: str) -> str: 
    if not media_mese:
        return ""

    tmax = media_mese.get("TMAX °C", "?")
    #tmin = media_mese.get("TMIN °C", "?")
    #tavg = media_mese.get("TAVG °C", "?")
    #nao = media_mese.get("NAO_INDEX", "?")

    return (
       
        f"Temperatura massima media (TMAX MEDIA) per questo mese: {tmax} °C\n"
        
    )




#informazioni sulle temperature minime per ogni stagione dell'anno
def descrizione_mese_tmin(mese: str) -> str: 
    descrizioni = {

        "January": "Gennaio le temperature minime sono basse.",
        "February": "Febbraio le temperature minime sono ancora basse.",
        "March": "Marzo le temperature minime sono moderate.",
        "April": "Aprile le temperature minime sono moderate.",
        "May": "Maggio le temperature minime sono moderatamente alte.",
        "June": "Giugno le temperature minime sono abbastanza alte.",
        "July": "Luglio le temperature minime sono elevate",
        "August": "Agosto le temperature minime sono molto elevate.",
        "September": "Settembre le temperature minime sono tipicamente miti.",
        "October": "Ottobre le temperature minime possono ancora essere miti.",
        "November": "Novembre le tempereature minime sono basse.",
        "December": "Dicembre le temperature minime basse."
    }
    return descrizioni.get(mese, "")



#informazioni sulle temperature minime per ogni stagione dell'anno
def descrizione_stagione_tmin(stagione: str) -> str: 
    stagione = stagione.strip().lower() 
    descrizioni = {
        "winter": "Ci troviamo in inverno. Le temperature minime tendono ad essere basse, con influenze importanti da irruzioni fredde.",
        "spring": "Ci troviamo in primavera. Le temperature minime sono generalmente in crescita, ma possono subire sbalzi legati a instabilità atmosferica.",
        "summer": "Ci troviamo in estate. Le temperature minime sono elevate e tendenzialmente stabili, salvo temporali o irruzioni fresche occasionali.",
        "autumn": "Ci troviamo in autunno. Le temperature minime tendono a calare gradualmente, spesso con fasi di instabilità e umidità."
    }
    return descrizioni.get(stagione, f"(Stagione sconosciuta: {stagione})")



#medie mensili annuali per temperature minime
def descrizione_medie_climatologiche_tmin(media_mese: dict, mese: str) -> str: 
    if not media_mese:
        return ""

    #tmax = media_mese.get("TMAX", "?")
    tmin = media_mese.get("TMIN °C", "?")
    #tavg = media_mese.get("TAVG", "?")
    #nao = media_mese.get("NAO_INDEX", "?")

    return (
       
        f"Tieni conto nella previsione che la temperatura minima media (TMIN MEDIA) per questo mese è di {tmin} °C\n"
        
    )


# INTERAZIONI TRA VARIABILI ATMOSFERICHE PER TMIN E TMAX


#breve spiegazione sui possibili effetti ed interazioni delle altre variabili climatologiche sulle temperature minime
def interazioni_tmin()->str: 
    interazioni="""
Per prevedere la temperatura minima (Tmin), considera queste variabili con i relativi valori di riferimento ed effetti.

Pressure (mb): alto > 1020, basso < 1005. Alta pressione favorisce cieli sereni e Tmin più basse; bassa pressione porta a nuvolosità e Tmin più alte.

Humidity (%): alto > 80, basso < 40. Umidità alta riduce il raffreddamento notturno e quindi Tmin è più alta; umidità bassa favorisce Tmin più basse.

DewPoint (°C): alto se >= Tmin - 1, basso se <= Tmin - 5. DewPoint vicino a Tmin indica aria umida e Tmin più alte; DewPoint distante indica aria secca e Tmin più basse.

NAO (indice): alto > +1, basso < -1. NAO positivo porta a condizioni miti e Tmin più alte; NAO negativo a Tmin più basse.

WindAvg & Gust (km/h): alto > 20, basso < 5. Vento forte riduce il raffreddamento notturno e quindi Tmin è più alta; vento debole favorisce Tmin più basse.

Visibility (km): alto > 10, basso < 2. Alta visibilità indica cieli sereni e Tmin più basse; bassa visibilità indica nebbia o nuvole e Tmin più alte.

Season: variabile stagionale che regola i valori medi di Tmin.

Trend Tmin (°C/giorno): indica la stabilità di Tmin nel tempo.

Tmax (°C): differenza Tmax - Tmin > 15 indica raffreddamento notturno intenso e Tmin più basse; differenza < 5 indica bassa escursione termica e Tmin più alte.

Il campo phenomena indica i fenomeni meteorologici presenti nel giorno di riferimento e può influenzare la temperatura minima (Tmin) come segue:

- none: assenza di fenomeni significativi; Tmin influenzata principalmente da altre variabili atmosferiche.

- rain (pioggia): presenza di pioggia tende a mantenere Tmin più alte rispetto a cieli sereni, perché le nubi e l'umidità limitano il raffreddamento notturno. Questo effetto è più marcato in autunno e inverno.

- thunderstorm (temporale) e rain thunderstorm (temporale con pioggia): simile alla pioggia, con possibile maggiore variabilità di Tmin dovuta a cambi repentini nelle condizioni atmosferiche.

- fog (nebbia): la nebbia generalmente indica elevata umidità e copertura nuvolosa bassa, riducendo la perdita di calore notturna e quindi aumentando Tmin. Questo fenomeno è frequente in autunno e inverno, soprattutto nelle ore notturne e mattutine.

- rain fog (pioggia e nebbia), rain thunderstorm fog (pioggia, temporale e nebbia): combinazione di effetti sopra, con Tmin generalmente più alte e maggiore umidità.

- snow (neve) e combinazioni con neve (rain snow, rain snow fog, rain snow thunderstorm, rain snow thunderstorm fog): la neve riflette la radiazione solare e durante la notte può mantenere Tmin basse se il cielo è sereno, ma se accompagnata da nuvolosità o fenomeni attivi può mitigare il calo termico. La neve è tipica dell'inverno.

- rain hail (pioggia e grandine): fenomeno raro, associato a temporali intensi, può causare variazioni brusche di Tmin.

In generale, i fenomeni con presenza di nuvolosità, umidità alta, e precipitazioni tendono a limitare il calo delle temperature minime durante la notte. La loro influenza è anche stagionale: in inverno e autunno gli effetti sono più marcati, mentre in estate la variabilità di Tmin è più influenzata da altri fattori come la radiazione solare e la ventilazione.

Quando il campo PHENOMENA è none, il modello deve basare la previsione di Tmin sulle altre variabili meteorologiche senza aggiustamenti specifici per fenomeni.

Usa queste informazioni in combinazione con le variabili meteorologiche per migliorare la previsione delle temperature minime.

Interazioni chiave da considerare:

- Alta pressione combinata con bassa umidità e DewPoint basso favorisce Tmin molto basse a causa di un raffreddamento notturno intenso.

- Alta pressione associata ad alta umidità o DewPoint elevato attenua l'effetto di raffreddamento, quindi Tmin risultano meno basse.

- Umidità e DewPoint insieme indicano la quantità di umidità nell'aria e la possibile formazione di nebbia o rugiada, influenzando Tmin.

- Vento forte e alta visibilità indicano mescolamento dell'aria e cieli sereni, associati a Tmin più alte; vento debole e bassa visibilità indicano stagnazione e Tmin più basse.

- L'indice NAO modula l'effetto stagionale: in inverno un NAO positivo tende a mantenere Tmin più alte rispetto a un NAO negativo.

- Una ampia escursione termica giornaliera (differenza Tmax - Tmin elevata) indica cieli sereni e Tmin più basse, mentre una escursione ridotta indica condizioni nuvolose e Tmin più alte.

- La presenza di fenomeni meteorologici descritti nel campo PHENOMENA, come pioggia, temporali, nebbia o neve, generalmente limita il raffreddamento notturno e porta a Tmin più alte rispetto a condizioni senza fenomeni (none).

- Fenomeni combinati (ad esempio pioggia con nebbia o neve) aumentano l'umidità e la copertura nuvolosa, accentuando l'effetto di mantenimento delle Tmin più alte.

- Condizioni senza fenomeni (none) richiedono maggiore attenzione alle variabili atmosferiche per stimare correttamente Tmin, perché l'assenza di nuvole o precipitazioni permette un raffreddamento più intenso.

- Cambiamenti simultanei e coerenti in pressione, umidità, vento, NAO e fenomeni atmosferici rafforzano e confermano l'effetto previsto su Tmin.

Per previsioni precise, considera sia i valori assoluti sia le dinamiche temporali (stabilità) di tutte queste variabili, inclusi i fenomeni.

"""
    return interazioni
      
   

 #breve spiegazione sui possibili effetti ed interazioni delle altre variabili climatologiche sulle temperature massime

def interazioni_tmax()->str:
    interazioni="""

Per prevedere la temperatura massima (Tmax), considera queste variabili con i relativi valori di riferimento, effetti e dinamiche temporali.

Pressure (mb): alto > 1020, basso < 1005. Alta pressione favorisce giornate soleggiate e Tmax più alte; bassa pressione porta a nuvolosità e Tmax più basse. Se la pressione è in aumento, Tmax tende ad aumentare; se in diminuzione, Tmax tende a diminuire.

Humidity (%): alto > 80, basso < 40. Umidità alta può ridurre l'irraggiamento solare diretto e quindi Tmax può essere più bassa; umidità bassa favorisce irraggiamento intenso e Tmax più alte. Se l'umidità è in aumento, Tmax tende a diminuire; se in diminuzione, Tmax tende ad aumentare.

DewPoint (°C): alto se vicino a Tmax, basso se distante. DewPoint alto indica aria umida che può limitare l'aumento termico diurno, quindi Tmax più bassa; DewPoint basso indica aria secca e maggiore escursione termica, Tmax più alte. Se il DewPoint è in aumento, Tmax tende a diminuire; se in diminuzione, Tmax tende ad aumentare.

NAO (indice): alto > +1, basso < -1. NAO positivo porta spesso a condizioni più calde e Tmax più alte; NAO negativo a Tmax più basse. Se NAO è in aumento, Tmax tende ad aumentare; se in diminuzione, Tmax tende a diminuire.

WindAvg & Gust (km/h): alto > 20, basso < 5. Venti forti possono ridurre l'accumulo di calore locale e quindi Tmax più basse; vento debole può favorire il riscaldamento e Tmax più alte. Se il vento è in aumento, Tmax tende a diminuire; se in diminuzione, Tmax tende ad aumentare.

Visibility (km): alto > 10, basso < 2. Alta visibilità indica assenza di foschie o nebbie, favorendo Tmax più alte; bassa visibilità indica condizioni di umidità e copertura, Tmax più basse. Se la visibilità è in aumento, Tmax tende ad aumentare; se in diminuzione, Tmax tende a diminuire.

Season: variabile stagionale che regola i valori medi di Tmax.

Trend Tmax (°C/giorno): positivo indica Tmax in aumento; negativo indica Tmax in diminuzione.

Tmin (°C): differenza Tmax - Tmin > 15 indica grande escursione termica e condizioni di riscaldamento intenso diurno; differenza < 5 indica escursione termica ridotta e Tmax più basse. Se l'escursione termica è in aumento, Tmax tende ad aumentare; se in diminuzione, Tmax tende a diminuire.


Il campo phenomena indica i fenomeni meteorologici presenti nel giorno di riferimento e può influenzare la temperatura massima (Tmax) come segue:

- none: assenza di fenomeni significativi; Tmax influenzata principalmente da altre variabili atmosferiche.

- rain (pioggia): presenza di pioggia tende a ridurre Tmax rispetto a giornate soleggiate, perché nuvole e precipitazioni limitano il riscaldamento diurno. Effetto più marcato in primavera, autunno e inverno.

- thunderstorm (temporale) e rain thunderstorm (temporale con pioggia): simile alla pioggia, con variabilità maggiore di Tmax dovuta a cambi repentini nelle condizioni atmosferiche.

- fog (nebbia): la nebbia al mattino può ritardare il riscaldamento, portando a Tmax più basse. Fenomeno frequente in autunno e inverno.

- rain fog (pioggia e nebbia), rain thunderstorm fog (pioggia, temporale e nebbia): combinazione di effetti sopra, con Tmax generalmente più basse.

- snow (neve) e combinazioni con neve: la neve riduce fortemente l'irraggiamento solare diretto riflettendolo, portando a Tmax più basse, tipico dell'inverno.

- rain hail (pioggia e grandine): fenomeno raro, associato a temporali intensi, può causare fluttuazioni di Tmax.

In generale, i fenomeni con nuvolosità, precipitazioni e alta umidità tendono a ridurre il riscaldamento diurno e quindi Tmax più basse. L'effetto è stagionale: in estate l'influenza può essere minore, in inverno e autunno più marcata.

Quando il campo PHENOMENA è none, il modello deve basare la previsione di Tmax sulle altre variabili meteorologiche senza aggiustamenti specifici per fenomeni.

Usa queste informazioni in combinazione con le variabili meteorologiche per migliorare la previsione delle temperature massime.


Interazioni chiave da considerare:

- Alta pressione combinata con bassa umidita' e DewPoint basso favorisce Tmax più alte a causa di giornate soleggiate e asciutte.
- Alta pressione associata ad alta umidita' o DewPoint elevato può attenuare l'aumento termico diurno, portando a Tmax meno alte.
- Umidita' e DewPoint insieme indicano la quantita' di umidita' nell'aria e la possibile formazione di nebbia o nuvole basse, influenzando Tmax.
- Vento forte e alta visibilita' indicano condizioni di dispersione dell'aria, spesso associati a Tmax più basse; vento debole e bassa visibilita' possono favorire accumulo di calore locale e Tmax più alte.
- L'indice NAO modula l'effetto stagionale: in estate un NAO positivo tende a mantenere Tmax più alte rispetto a un NAO negativo.
- Una ampia escursione termica giornaliera (differenza Tmax - Tmin elevata) indica condizioni di riscaldamento intenso e Tmax più alte, mentre una escursione ridotta indica condizioni più moderate e Tmax più basse.
- La presenza di fenomeni meteorologici descritti nel campo PHENOMENA, come pioggia, temporali, nebbia o neve, generalmente limita il riscaldamento diurno e porta a Tmax più basse rispetto a condizioni senza fenomeni (none).
- Fenomeni combinati (ad esempio pioggia con nebbia o neve) aumentano l'umidita' e la copertura nuvolosa, accentuando l'effetto di riduzione delle Tmax.
- Condizioni senza fenomeni (none) richiedono maggiore attenzione alle variabili atmosferiche per stimare correttamente Tmax, perché l'assenza di nuvole o precipitazioni permette un riscaldamento più intenso.
- Cambiamenti simultanei e coerenti in pressione, umidita', vento, NAO e fenomeni atmosferici rafforzano e confermano l'effetto previsto su Tmax.

Per previsioni precise, considera sia i valori assoluti sia le dinamiche temporali (aumento, diminuzione o stabilita') di tutte queste variabili, inclusi i fenomeni.

"""
    return interazioni
      
      
    
