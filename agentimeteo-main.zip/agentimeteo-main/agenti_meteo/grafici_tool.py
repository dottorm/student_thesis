'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo per la creazione di grafici
Questo modulo è utilizzato dall'agente interprete per generare grafici relativi alle previsioni.
I grafici generati possono essere salvati in un file a piacere dell'utente.
Questo modulo rappresenta una prima versione, e deve essere perfezionato.
'''
import matplotlib.pyplot as plt
import os
from datetime import datetime

#stampa e se richiesto salva un grafico basato sulle previsioni
def mostra_grafico_previsioni(tabella, tipo="TMIN_TMAX", sorgente="previsioni", salva=False):
    #attualmente viene passato come sorgente solo il parametro previsioni
    #questo fa si che vengano generati grafici solo sulle previsioni attuali e non sui dati storici, anche se il blocco sotto ne prevede la possibilità
    #funzione da integrare e sistemare nell'interprete
 
    # cancella i grafici precedentemente richiesti, questo risolve il problema della generazione di più grafici nella stessa run dell'interprete
    plt.clf() # elimina tutti gli elementi del grafico lasciando la finestra vuota
    plt.cla() #cancella gli assi della figura
    plt.close() #chiude la finestra e svuota la memoria

    # estrazione dei dati previsionali
    if sorgente == "previsioni": #in questo caso estraggo le info solo dalle previsioni
      #creo una lista di oggetti contenenti la data ed il valore delle previsioni esempio 2015-01-01, 10.5, 15.0, 24.0
        date = [datetime.strptime(row[0], "%Y-%m-%d") for row in tabella]
        tmin = [row[2] for row in tabella]
        tmax = [row[3] for row in tabella]
        tavg = [row[4] for row in tabella]
    elif sorgente == "storico": #grafico sui dati di contesto storico ( non implementato attualmente nell'interprete)
       #creo un dataframe a partire da tabelle ed ordino le date recuperando i valori delle temperature
        df = tabella
        df = df.sort_values("DATE")
        date = df["DATE"]
        tmin = df["TMIN °C"]
        tmax = df["TMAX °C"]
        tavg = df["TAVG °C"]
    else:
        print("[ERRORE] Sorgente non riconosciuta.")
        return


#creazione di una nuova figura, che rappresenza la base del grafico, le dimensioni sono espressi in pollici
    plt.figure(figsize=(10, 5))
    
    #disegna la parte di grafico relativo alla temperatura richiesta aggiungendo un punto circolare su ogni valore
    if tipo == "TMIN":
        plt.plot(date, tmin, label="Temperature Minime", marker="o")
    elif tipo == "TMAX":
        plt.plot(date, tmax, label="Temperature Massime", marker="o")
    elif tipo == "TAVG":
        plt.plot(date, tavg, label="Temperature Medie", marker="o")
    elif tipo == "TMIN_TMAX":
        plt.plot(date, tmin, label="Minime", marker="o")
        plt.plot(date, tmax, label="Massime", marker="o")
        plt.plot(date, tavg, label="Medie", marker="o")
    else:
        print("[ERRORE] Tipo grafico non riconosciuto.")
        return

#Creazione del grafico e stampa in finestra pop-up ( no terminale)

    plt.title("Andamento Temperature" + (" (storico)" if sorgente == "storico" else " (previsioni)"))#stampa titolo corrispondente alla richiesta
    plt.xlabel("Data") #label per l'asse delle ascisse
    plt.ylabel("Temperatura (°C)") #label per asse delle temperature 
    plt.xticks(rotation=45) #label ruotate di 45°
    plt.grid(True) #mostra una griglia nel grafico
    plt.legend() #inserisce una legende vicino le curve delle temperature
    plt.tight_layout() #sistema spazi tra elementi inseriti 

    if salva: #possibilità di salvare se utente lo richiede
        os.makedirs("grafici", exist_ok=True) #crea la cartella grafici se non esiste
        nome_file = f"grafici/andamento_{tipo.lower()}_{sorgente}.png" #selezione del nome con estensione png
        plt.savefig(nome_file) #salva il grafico

    plt.show() #mostra il grafico nella finestra mobile.
