'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologichee tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo Agenti
Il modulo degli Agenti contiene la logica relativa ad ogni agente, ed i prompt per gli Agenti Tmin, Tmax ed interprete.
'''


from descrizioni import descrizione_mese, descrizione_stagione,descrizione_medie_climatologiche, descrizione_mese_tmin, descrizione_stagione_tmin,descrizione_medie_climatologiche_tmin,interazioni_tmin, interazioni_tmax
from export_csv import salva_tabella_finale_csv  # importa la funzione di salvataggio
from datetime import datetime, timedelta
import re
from config import carica_dataset,REPORTS_ROOT,GIORNI_CONTESTO,PREVISIONI_GIORNI,VERBOSE_TMIN, VERBOSE_TMAX,VISTA_TABFINALE,VISTA_PREDIZIONE_TMIN, VISTA_PREDIZIONE_TMAX,VERBOSE_INTERPRETE,CITY,GIORNI_STORICO_INTERPRETE,DATASET_PATH, USA_TMIN, USA_TMAX,PROGRESSO_TERMINALE, PROGRESSO_STIMA_SECONDI,USA_INTERPRETE,GLOSSARIO_INTERPRETE
import pandas as pd
import time
import threading, sys
import os


#----------------- Classe Base Agenti----------#

#inizializzazione variabili per il tracciamento dei tempi di esecuzione delle previsioni
TMIN_SECONDI = None #durata previsione tmin
TMAX_SECONDI = None #durata previsione tmax
TMIN_inizio_ts = None #data avvio ultima previsione tmin
TMIN_FINE   = None #data fine ultima previsione  tmin
TMAX_inizio_ts = None #data avvio ultima previsione tmax
TMAX_FINE   = None #data fine ultima previsione tmax


#definizion della classe base per i soli agenti previsionalie
class AgenteBase:
    #costruttore con nome, descrizione e parametro verbose, questo parametro gestibile dal modulo configurazione,
    #quando è impostato su True abilita la visualizzazione a terminale del prompt degli agenti. 
    #
    def __init__(self, nome, verbose=False, descrizione: str = ""):
        self.nome = nome
        self.verbose = verbose  # abilita visualizzazione prompt intero per i singoli agenti
        self.descrizione = descrizione #descrizione del ruolo degli agenti (solo a fini informativi)

    def info(self):
        # da chiamare solo se si vuole mostrare la descrizione e il nome
        print(f" {self.nome} — {self.descrizione}")

    def costruisci_prompt(self): #metodo astratto per costruire il prompt ereditato e poi modificato dai singoli agenti
     raise NotImplementedError #forza le classi a ridefiniro il metodo

    # crea una lista di date ordinate tra due estremi  per essere sicuro che non ci siano giorni mancanti nella previsione
    #è applicata all'intervallo di date da prevedere
    def genera_date_consecutive(self, data_inizio_ts_str, data_fine_str):
        #converto  le due stringhe in oggetti datatime
        data_inizio_ts = datetime.strptime(data_inizio_ts_str, "%Y-%m-%d")
        data_fine = datetime.strptime(data_fine_str, "%Y-%m-%d")
        #calcolo i giorni nell'intervallo
        giorni = (data_fine - data_inizio_ts).days + 1
        #ritorna lista di stringhe
        return [(data_inizio_ts + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(giorni)]

    # metodo principlae, riceve i dati di contest, le date da prevedere, il modello e albri paramentri opzionali
    def esegui(self, dati, date_da_prevedere, llm_func, stagione_corrente=None,media_mese=None, tmax_ultimo=None, tmin_ultimo=None):

                   
        #se la lista di date da prevedere è vuota blocca il programma.
        if not date_da_prevedere:
            raise ValueError("La lista date_da_prevedere non può essere vuota.")

        # Rigenero la lista date per essere sicuro che sia ordinata e consecutiva
        date_da_prevedere = self.genera_date_consecutive(date_da_prevedere[0], date_da_prevedere[-1])

        #costruzione del prompt qui viene richiamata l'implementazione specifica dell'agente che modificherà quella dell'agente base
        prompt = self.costruisci_prompt(dati, date_da_prevedere,stagione_corrente, media_mese,tmax_ultimo, tmin_ultimo)
        
        #stampa a terminale l'intervallo temporale delle previsioni
        print(f"{self.nome}: previsione per i giorni {date_da_prevedere[0]} → {date_da_prevedere[-1]}")

        # Mostra il prompt se i flag verbose sono attivi da config (possibilità di inserire anche per Interprete ma attualmente non attivo)
        if (
            (self.nome == "Agente Tmin" and VERBOSE_TMIN) or
            (self.nome == "Agente Tmax" and VERBOSE_TMAX) 
        ):
            print(f"{'-'*60}\n{prompt}\n{'='*60}")

        # SEZIONE CALCOLO DURATA DELLA PREVISIONE

        #determino se tracciare i tempi di esecuzione, è subordinata ai due flag 
        timer_attivo = (
            (self.nome == "Agente Tmin" and USA_TMIN) or
            (self.nome == "Agente Tmax" and USA_TMAX)
        )
      
        #registrazione delle date di inizio_ts previsione
       
        #registra il timestamp di inizio previsione
        inizio_ts: float = time.time()        
        nome_minuscolo: str  = self.nome.lower() 
        
        #aggiorna le variabili globali per l'inzio del contatore per ogni agente
        if "tmin" in nome_minuscolo:
           globals()["TMIN_inizio_ts"] = inizio_ts
        elif "tmax" in nome_minuscolo:
           globals()["TMAX_inizio_ts"] = inizio_ts


        # BARRE DI PROGRESSO NEL TERMINALE dipende dalla variabile timer_attivo e da PROGRESSO_TERMINALE in config
        progress_attivo = PROGRESSO_TERMINALE and timer_attivo and (
            self.nome in ("Agente Tmin", "Agente Tmax")
        )

        risposta_box = {} # dizionario per contenere la risposta del modello
        errore_box = {} # dizionario per contenere un eventuale errore
 
        #chiamata al modello
        def _run_llm():
            try:
                #salva l'output del modello nel dizionario
                risposta_box["val"] = llm_func(prompt)
            except Exception as e:
                #se non riesce solleva un errore
                errore_box["err"] = e
        #crea un nuovo thread che lavora in parallelo con il programma principale
        #in questo modo posso eseguire più operazioni contemporaneamente
        #target indica quale funzione eseguire dentro il thread
        #il thread è secondario e viene eseguito in background, daemon=True, quando cessa il programma cessa anceh il thread
        th = threading.Thread(target=_run_llm, daemon=True)
        th.start() #avvio reale del Thread
        
        #se attiva visualizza a terminale la barra di avanzamento
        if progress_attivo: #avanzamento barra progresso (percentuale)
            print("   Previsione in corso…")
            sys.stdout.flush()

            len_utlima_riga = 0 #tiene traccia della lunghezza dell'ultima riga stampata
            # Avanza fino al 99% e la sua velocità dipende da PROGRESSO_STIMA_SECONDI, poi aspetta fino alla reale fine della previsione
            while th.is_alive(): #finchè il thread è attivo
                #calcola tempo trascorso tra il timestamp attuale e l'inizio, se non riesce pone il valore a 0.0
                t_trascorso = time.time() - inizio_ts if inizio_ts  else 0.0
                fine_ts = time.time()  

                #aggiornamento dei timer globali con i valori rilevati
                if self.nome == "Agente Tmin":
                    globals()["TMIN_SECONDI"] = t_trascorso
                    globals()["TMIN_FINE"] = fine_ts
                elif self.nome == "Agente Tmax":
                    globals()["TMAX_SECONDI"] = t_trascorso
                    globals()["TMAX_FINE"] = fine_ts
                    

                if PROGRESSO_STIMA_SECONDI <= 0:
                    #se il valore è negatovo forzo l'avanzamento al 99%
                    pct = 99
                else:
                    #stima una percentuale di avanzamento in base alla variabile PROGRESSO_STIMA_SECONDI e al tempo trascorso
                    #min limita il valore a 99
                    pct = min(99, int((t_trascorso / PROGRESSO_STIMA_SECONDI) * 100))

                line = f"\r   Avanzamento: {pct:3d}%" #stampa avanzamento
                pad = max(0, len_utlima_riga - len(line)) #calcolo spazi aggiuntivi nella stampa ad esempio 100% e 5% elimina lo spazio dedicato ai due 00
                sys.stdout.write(line + (" " * pad)) #stampa dell'avanzamente
                sys.stdout.flush() #aggiornamento dell'output
                len_utlima_riga = len(line) #variabile che tiene traccia della lunghezza dell'ultima riga
                time.sleep(0.1) # pausa tra gli aggiornamenti della barra

            # stampa a terminale del complteamento della previsione
            sys.stdout.write("\r   Avanzamento: 100%\n")
            sys.stdout.flush() #mostra subito la riga
            
            #se progresso_attivo è False non stampa l'avanzamento a terminale
        else:
            #blocco il thread principale, aspetto la fine della previsione
            th.join()
            fine_ts = time.time() #fine previsione
            t_trascorso = fine_ts - inizio_ts #calcolo tempo impiegato

            #aggiorno le variabili globali
            if "tmin" in nome_minuscolo:
              globals()["TMIN_FINE"] = fine_ts
              globals()["TMIN_SECONDI"] = t_trascorso
            elif "tmax" in nome_minuscolo:
              globals()["TMAX_FINE"] = fine_ts
              globals()["TMAX_SECONDI"] = t_trascorso



        # Se c'è stato un errore nel thread _run_llm ferma l'esecuzione
        if "err" in errore_box:
            raise errore_box["err"]
        
        #recupera risposta del modello oppure una stringa vuota se non esiste
        risposta = risposta_box.get("val", "")

        # chiamata parsing_risposta per dare una leggibilità migliore dei risultati
        previsioni = self.parse_risposta(risposta, date_da_prevedere)

        # se i flag sono attivi, viene stampata alla fine della previsione una tabella riassuntiva
        mostra_tabella = (
            (self.nome == "Agente Tmin" and VISTA_PREDIZIONE_TMIN) or
            (self.nome == "Agente Tmax" and VISTA_PREDIZIONE_TMAX)
        )
        #tabella riassuntiva previsione
        if mostra_tabella:
            print(f"\nTabella previsioni da {self.nome}:")
            print(f"{'Data':<12} | {'Temperatura (°C)':>17}")# stampa con allineamento 12 caratteri sx 17 dx
            print("-" * 32)
            #scorro lista d=data v=valore
            for d, v in previsioni:
                print(f"{d:<12} | {v:17.1f}")

        # mostra il tempo impiegato per le previsioni dei singoli agenti
        #controlla se il timer è attivo e se c'è un inizio valido

        if timer_attivo and inizio_ts is not None:
            #tempo totale di previsione
            t_trascorso = time.time() - inizio_ts
            #ottengo il numero di minuti trascorsi con la divisione intera
            mins = int(t_trascorso // 60)
            #calcolo i secondi
            secs = t_trascorso % 60
            #stampo i risultati in base alle seguenti condizioni
            if mins > 0:
                print(f" {self.nome} ha impiegato {mins} min {secs:.2f} s per completare la previsione.")
            else:
                print(f" {self.nome} ha impiegato {secs:.2f} s per completare la previsione.")

            #aggiorna le variabili globali
            if self.nome == "Agente Tmin":
                globals()["TMIN_SECONDI"] = t_trascorso
            elif self.nome == "Agente Tmax":
                globals()["TMAX_SECONDI"] = t_trascorso

        return previsioni
    
    
    
    #parsing della risposta
    def parse_risposta(self, risposta, date_da_prevedere):
      #divide la risposta in righe, rimuove gli spazi vuoti da ogni riga e da inizio e fine di tutto il testo
      lines = [line.strip() for line in risposta.strip().splitlines()]
      #inizializza una lista vuota
      previsioni = []
      #conta il numero di previsioni 
      target = len(date_da_prevedere)

      #scorre ogni riga della risposta del modello
      for line in lines:
        #se il numero di elementi è maggiore uguale al  target, ovvero ci sono le previsioni necessarie, si ferma
        if len(previsioni) >= target:
            break  # blocco appena raggiunto numero di giorni da prevedere anche se il modello continua a generare
        #altrimenti continua saltando le righe vuote
        if not line: 
            continue  # ignora riga vuota senza stampare
        # estrai l'ultimo numero nella riga
        try:
            # il blocco sostituisce le virgole con i punti e tramite espressione regolare estrae i numeri, sia positivi che negativi
            #creando una lista di stringhe
            matches = re.findall(r"[-+]?\d+(?:\.\d+)?", line.replace(",", "."))
            #se nella riga c'è almento un numero
            if matches:
                #converto in float l'ultimo numero
                valore = float(matches[-1])
                #associo il valore alla prossima data disponibile
                previsioni.append((date_da_prevedere[len(previsioni)], valore))
            else:
                # nessun numero
                continue
        except Exception:
            # qualsiasi errore di parsing
            continue
      # controllo se il modello ha stampato meno giorni di previsioni rispetto a quelli che ci aspettavamo
      #se è così stampa un avviso.
      if len(previsioni) < target:
        mancanti = target - len(previsioni)
        print(f" Mancano {mancanti} previsioni rispetto alle date.")

      return previsioni
 
    

    






#---- -------------- Agente TMIN --------------------- #

#definizione classe Agente Tmin
class AgenteTmin(AgenteBase):
    def __init__(self): #costruttore
        #chiama il costruttore con nome, flag VERBOSE e descrizione
        super().__init__('Agente Tmin',
                verbose=VERBOSE_TMIN,
                descrizione="Prevede le temperature minime per i prossimi giorni usando storico e indici meteo.Usa la capacità di ragionamento del modello")
    #definizione del metodo per costruire il prompt, passando i dati di contesto, lista di date da prevedere, stagione
    #alcuni parametri sono opzionali
    def costruisci_prompt(self, dati_contesto, date_da_prevedere, stagione_corrente, media_mese=None, tmax_ultimo=None, tmin_ultimo=None):
      
        #date da prevedere (intervallo)
        inizio_ts = date_da_prevedere[0] #prima data
        fine = date_da_prevedere[-1] #ultima data
        mese_previsto = datetime.strptime(inizio_ts, "%Y-%m-%d").strftime('%B')

        #blocco per arricchire il prompt, derivato dal file descrizioni.py
        #il blocco richiama le singole funzioni, passando la stagione, il mese previsto e la media_mese
        blocco_descrizione_tmin = ( 
            descrizione_stagione_tmin(stagione_corrente) + "\n" +
            descrizione_mese_tmin(mese_previsto) + "\n" +
            descrizione_medie_climatologiche_tmin(media_mese, mese_previsto)
        )

        

      #costruzione del prompt tramite parti statiche ed altre variabili

        return f"""Sei un esperto meteorologo. 

Prevedi le **temperature minime** per i {PREVISIONI_GIORNI} giorni successivi, dal {inizio_ts} al {fine}.

******* ANALIZZA E USA I SEGUENTI DATI STORICI ********

Storia delle temperature e variabili meteorologiche degli ultimi {GIORNI_CONTESTO} giorni:

{dati_contesto}

Ogni riga rappresenta un giorno e contiene i seguenti campi osservati e derivati:

- season: stagione meteorologica del giorno (Winter, Spring, Summer, Autumn), utile per comprendere il contesto climatico generale.
- Tmin: temperatura minima giornaliera osservata.
- Tmax: temperatura massima giornaliera osservata.
- Tavg: temperatura media giornaliera osservata, media tra Tmin e Tmax.
- NAO: indice di oscillazione nord atlantica. Valori positivi indicano afflussi di aria più temperata, valori negativi condizioni più fredde.
- Trend Tmin: tendenza storica di lungo periodo della Tmin, utile per stimare variazioni stagionali.
- Season Tmin: componente stagionale della Tmin, utile per riconoscere cicli ricorrenti.
- WindAvg: velocità media del vento (in km/h). Un vento costante può raffreddare o riscaldare l'ambiente, a seconda della direzione.
- Gust: raffica massima di vento registrata. Utile solo in condizioni di eventi estremi, ma può segnalare variazioni locali intense.
- Visibility: visibilità media (in km). Valori bassi indicano foschia o nebbia, che possono influenzare la temperatura massima, soprattutto in inverno.
- Humidity: umidità relativa media della giornata (in %). Alti valori di umidità ostacolano la dispersione del calore.
- DewPoint: punto di rugiada (in °C), cioè la temperatura alla quale l'umidità condensa. Valori elevati indicano aria satura, spesso associata a massime elevate in estate.
- Pressure: pressione atmosferica media (in millibar). Pressioni alte sono associate a stabilità e riscaldamento, pressioni basse a instabilità e raffreddamento.



************ USA QUESTE INFORMAZIONI COME CONOSCENZA DI BASE PER LE PREVISIONI **************
{interazioni_tmin()}



******* ANALIZZA E USA LE SEGUENTI INFORMAZIONI AGGIUNTIVE ********

{blocco_descrizione_tmin}


***** ISTRUZIONI PER LA PREVISIONE *********

Per il primo giorno di previsione, la temperatura minima dovrebbe essere intorno a {tmin_ultimo}°C, con una possibile variazione di circa un grado in più o in meno
Analizza sempre le interazioni tra i valori di pressure, humidity, DewPoint, NAO, WindAvg, Gust, visibility, Season Tmin, Trend Tmin, Tmin per prevedere la Temperatura minima.
Considera le tendenze recenti e le condizioni meteorologiche correlate
Le previsioni devono essere realistiche, coerenti e includere una stima della variabilità possibile.
Sulla base di tutti i dati che hai ricevuto, prevedi le temperature minime solo per i prossimi {PREVISIONI_GIORNI} giorni.
Fornisci un valore ragionevole per ogni giorno, indicando la temperatura minima .
Le temperature previste per i prossimi giorni NON devono essere una sequenza monotona crescente o decrescente
Le temperature devono avere fluttuazioni naturali, cioè salite e discese non continue per tutta la durata della previsione.

IMPORTANTE: NON GENERARE VALORI MONOTONI CRESCENTI O DECRESCENTI PER PIU' DI 2 GIORNI CONSECUTIVI.
Sequenze come 5, 6, 7, 8 sono vietate.
Sequenze corrette includono variazioni come 5, 6, 5.5, 7 o 10, 9.5, 10.5, 11.
Dopo aver generato la sequenza, controlla e correggi se necessario.

Esempi di sequenze corrette di 7 valori di temperatura minima:

1) 3, 5, 4, 6, 5, 7, 6  
2) 2, 3, 2.5, 3.5, 3, 4, 3.5  
3) 6, 5, 6.5, 7, 6, 7.5, 7  
4) 4, 3, 4, 5, 4, 5.5, 5  
5) 5, 4, 6, 7, 5, 6, 7  

Genera {PREVISIONI_GIORNI} valori di temperatura minima, uno per giorno.  
Assicurati che la sequenza non abbia più di 2 valori consecutivi in crescita o decrescita monotona.  
Se la sequenza contiene più di 2 valori monotoni consecutivi, correggila introducendo variazioni realistiche.  
Fornisci la sequenza finale, una temperatura per riga.

 
 
***** ISTRUZIONI PER L'OUTPUT *********
Fornisci tutte le temperature previste come numeri arrotondati a valori interi o con massimo una frazione di 0.5 (ad esempio 15, 15.5, 16, 16.5, ecc.). Evita valori decimali diversi da 0 o 0.5.
Scrivi solo i {PREVISIONI_GIORNI} valori numerici in °C, uno per riga, in ordine cronologico. Non scrivere commenti, testo extra o simboli. Solo numeri.
Esempio:
5.0
3.0
...
"""



#---- -------------- Agente TMAX --------------------- #

#definizione della classe Agente Tmax
class AgenteTmax(AgenteBase):
    def __init__(self): #costruttore
        #chiama il costruttore con nome, flag VERBOSE e descrizione
        super().__init__(
            'Agente Tmax',
            verbose=VERBOSE_TMAX,
            descrizione="Prevede le temperature massime per i prossimi giorni usando storico e indici meteo.Usa la capacità di ragionamento del modello per generare le previsioni."
        )
    #definizione del metodo per costruire il prompt, passando i dati di contesto, lista di date da prevedere, stagione
    #alcuni parametri sono opzionali
    def costruisci_prompt(self, dati_contesto, date_da_prevedere, stagione_corrente, media_mese=None, tmax_ultimo=None, tmin_ultimo=None):

     
     #intervallo di date da prevedere 
     inizio_ts = date_da_prevedere[0] #prima data
     fine = date_da_prevedere[-1] #ultima data
    
     #ottengo il nome del mese
     mese_previsto = datetime.strptime(inizio_ts, "%Y-%m-%d").strftime('%B')
     
     #blocco per arricchire il prompt, derivato dal file descrizioni.py
     #il blocco richiama le singole funzioni, passando la stagione, il mese previsto e la media_mese
     blocco_descrizione = ( 
        descrizione_stagione(stagione_corrente) + "\n" +
        descrizione_mese(mese_previsto) + "\n" +
        descrizione_medie_climatologiche(media_mese, mese_previsto)
     )
     #questo blocco va ad essere concatenato al prompt
     
    
        
     #costruzione del prompt tramite parti statiche ed altre variabili
        
     return f"""Sei un esperto meteorologo.
    
Prevedi le **temperature massime** per i {PREVISIONI_GIORNI} giorni successivi, dal {inizio_ts} al {fine}.

******* ANALIZZA E USA I SEGUENTI DATI STORICI ********

Storia delle temperature e variabili meteorologiche degli ultimi {GIORNI_CONTESTO} giorni:

{dati_contesto}

Ogni riga rappresenta un giorno e contiene i seguenti campi osservati e derivati:

- season: stagione meteorologica del giorno (Winter, Spring, Summer, Autumn), utile per comprendere il contesto climatico generale.
- Tmin: temperatura minima giornaliera osservata.
- Tmax: temperatura massima giornaliera osservata.
- Tavg: temperatura media giornaliera osservata, media tra Tmin e Tmax.
- NAO: indice di oscillazione nord atlantica. Valori positivi indicano afflussi di aria più temperata, valori negativi condizioni più fredde.
- Trend Tmax: tendenza storica di lungo periodo della Tmax, utile per stimare variazioni stagionali.
- Season Tmax: componente stagionale della Tmax, utile per riconoscere cicli ricorrenti.
- WindAvg: velocità media del vento (in km/h). Un vento costante può raffreddare o riscaldare l’ambiente, a seconda della direzione.
- Gust: raffica massima di vento registrata. Utile solo in condizioni di eventi estremi, ma può segnalare variazioni locali intense.
- Visibility: visibilità media (in km). Valori bassi indicano foschia o nebbia, che possono influenzare la temperatura massima, soprattutto in inverno.
- Humidity: umidità relativa media della giornata (in %). Alti valori di umidità ostacolano la dispersione del calore.
- DewPoint: punto di rugiada (in °C), cioè la temperatura alla quale l'umidità condensa. Valori elevati indicano aria satura, spesso associata a massime elevate in estate.
- Pressure: pressione atmosferica media (in millibar). Pressioni alte sono associate a stabilità e riscaldamento, pressioni basse a instabilità e raffreddamento.



************ USA QUESTE INFORMAZIONI COME CONOSCENZA DI BASE PER LE PREVISIONI **************
{interazioni_tmax()}


******* ANALIZZA E USA LE SEGUENTI INFORMAZIONI AGGIUNTIVE ********

{blocco_descrizione}


***** ISTRUZIONI PER LA PREVISIONE *********

Per il primo giorno di previsione, la temperatura massima dovrebbe essere intorno a {tmax_ultimo}°C, con una possibile variazione di circa un grado in più o in meno
Analizza sempre le interazioni tra i valori di pressure, humidity, DewPoint, NAO, WindAvg, Gust, visibility, Season Tmax, Trend Tmax, Tmax per prevedere la Temperatura massima.
Considera le tendenze recenti e le condizioni meteorologiche correlate
Le previsioni devono essere realistiche, coerenti e includere una stima della variabilità possibile.
Sulla base di tutti i dati che hai ricevuto, prevedi le temperature massime solo per i prossimi {PREVISIONI_GIORNI} giorni.
Fornisci un valore ragionevole per ogni giorno, indicando la temperatura massima.
Le temperature previste per i prossimi giorni NON devono essere una sequenza monotona crescente o decrescente.
Le temperature devono avere fluttuazioni naturali, cioè salite e discese non continue per tutta la durata della previsione.

IMPORTANTE: NON GENERARE VALORI MONOTONI CRESCENTI O DECRESCENTI PER PIU' DI 2 GIORNI CONSECUTIVI.
Sequenze come 10, 11, 12, 13 sono vietate.
Sequenze corrette includono variazioni come 10, 11, 10.5, 12 o 15, 14.5, 15.5, 16.
Dopo aver generato la sequenza, controlla e correggi se necessario.

Esempi di sequenze corrette di 7 valori di temperatura massima:

1) 18, 25, 22, 28, 23, 26, 24  
2) 15, 20, 17, 21, 19, 23, 20  
3) 30, 27, 29, 31, 28, 32, 30  
4) 22, 18, 21, 25, 20, 24, 23  
5) 26, 24, 28, 30, 27, 29, 31  

Genera {PREVISIONI_GIORNI} valori di temperatura massima, uno per giorno.  
Assicurati che la sequenza non abbia più di 2 valori consecutivi in crescita o decrescita monotona.  
Se la sequenza contiene più di 2 valori monotoni consecutivi, correggila introducendo variazioni realistiche.  
Fornisci la sequenza finale, una temperatura per riga.



***** ISTRUZIONI PER L'OUTPUT *********
Fornisci tutte le temperature previste come numeri arrotondati a valori interi o con massimo una frazione di 0.5 (ad esempio 15, 15.5, 16, 16.5, ecc.). Evita valori decimali diversi da 0 o 0.5.
Scrivi solo i {PREVISIONI_GIORNI} valori numerici in °C, uno per riga, in ordine cronologico. Non scrivere commenti, testo extra o simboli. Solo numeri.
Esempio:
7.5
6.0
...
"""



#------------- Agente di Sintesi ---------------------- #

#definizione della classe agente
class AgenteTabellaFinale:
    #costruttore con nome, modello utile per il file di log e descrizione
    def __init__(self, modello): 
        self.nome = "Agente Di Sintesi"
        self.modello = modello
        self.descrizione = "Compone la tabella finale (Data, Tmin, Tmax, Tavg) e la salva su CSV. Non usa il modello per eseguire il compito"

    #metodo principale che ha come argomenti le date da prevedere e le previsioni dei singoli agenti sotto forma di liste
    def esegui(self, date_da_prevedere, previsioni_tmin=None, previsioni_tmax=None):
        #nuova lista che conterrà tutte le righe finali
        risultati_finali = []
        #itero sulle date utilizzando lo stesso indice i per accedere agli stessi indici delle liste
        for i, data in enumerate(date_da_prevedere):
            tmin = previsioni_tmin[i][1]
            tmax = previsioni_tmax[i][1]
            #calcolo la media aritmetica e arrotondo
            tavg_raw = round((tmin + tmax) / 2, 1)
            #porto il risultato con decimali del tipo 0.5 oppure .0
            tavg = round(tavg_raw * 2) / 2
            #popolo la lista aggiungendo la riga completa
            risultati_finali.append((data, tmin, tmax, tavg))

        # Stampa tabella a terminale se il flag è attivo
        if VISTA_TABFINALE:  
         print(f"\n{self.nome} - Tabella finale delle previsioni:")
         print(f"{'Data':<12} | {'Tmin (°C)':>9} | {'Tmax (°C)':>9} | {'Tavg (°C)':>9}")
         print("-" * 46) #linea di separazione orizzontale con 46 trattini
         for row in risultati_finali:
            data, tmin, tmax, tavg = row
            print(f"{data:<12} | {tmin:9.1f} | {tmax:9.1f} | {tavg:9.1f}")

        
        # chiama la funzione di salvataggio del modulo export, passando tutti i parametri utili.
        # oltre al file csv verrà creato anche un log di testo. 
        salva_tabella_finale_csv(risultati_finali,localita=CITY, modello=self.modello,date_da_prevedere=date_da_prevedere,tempo_tmin_sec=TMIN_SECONDI,tempo_tmax_sec=TMAX_SECONDI )
       
            
        #ritorna la lista di tuple
        return risultati_finali




# --------- Agente Report Previsioni ---------#
#definizione classe Agente Report previsioni
class AgenteReportPrevisioni:
    #costruttore con nome e descrizione
    def __init__(self): 
        self.nome = "Agente Report Previsioni"
        self.descrizione = "Genera il PDF delle previsioni (metadati dal log e tabella dati). Non usa il modello"
    #metodo per chiedere all'utente la conferma per la stampa del report, restituisce True o False
    def _chiedi_conferma(self) -> bool:
        # richiesta di stampa del report all'utente
        while True:
            try: #finchè non arriva una risposta valida continuo il ciclo
                ans = input('Vuoi che generi un report PDF delle previsioni? S/N ').strip().lower()
            except EOFError:
                return False
            if ans in ("s", "si", "sì", "y", "yes"):
                return True
            if ans in ("n", "no", ""):
                return False
            print("Risposta non valida. Digita S oppure N.")

    def esegui(self): # se l'utente non conferma ritorn stringa vuota e annulla.
        if not self._chiedi_conferma():
            print(" Generazione report previsioni annullata dall'utente.")
            return ""

        # Importazionee della funzione di stampa dal file stampa_previsioni, avviene solo quando utile
        from stampa_previsioni import genera_pdf_previsioni
     

        #creazione della cartella se non esiste 
        os.makedirs(REPORTS_ROOT, exist_ok=True)
        #creazione del nome e del percorso per il report. Viene agganciato al nome la data e l'ora di generazione
        nome = f"Report_previsioni_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        percorso_s = os.path.join(REPORTS_ROOT, nome)

        print(f"\n {self.nome}: generazione PDF in corso…")
        #chiamo la funzione di creazione del modulo stampa_previsioni
        path = genera_pdf_previsioni(percorso_s=percorso_s, use_dialog=False)

      #esito della creazione del report pdf
        if path:
            print(f" {self.nome}: PDF salvato in {path}")
        else:
            print(f" {self.nome}: operazione annullata o errore.")
        return path


# --------- Agente Report Confronti ---------#

#definizione classe Agente Report Confronti
class AgenteReportConfronti: #informazioni agente
    def __init__(self):
        self.nome = "Agente Report Confronti"
        self.descrizione = "Confronta previsioni vs reali, calcola MAE/MBE/RMSE/accuratezza e genera PDF con grafico. Non usa il modello"

    def _chiedi_conferma(self) -> bool:
        #richiesta all'utente se stampare il report confronti
        while True:
            try: #finchè non arriva una risposta valida continuo il ciclo
                ans = input('Vuoi che generi un report PDF dei confronti? S/N ').strip().lower()
            except EOFError:
                return False
            if ans in ("s", "si", "sì", "y", "yes"):
                return True
            if ans in ("n", "no", ""):
                return False
            print("Risposta non valida. Digita S oppure N.")
    
    #se l'utente non conferma, ritorna stringa vuota e annulla
    def esegui(self):
        if not self._chiedi_conferma():
            print(" Generazione report confronti annullata dall'utente.")
            return ""
        # Importazione della funzione di stampa dal file stampa_confronto, avviene solo quando utile
        from stampa_confronto import genera_pdf_confronti 
      
        #creazione della cartella se non esiste 
        os.makedirs(REPORTS_ROOT, exist_ok=True)
        #creazione del nome e del percorso per il report. Viene agganciato al nome la data e l'ora di generazione
        nome = f"Report_confronto_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        save_path = os.path.join(REPORTS_ROOT, nome)
       
        print(f"\n {self.nome}: generazione PDF confronto in corso…")
        #chiamo la funzione di generazione dei confronti dal modulo stampa_confronto
        path = genera_pdf_confronti(save_path=save_path, use_dialog=False)
        #esito creazione report
        if path:
            print(f" {self.nome}: PDF salvato in {path}")
        else:
            print(f" {self.nome}: operazione annullata o errore.")
        return path





#--------------------- Agente Interprete -----------------------

#definizione classe Agente Interprete
class AgenteInterpreteLLM:

    #costruttore con percorrso del file csv con le previsione e il collegamento al modello
    def __init__(self, path_csv_previsioni, llm_func):
        #descrizione caratteristiche interprete
        self.nome = "Agente Interprete" 
        self.descrizione = "Risponde a domande su storico+previsioni e può generare grafici su richiesta. Usa il modello"
        self.llm_func = llm_func

        # Caricamento del dataset storico completo e creazione del DataFrame
        df = carica_dataset(DATASET_PATH)
        df['DATE'] = pd.to_datetime(df['DATE'])
        self.df = df #memorizzo il DataFrame nell'istanza

        # Legge previsioni generate dagli agenti e conservate nel file previsioni.csv, crea una tabella da aggiungere al prompt 
        df_previsioni = pd.read_csv(path_csv_previsioni)
        #inizializzo una lista vuota, conterrà tutti i valori della previsione
        self.tabella = []
        #popolo la lista iterando il documento csv con le previsioni
        for _, row in df_previsioni.iterrows():
            data = row['Data']
            localita = row['Località']
            tmin = row.get('TMIN °C', None)
            tmax = row.get('TMAX °C', None)
            tavg = row.get('TAVG °C', None)
            self.tabella.append((data, localita, tmin, tmax, tavg))
 
    #metodo per comporre il prompt, data la domanda dell'utente
    def costruisci_prompt(self, domanda: str):
        try: #prova ad aprire e leggere un file di testo contenente un glossario
            with open(GLOSSARIO_INTERPRETE, "r", encoding="utf-8") as f: 
               glossario = f.read()
        except FileNotFoundError:
            glossario = "(Glossario non disponibile)"
        
        #elenco delle colonne del dataset storico da inserire nel prompt
        col_storiche = [ 
            'DATE', 'TMIN °C', 'TMAX °C', 'TAVG °C',
            'NAO_INDEX',
            'TMIN TREND', 'TMIN SEASONALITY',
            'TMAX TREND', 'TMAX SEASONALITY',
            'TAVG TREND', 'TAVG SEASONALITY',
            'SEASON_NAME', 'WINDAVG km/h',
            'GUST km/h', 'VISIBILITY km',
            'HUMIDITY %', 'DEWPOINT °C',
            'PRESSURE mb','PHENOMENA'
        ]

        #considero la prima data di previsione e la trasformo in oggetto datetime
        prima_data_previsione = pd.to_datetime(self.tabella[0][0])
        #calcola la data di inizio del DataFrame di contesto da associare al prompt, è simile a quello usato nel main
        #ma cambia la variabile in cui sono stati indicati i giorni storici di contesto
        data_inizio_ts_storico = prima_data_previsione - pd.Timedelta(days=GIORNI_STORICO_INTERPRETE)
        
        #filtra il dataset storico tra le date di inizio del DataFrame fino al giorno di prima previsione
        #elenca solo le colonne scelte in col_storiche
        df_storico = self.df.loc[
            self.df['DATE'].between(data_inizio_ts_storico, prima_data_previsione - pd.Timedelta(days=1)),
            col_storiche
        ]
        #costruzione stringa giorni di contesto da passare al modello
        #se non ci sono righe viene dichiarato esplicitamente
        if df_storico.empty:
            storico_str = f"Dati storici ultimi {GIORNI_STORICO_INTERPRETE} giorni (da {data_inizio_ts_storico.date()} a {prima_data_previsione.date()}):\n(Nessun dato disponibile nel range selezionato)"
        #se ci sono righe costruisco le intestazioni e per ogni riga storica viene aggiunto un contenuto testuale
        #con i campi scelti. Il numero di campi equivale a quello indicato in GIORNI_STORICO_INTERPRETE 
        else:
            storico_str = f"Dati storici ultimi {GIORNI_STORICO_INTERPRETE} giorni (da {data_inizio_ts_storico.date()} a {(prima_data_previsione - pd.Timedelta(days=1)).date()}):\n"
            for _, row in df_storico.iterrows():
                storico_str += (
                    f"{row['DATE'].strftime('%Y-%m-%d')}, season={row['SEASON_NAME'].capitalize()}, "
                    f"Tmin={row['TMIN °C']}°C, Tmax={row['TMAX °C']}°C, Tavg={row['TAVG °C']}°C, "
                    f"NAO={row['NAO_INDEX']:.2f}, Trend Tmax={row['TMAX TREND']:.2f}, Season Tmax={row['TMAX SEASONALITY']:.2f},Trend Tmin={row['TMIN TREND']:.2f}, Season Tmin={row['TMIN SEASONALITY']:.2f}, "
                    f"WindAvg={row['WINDAVG km/h']}km/h, Gust={row['GUST km/h']}km/h, Visibility={row['VISIBILITY km']}km, "
                    f"Humidity={row['HUMIDITY %']}%, DewPoint={row['DEWPOINT °C']}°C, Pressure={row['PRESSURE mb']}mb, "
                    f"Phenomena={row['PHENOMENA']}\n"
                )


        #costruzione della tabella previsioni
        previsioni_str = f"Previsioni temperature prossimi {PREVISIONI_GIORNI} giorni:\n"
        #si itera sulle righe precedentemente lette dal file e si costruisce la tabella
        for data, localita, tmin, tmax, tavg in self.tabella:
            previsioni_str += f"{data} - {localita}: Tmin={tmin}, Tmax={tmax}, Tavg={tavg}\n"
        
        #costruzione del prompt associando le parti dinamiche e statiche
        prompt = (  
            "Sei un esperto meteorologo e analista climatologico.\n"
            "Rispondi usando esclusivamente i dati storici e le previsioni fornite.\n"
            "Usa il seguente glossario per arricchire le tue risposte.\n\n"
            f"{glossario}\n\n"
            f"{storico_str}\n\n"
            f"{previsioni_str}\n\n"
            f"Domanda: {domanda}\n"
        )
        
        #vista del prompt se i flag sono True
        if VERBOSE_INTERPRETE and USA_INTERPRETE: 
            print(f"\n Prompt generato per interprete\n{prompt}\n Fine prompt\n")

        return prompt

    #invio il prompt all'agente che costruisce e ritorna la risposta
    def rispondi(self, domanda: str): #costruzione del prompt ed invio al modello
        prompt = self.costruisci_prompt(domanda)
        risposta = self.llm_func(prompt)
        return risposta
    #metodo per implementare una interfaccia testuale minimale
    def interfaccia(self):
        #gestisce la richiesta e l'attesa della domanda
        print("\nAgente Interprete LLM. Scrivi 'esci' per terminare.")
        while True:
            domanda = input("Fai una domanda sulla previsione o tendenze: ")
            if domanda.strip().lower() in ['esci', 'exit', 'quit']:
                print("Uscita dall'interfaccia.")
                break

          #se nel prompt dinamico inserito dall'utente c'è una delle seguneti parole, genera un grafico 
            domanda_bassa = domanda.strip().lower()
            #se nella domanda ci sono parole simili a quelle indicate faccio l'import del tool per generare i grafici
            if any(k in domanda_bassa for k in ["grafico", "grafici", "andamento"]):
                from grafici_tool import mostra_grafico_previsioni
                #determino che tipo di grafico desidera l'utente.
                #in questa versione del sistema il grafico è generato solo sui dati previsionali e non di contesto
                if any(k in domanda_bassa for k in ["media", "medie", "tavg"]):
                    tipo = "TAVG"
                elif any(k in domanda_bassa for k in ["minime", "tmin"]):
                    tipo = "TMIN"
                elif any(k in domanda_bassa for k in ["massime", "tmax"]):
                    tipo = "TMAX"
                else:
                    tipo = "TMIN_TMAX"
                    #se vengono rilevate parole relative al salvataggio abilità il flag salva
                salva = any(k in domanda_bassa for k in ["salva", "file", "immagine", "png"])
                #chiamo la funzione per generare il grafico, passando la tabella delle previsione e i parametri intercettati.
                mostra_grafico_previsioni(self.tabella, tipo=tipo, salva=salva)
                print("Grafico generato." + (" Salvato nella cartella 'grafici'." if salva else ""))
                print("-" * 60)
                continue

        # se non c'è da stampare un grafico inoltra il prompt al modello e stampa la risposta
            print("\nSto ragionando..........:\n")
            risposta = self.rispondi(domanda)
            print("\nRisposta:\n")
            #stampa la risposta lentamente, come se fosse una macchina da scrivere, carattere per carattere
            for char in risposta: 
                print(char, end='', flush=True)
                time.sleep(0.01)
            print("\n" + "-" * 60)
