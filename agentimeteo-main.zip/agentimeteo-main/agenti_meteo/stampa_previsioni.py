'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo Stampa Report Previsioni
Questo modulo è richiamato dall'Agente Report Previsioni e serve per generare un file pdf con il risultato delle previsioni
e alcune informazioni di supporto. Utilizza le funzioni di libreria di ReportLab
'''


import os
import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from datetime import datetime
from config import PREVISIONI_PATH,LOG_PREVISIONI_PATH,OPERATOR, PREVISIONI_REPORT_DIR

# questa funzione genera un percorso assoluto per il pdf dove nome_file rappresenta il nome del pdf (opzionale)
def genera_path_pdf(target_dir: str, nome_file: str | None, default_prefix: str) -> str: #nome_file è il nome del pdf in uscita (opz)
    
    #crea cartella di destinazione se non esiste
    os.makedirs(target_dir, exist_ok=True)
    #se il nome del file non è stato passato lo genera.
    if not nome_file:
        fname = f"{default_prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    #se è stato fornito il nome, viene presa solo la parte del nome e associata l'estensione pdf se non presente
    else:
        base = os.path.basename(nome_file)
        if not base.lower().endswith(".pdf"):
            base += ".pdf"
        fname = base
    return os.path.abspath(os.path.join(target_dir, fname))

 #questa funzione definisce lo schema di creazione di etichette in grassetto e valori non in grassetto ( ad esempio Operatore:nome)
def scrivi_label(canv: canvas.Canvas, x: float, y: float, label: str, value: str, font_size=11):
   
    #sostituisco none con stringa vuota ed elimino spazi vuoti ai bordi
    label = (label or "").strip()
    value = (value or "").strip()
    #definisco lo stile per l'etichetta
    canv.setFont("Helvetica-Bold", font_size)
    canv.drawString(x, y, label + " ")
    #calcola larghezza etichetta per sapere come posizionare il valore a fianco
    offset = canv.stringWidth(label + " ", "Helvetica-Bold", font_size) 
    #definisco stile valore
    canv.setFont("Helvetica", font_size)
    canv.drawString(x + offset, y, value)


#nel file log_previsioni, sono presenti i giorni da prevedere in sequenza esempio 2025-01-01, 2025-01-02 etc....
#la seguente funzione compatta la vista delle date come dalla <data_inizio_previsione> a <data_fine_previsione>
def compatta_periodo(periodo_str: str) -> str:
    #se la strigna è vuota, torna una stringa vuota
    if not periodo_str:
        return ""
    #se la stringa contiene virgole, la funzione si aspetta una lista di date separate da virgole
    if "," in periodo_str:
        #elimina spazi vuoti e divide in parti prendendo come elemento la virgola
        parti = [p.strip() for p in periodo_str.split(",") if p.strip()]
        # se non ci sono elementi torna la stringa originale
        if not parti:
            return periodo_str
        try: #conversione delle parti data in datetime per poter essere manipolate come oggetti
            dates = pd.to_datetime(parti, errors="raise").date
            #costruzione della stringa compatta
            return f"dal {min(dates).isoformat()} al {max(dates).isoformat()}"
        except Exception: #se non riesce solleva un errore e torna le data originali non compatte
            return periodo_str
    return periodo_str


#questa funzione separa l'etichetta dal valore considerando i due punti come separatore
def dividi_etichetta_valore(line: str | None, fix_minim: bool = False): #fix_min è un parametro opzionale se è falso non fa nulla se vero effettua una correzione
    
    #se la riga è vuota torna una coppia di None
    if not line:
        return None, None
    #se il parametro è vero effettua correzione, è stato inserito perchè certe volte il modello tronca l'ultima lettera
    #il sistema non andrebbe in errore è solo per mantenere corretta la parte finale della frase.
    
    # se la riga contiene : la divide creando la prima parte (etichetta) e la parte dopo (valore)
    if ": " in line:
        before, after = line.split(": ", 1)
        #se before è vero mette la prima lettera in maiuscolo e ritorna Etichetta:valore
        if before:
            before = before[0].upper() + before[1:]
        return before + ":", after
    #se : non ci sono ritorna l'etichetta in masiuscolo ed un valore vuoto
    label = line[0].upper() + line[1:] if line else line
    return label, ""




# GENERAZIONE PDF PRINCIPALE 
#la funzione riceve il percorso e genera il pdf
def genera_pdf_previsioni(percorso_s: str | None = None, use_dialog: bool = True) -> str:
 
    #viene determinato il percorso finale del file ed il nome
    percorso_s = genera_path_pdf(PREVISIONI_REPORT_DIR, percorso_s, "Report_previsioni")
    
    #prova a leggere il csv delle previsioni, se non riesce solleva un errore
    try:
        df = pd.read_csv(PREVISIONI_PATH)
    except Exception as e:
        raise FileNotFoundError(f"Errore nel caricamento delle previsioni da {PREVISIONI_PATH}: {e}")

   # trasformo in stringa il valore contenuto in località
    luogo = str(df["Località"].iloc[0])

    # creo una copia del DataFrame con le colonne indicate
    df = df[["Data", "TMIN °C", "TMAX °C", "TAVG °C"]].copy()

    #converto i valori termini in valori numerici, se qualcos non è convertibile inserisce NaN
    for c in ["TMIN °C", "TMAX °C", "TAVG °C"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")



    #prova ad aprire il log previsioni e leggere i valori all'interno ripulendoli
    try:
        with open(LOG_PREVISIONI_PATH, "r", encoding="utf-8", errors="ignore") as f:
            lines = [ln.strip() for ln in f if ln.strip()]
            #inizializzo le variabili 
        data_ora = modello = periodo = ""
        tmin_label = tmin_value = tmax_label = tmax_value = ""
        #ciclo su ogni riga portando tutto in minuscolo, successivamente confronto le stringhe minuscole
        #se trovo le corrispondenze indicate passo i valori alla funzione che separa valore da etichetta
        #se non trovo corrispondenza valorizzo con stringa vuota
        for ln in lines:
            low = ln.lower()
            if "modello usato" in low:
                _, v = dividi_etichetta_valore(ln); modello = v or ""
            elif "data/ora previsione" in low:
                _, v = dividi_etichetta_valore(ln); data_ora = v or ""
            elif "periodo previsione" in low:
                _, v = dividi_etichetta_valore(ln); periodo = v or ""
                #qui per il tempo vengono gestite le due versioni 
            elif "tempo previsioni temperature minime" in low:
                k, v = dividi_etichetta_valore(ln, fix_minim=True); tmin_label, tmin_value = k or "", v or ""
            elif "tempo previsioni temperature massime" in low:
                k, v = dividi_etichetta_valore(ln); tmax_label, tmax_value = k or "", v or ""
    #errore durante la lettura del file, solleva eccezione
    except Exception as e:
        raise FileNotFoundError(f"Errore nella lettura del log {LOG_PREVISIONI_PATH}: {e}")

    #nella variabile è contenuto il periodo previsionale in forma compatta
    periodo_c = compatta_periodo(periodo)
    
    
    #tramite le funzioni di ReportLab genero l'oggetto canvas utilizzando un formato pagina A4, impostando nome, ed estraendo le dimensioni del canvas
    c = canvas.Canvas(percorso_s, pagesize=A4)
    c.setTitle("Previsioni Temperature")
    width, height = A4

    y = height - 40 #imposto coordinate bordo superiore
    #imposto le caratteristiche del documento, titolo, font, e altri paramentri come 50 che rappresenta il valore della coordinata x nel documento .
    c.setFont("Helvetica-Bold", 16); c.drawString(50, y, "Agenti meteo - Previsioni Temperature (degC)"); y -= 30 #scalo il documento di 30 punti verso il basso
    # inserimento delle altre voci del documento con lo stesso principio di funzionamento del titolo
    scrivi_label(c, 50, y, "Data/Ora previsione:", data_ora); y -= 20
    scrivi_label(c, 50, y, "Data/Ora generazione report:", datetime.now().strftime("%Y-%m-%d %H:%M:%S")); y -= 20
    scrivi_label(c, 50, y, "Operatore:", OPERATOR); y -= 20
    scrivi_label(c, 50, y, "Modello usato:", modello); y -= 20
    scrivi_label(c, 50, y, "Periodo previsione:", periodo_c); y -= 20
    scrivi_label(c, 50, y, "Luogo previsione:", luogo); y -= 20
    #etichette relative al tempo, se disponibili stampa i valori
    if tmin_label: scrivi_label(c, 50, y, tmin_label, tmin_value); y -= 20
    if tmax_label: scrivi_label(c, 50, y, tmax_label, tmax_value); y -= 20

    #prepara i dati per la tabella. La prima riga sono intestazioni ed il resto elementi della lista
    records = [df.columns.to_list()] + df.values.tolist()
    table = Table(records)
    #stili grafici applicati alla tabella
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightblue),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
    ]))
    #calcolo dimensioni tabella dopo aver applicato gli stili, senza imporre limiti (0,0)
    w, h = table.wrap(0, 0)
    #disegna la tabella posizionandola sotto i dati della previsione.
    table.drawOn(c, 50, max(60, y - 20 - h))
    #salva il pdf e chiude
    c.save()
    return percorso_s
    
