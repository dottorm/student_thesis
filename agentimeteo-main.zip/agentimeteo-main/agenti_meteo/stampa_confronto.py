'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo Stampa Report Confronti
Questo modulo è richiamato dall'Agente Report Confronti e serve per generare un file pdf con il risultato dei confronti tra valori previsiti e
valori osservati/simulati, genera tabelle riassuntive per ogni variabile ed anche un grafico insieme ad altre informazioni di supporto. 
Utilizza le funzioni di libreria di ReportLab MatplotLib per i grafici
'''

import os
from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg") #per crare grafici senza intestazioni
import matplotlib.pyplot as plt

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import  Table, TableStyle, SimpleDocTemplate, Paragraph, Spacer, Image,KeepTogether, PageBreak

from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


from config import GIORNI_CONTESTO,DATASET_PATH,PREVISIONI_PATH,LOG_PREVISIONI_PATH,OPERATOR,MEDIE_FINALI_PATH,CONFRONTI_REPORT_DIR


#creazione di stili predefiniti per il documento, vista la grandezza del documento è conveniente avere dei parametri facilmente riutilizzabili ed omogenei
#vengono gestiti gli stili del titoli, sottotitolo dei testi e dei paragrafi
stili = getSampleStyleSheet()
stile_titolo = stili["Title"]; stile_titolo.fontSize = 20; stile_titolo.spaceAfter = 10; stile_titolo.leading = 22
stile_testo = stili["Normal"]; stile_testo.spaceAfter = 10
stile_sottotitolo = stili["Heading3"]; stile_sottotitolo.spaceAfter = 6; stile_sottotitolo.alignment = 1
stile_sottotitolo_piccolo = ParagraphStyle(name="SottoTitoloPiccolo", parent=stile_sottotitolo, fontSize=10, leading=12, spaceAfter=4, alignment=1)

#restituice un percorso assoluti per il pdf, se il nome non è passato tra i parametri
#la funzione ne genera uno usando il time stamp
def salva_pdf_cartella(target_dir: str, desired_name: str | None, default_prefix: str) -> str:
    
    os.makedirs(target_dir, exist_ok=True)
    if not desired_name:
        fname = f"{default_prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    #se viene passato il nome, lo mette in minuscolo e associa l'estensione .pdf se non presente
    else:
        base = os.path.basename(desired_name)
        if not base.lower().endswith(".pdf"):
            base += ".pdf"
        fname = base
    return os.path.abspath(os.path.join(target_dir, fname))

#nel file log_previsioni, sono presenti i giorni da prevedere in sequenza esempio 2025-01-01, 2025-01-02 etc....
#la seguente funzione compatta la vista delle date come dalla <data_inizio_previsione> a <data_fine_previsione>
def compatta_periodo(periodo_str: str) -> str: 
    #se la strigna è vuota, torna una stringa vuota
    if not isinstance(periodo_str, str):
        return str(periodo_str)
    #se la stringa contiene virgole, la funzione si aspetta una lista di date separate da virgole
    if "," in periodo_str:
        #elimina spazi vuoti e divide in parti prendendo come elemento la virgola
        parts = [p.strip() for p in periodo_str.split(",") if p.strip()]
        # se non ci sono elementi torna la stringa originale
        if not parts:
            return periodo_str
        
        try:
            #conversione delle parti data in datetime per poter essere manipolate come oggetti
            date = pd.to_datetime(parts, errors="raise").date
            #costruzione della stringa compatta
            dmin = min(date); dmax = max(date)
            return f"dal {dmin.isoformat()} al {dmax.isoformat()}"
        #se non riesce solleva un errore e torna le data originali non compatte
        except Exception:
            return periodo_str
    return periodo_str


#questa funzione riceve un parametro percorso e carica il file log_previsioni
def carica_log(path): 
    #inizializzazioni di variabili vuote
    data_ora = ""
    modello = ""
    riga_periodo = ""
    tmin_line_pdf = None
    tmax_line_pdf = None
    
    #apertura del file di log e rimozione dei caratteri \n
    try:
        with open(path, "r", encoding="utf-8") as f:
            log_lines = [r.rstrip("\n") for r in f.readlines()]
            #se ci sono almento tre righe prende ogni riga ed estrare i campi. Se trova : prende la parte che si trova dopo e la ripulisce
            #altrimenti prende tutta la riga
        if len(log_lines) >= 3:
            data_ora   = log_lines[0].split(": ", 1)[1].strip() if ": " in log_lines[0] else log_lines[0]
            modello    = log_lines[1].split(": ", 1)[1].strip() if ": " in log_lines[1] else log_lines[1]
            riga_periodo= log_lines[2].split(": ", 1)[1].strip() if ": " in log_lines[2] else log_lines[2]

            #formatta la riga con etichetta in grassetto e valore non in grassetto.
            #inoltre corregge il troncamento minim solo ai fini di una migliore leggibilità (evitabile)
        def fmt(line, tipo):
            #se line è vuota ritorna none
            if not line: return None
         
            #se la riga non è vuota ed il primo valore è una lettera la converte in maiuscolo
            if line and line[0].isalpha():
                line = line[0].upper() + line[1:]
            #se nella riga c'è un separatore : la divide in before ed after ponendo before in grassetto    
            if ": " in line:
                before, after = line.split(": ", 1)
                return f"<b>{before}:</b> {after}"
            return f"<b>{line}</b>"
        
        #scorre le righe cercando una corrispondenza e seleziona la prima riga r che la soddisfa
        #se non trova corrispondenze torna none
        cand_tmin = next((r for r in log_lines if r.startswith("tempo previsioni temperature minime:")), None)
        cand_tmax = next((r for r in log_lines if r.startswith("tempo previsioni temperature massime:")), None)
        #passa la riga trovata alla funzione fmt per la formattazione
        tmin_line_pdf = fmt(cand_tmin, "minime")
        tmax_line_pdf = fmt(cand_tmax, "massime")
    except Exception:
        pass
    return data_ora, modello, riga_periodo, tmin_line_pdf, tmax_line_pdf

#partendo dal DataFrame delle temperature previste crea una mappa per attribuire i nuovi nomi per le tabelle
def rinomina_intestazioni_colonne(df_prev: pd.DataFrame) -> pd.DataFrame:

    mappa_prev = {
        "TMIN °C": "Tmin_prev",
        "TMAX °C": "Tmax_prev",
        "TAVG °C": "Tavg_prev",
    }
    #ritorna un nuovo DataFrame con le colonne interessate rinominate, le altre non inserite nella mappa restano le stesse
    return df_prev.rename(columns=mappa_prev)

#partendo dal DataFrame delle temperature reali/simulate crea una mappa per attribuire i nuovi nomi per le tabelle
def rinomina_colonne_reali(df_reali: pd.DataFrame) -> pd.DataFrame:
 
    mappa_reali = {
        "TMIN °C": "Tmin_reale",
        "TMAX °C": "Tmax_reale",
        "TAVG °C": "Tavg_reale",
    }
    #ritorna un nuovo DataFrame con le colonne interessate rinominate, le altre non inserite nella mappa restano le stesse
    return df_reali.rename(columns=mappa_reali)


# questa funzione calcola le metriche ricevendo come parametri i valori reali/simulati e i valori predetti
def metriche(y_true, y_pred):
    #converte i due valori in float e inserisce NaN se qualcosa non va bene
    y_true = pd.to_numeric(y_true, errors="coerce")
    y_pred = pd.to_numeric(y_pred, errors="coerce")
    
    #calcolo metriche arrotondando a 2 cifree decimali
    mae = float(np.round(np.abs(y_true - y_pred).mean(), 2))
    rmse = float(np.round(np.sqrt(((y_pred - y_true) ** 2).mean()), 2))
    mbe = float(np.round((y_pred - y_true).mean(), 2))
    acc = float(np.round(100 - mae, 2))
    return mae, rmse, mbe, acc


#questa funzione genera il pdf dei confronti. Riceve in ingresso il percorso dove salvare il file, ma è opzionale
#ho lasciato l'opzione per gestire il salvataggio in maniera diversa per il futuro
def genera_pdf_confronti(save_path: str | None = None, use_dialog: bool = False) -> str:
    
    #crea l'intero percorso di salvataggio del file
    save_path = salva_pdf_cartella(CONFRONTI_REPORT_DIR, save_path, "Report_confronto")

    # caricamento del csv delle previsioni e creazione del DataFrame
    #se incontra un problema, solleva l'errore e ritorna una stringa vuota
    try:
        df_prev = pd.read_csv(PREVISIONI_PATH)
    except Exception as e:
        print(f"Errore nel caricamento previsioni: {e}")
        return ""
    #rinomino le intestazioni delle colonne
    df_prev = rinomina_intestazioni_colonne(df_prev)

    #effettuo un controllo di sicurezza, anche se in genere il dataset è sempre completo.
    #se non trova la colonna data solleva un errore e ritorna una strunga vuota.
    if "Data" not in df_prev.columns:
        print("Errore: la colonna 'Data' non è presente nelle previsioni.")
        return ""
    #se non trova le temperature medie calcolate nel file, ma trova la temperatura minima e massima, calcola la media
    #controllo di sicurezza 
    if "Tavg_prev" not in df_prev.columns and {"Tmin_prev", "Tmax_prev"}.issubset(df_prev.columns):
        df_prev["Tavg_prev"] = (pd.to_numeric(df_prev["Tmin_prev"], errors="coerce") + pd.to_numeric(df_prev["Tmax_prev"], errors="coerce"))/2
    #imposto come tipo numerico
    for c in ["Tmin_prev", "Tmax_prev", "Tavg_prev"]:
        if c in df_prev.columns:
            df_prev[c] = pd.to_numeric(df_prev[c], errors="coerce")


    # leggo i valori dal log
    data_ora, modello, riga_periodo, tmin_line_pdf, tmax_line_pdf = carica_log(LOG_PREVISIONI_PATH)
    #compatto la visualizzazione del periodo di previsione
    periodo_compatto = compatta_periodo(riga_periodo)

    # prova ad aprire il dataset con i dati reali/simulati e creare il DataFrame
    #se incontra problemi solleva eccezione e torna una stringa vuota
    try:
        df_reali = pd.read_csv(DATASET_PATH)
    except Exception as e:
        print(f"Errore nel caricamento dataset reale: {e}")
        return ""
    #rinomina le colonne del dataset
    df_reali = rinomina_colonne_reali(df_reali)
    n_reali = {"DATE", "Tmin_reale", "Tmax_reale", "Tavg_reale"}
    #verifica che le colonne siano presenti
    if not n_reali.issubset(df_reali.columns):
        print(f"Errore: mancano colonne nel dataset reale: {n_reali - set(df_reali.columns)}")
        return ""
    #forza le colonne come numeriche (float) se riscontra problemi inserisce Nan
    for c in ["Tmin_reale", "Tmax_reale", "Tavg_reale"]:
        df_reali[c] = pd.to_numeric(df_reali[c], errors="coerce")

    # Dati per la stampa della finistra di contesto in base al numero di giorni scelti in config
    #converto le date previste in oggetto datetime
    dates_prev = pd.to_datetime(df_prev["Data"], errors="coerce")
    #Se trova almento una data la normalizza, se non trova date valide le pone a None
    if dates_prev.notna().any():
      inizio_prev_date = pd.to_datetime(dates_prev.min()).normalize()
    else:
      inizio_prev_date = None

    #viene creato un DataFrame vuoto con le colonne scelte
    df_contesto = pd.DataFrame(columns=["DATE", "Tmax_reale", "Tavg_reale", "Tmin_reale"])
    #dizionario per memorizzare i dati, inizialmente vuoto
    contesto_s = {"Tmax": np.nan, "Tavg": np.nan, "Tmin": np.nan}
    #se la data di inizio previsione è valida, prima crea una colonna DATE di appoggio contenente le date reali normalizzate e trasformate in datetime
    if inizio_prev_date is not None and not pd.isna(inizio_prev_date):
        df_reali["_DATE"] = pd.to_datetime(df_reali["DATE"], errors="coerce").dt.normalize()
        #calcola l'inizio della finestra di contesto,questo serve perchè alla finde del pdf viene stampata tutta la finestra di contesto delle temperature 
        contesto_start = inizio_prev_date - pd.Timedelta(days=int(GIORNI_CONTESTO))
        #seleziona solo le date relative ai giorni reeali/osservati 
        dati_reali_bool = (df_reali["_DATE"] >= contesto_start) & (df_reali["_DATE"] < inizio_prev_date)
        #estrae la finestra di contesto
        df_contesto = df_reali.loc[dati_reali_bool, ["DATE", "Tmax_reale", "Tavg_reale", "Tmin_reale"]].copy().reset_index(drop=True)
        #se la finestra non è vuota calcola la media la arrotonda a due decimali
        if not df_contesto.empty:
            contesto_s["Tmax"] = round(pd.to_numeric(df_contesto["Tmax_reale"], errors="coerce").mean(), 2)
            contesto_s["Tavg"] = round(pd.to_numeric(df_contesto["Tavg_reale"], errors="coerce").mean(), 2)
            contesto_s["Tmin"] = round(pd.to_numeric(df_contesto["Tmin_reale"], errors="coerce").mean(), 2)

    # Unione tra previsione e dati osservati/simulati, ma prima viene fatto un controllo sull'esistenza di date comuni
    #il controllo sarebbe superfluo se il campo DATE avesse una sola etichetta uguale per tutti
    if not set(df_prev["Data"]).intersection(set(df_reali["DATE"])):
        print("Errore: nessuna data delle previsioni è presente nel dataset reale.")
        return ""
    #se ci sono date in comune fa un'unione ( merge inner=intersezione) tra date previste e date osservate/simulate
    df_merge = pd.merge(df_prev, df_reali, left_on="Data", right_on="DATE", how="inner")
    for v in ["Tmin", "Tmax", "Tavg"]:
        #caloclo errore con segno ed errore in valore assoluto
        df_merge[f"{v}_err_signed"] = df_merge[f"{v}_prev"] - df_merge[f"{v}_reale"]
        df_merge[f"{v}_err_abs"] = df_merge[f"{v}_err_signed"].abs()
    
    # calcola per ogni variabile termica, gli indicatori tramite le funzioni appositamente create 
    mae_tmin, rmse_tmin, mbe_tmin, acc_tmin = metriche(df_merge["Tmin_reale"], df_merge["Tmin_prev"])
    mae_tmax, rmse_tmax, mbe_tmax, acc_tmax = metriche(df_merge["Tmax_reale"], df_merge["Tmax_prev"])
    mae_tavg, rmse_tavg, mbe_tavg, acc_tavg = metriche(df_merge["Tavg_reale"], df_merge["Tavg_prev"])
    #calcolo media tra le accuratezze con 2 decimali
    accuratezza_totale = round((acc_tmin + acc_tmax + acc_tavg) / 3, 2)

    


    # creazione del pdf tramite reportlab, documento con più pagine
    doc = SimpleDocTemplate(save_path, pagesize=A4)
    #definisce la struttura della prima pagina
    def on_first_page(canvas, doc):
        canvas.setTitle("Confronto previsioni")
    # definisco e poi popolo una lista con le voci contenenti le informazioni relativa al confronto a cui vengono applicati gli stili definiti inizialmente
    voci = []
    voci.append(Paragraph("Confronto Temperature Previste vs Reali in °C", stile_titolo))
    voci.append(Spacer(1, 10)) #spazio verticale
    voci.append(Paragraph(f"<b>Data/Ora generazione previsione:</b> {data_ora}", stile_testo))
    voci.append(Paragraph(f"<b>Data/Ora generazione report:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", stile_testo))
    voci.append(Paragraph(f"<b>Operatore:</b> {OPERATOR}", stile_testo))
    voci.append(Paragraph(f"<b>Modello usato:</b> {modello}", stile_testo))
    voci.append(Paragraph(f"<b>Periodo previsione:</b> {periodo_compatto}", stile_testo))
    voci.append(Paragraph(f"<b>MAE complessivo:</b> Tmin {mae_tmin} °C | Tmax {mae_tmax} °C | Tavg {mae_tavg} °C", stile_testo))
    voci.append(Paragraph(f"<b>RMSE complessivo:</b> Tmin {rmse_tmin} °C | Tmax {rmse_tmax} °C | Tavg {rmse_tavg} °C", stile_testo))
    voci.append(Paragraph(f"<b>MBE complessivo:</b> Tmin {mbe_tmin} °C | Tmax {mbe_tmax} °C | Tavg {mbe_tavg} °C", stile_testo))
    voci.append(Paragraph(f"<b>Accuratezza complessiva (100 - MAE):</b> {accuratezza_totale}%", stile_testo))
    #voci relative al tempo di calcolo
    if tmin_line_pdf: voci.append(Paragraph(tmin_line_pdf, stile_testo))
    if tmax_line_pdf: voci.append(Paragraph(tmax_line_pdf, stile_testo))
    voci.append(Spacer(1, 16))

    #creazione della tabella riassuntiva per il confronto tra tutte le variabili
    #estrae dal DataFrame merge le colonne da mostrare
    df_tab = df_merge[["Data", "Tmin_prev", "Tmin_reale", "Tmax_prev", "Tmax_reale", "Tavg_prev", "Tavg_reale"]] 
    #definisce le intestazioni per la tabella
    intestazione_tab = ["Data", "Tmin Prev", "Tmin Reale", "Tmax Prev", "Tmax Reale", "Tavg Prev", "Tavg Reale"]
    #costruisce la tabella con le intestazioni e poi i valori della lista
    table_data = [intestazione_tab] + df_tab.values.tolist()
    #istanzio l'oggetto tabella di reportlab
    table = Table(table_data)
    #definisco gli stili della tabella
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
    ]))
    #aggiungo la tabella al flusso del documento
    voci.append(table)

    # creo una nuova figura di 10 x 5 pollici
    plt.figure(figsize=(10, 5))
    #converto la data in oggetto datetime
    dates = pd.to_datetime(df_merge["Data"]) 
    #traccio il grafico delle singole variabili doppio trattino (--) per temperature previste
    plt.plot(dates, df_merge["Tmin_prev"], label="Tmin Prev", linestyle="--")
    plt.plot(dates, df_merge["Tmin_reale"], label="Tmin Reale")
    plt.plot(dates, df_merge["Tmax_prev"], label="Tmax Prev", linestyle="--")
    plt.plot(dates, df_merge["Tmax_reale"], label="Tmax Reale")
    plt.plot(dates, df_merge["Tavg_prev"], label="Tavg Prev", linestyle="--")
    plt.plot(dates, df_merge["Tavg_reale"], label="Tavg Reale")
    #aggiungo una piccola legenda
    plt.legend(); plt.title("Confronto Temperature"); plt.xlabel("Data"); plt.ylabel("Temperatura (°C)")
    #ruoto di 45° le etichette che si trovano sull'asse delle ascisse
    plt.xticks(rotation=45); plt.tight_layout()

    # salva il grafico nella stessa cartella del PDF. Il salvataggio è temporaneo, serve solo come supporto
    # a fine file verrà eliminato 
    pdf_dir = os.path.dirname(save_path)
    graph_path = os.path.abspath(os.path.join(pdf_dir, os.path.basename(save_path).replace(".pdf", "_grafico.png")))
    plt.savefig(graph_path); plt.close()
    #aggiunge al pdf un blocco composto dal titolo del grafico e l'immagine png generata
    voci.append(
        KeepTogether([
            Paragraph("Grafico temperature previste e reali", stile_sottotitolo),
            Image(graph_path, width=500, height=200),
            Spacer(1, 18),
        ])
    )

    # costruzione delle tabelle dettagliate.
    #per ogni variabile termica vengono definite le intestazioni delle colonne e gli indicatore di errori associati
    variabili = [
        ("Tmin", "Tmin_prev", "Tmin_reale", "Tmin_err_signed", "Tmin_err_abs", mae_tmin, rmse_tmin, mbe_tmin, acc_tmin),
        ("Tmax", "Tmax_prev", "Tmax_reale", "Tmax_err_signed", "Tmax_err_abs", mae_tmax, rmse_tmax, mbe_tmax, acc_tmax),
        ("Tavg", "Tavg_prev", "Tavg_reale", "Tavg_err_signed", "Tavg_err_abs", mae_tavg, rmse_tavg, mbe_tavg, acc_tavg),
    ]

    #itera sulle tre variabili
    for label, prev, reale, err_s, err_abs, mae_val, rmse_val, mbe_val, acc_val in variabili:
       #inizia costruendo la riga di intestazione
        righe_dt = [["Data", f"{label} Prev", f"{label} Reale", "Errore (signed)", "Errore (abs)"]]
        #popola ogni riga con i dati
        for _, row in df_merge.iterrows():
            righe_dt.append([row["Data"], row[prev], row[reale], round(row[err_s], 2), round(row[err_abs], 2)])
        #preparazione di 4 righe di testo con le metriche
        testo_metriche = [f"MAE: {mae_val} °C", f"RMSE: {rmse_val} °C", f"MBE: {mbe_val} °C", f"Accuratezza (100 - MAE): {acc_val}%"]

        #aggiunge le righe relative alle metriche come se fossere righe della tabella, riempiendo solo le prime celle e lasciando le altre vuote
        # lasciare celle vuote è necessario perchè le righe più in alto hanno tutte le celle piene 
        idx_metriche = []
        for txt in testo_metriche:
            idx_metriche.append(len(righe_dt)); righe_dt.append([txt, "", "", "", ""])
        #creazione della tabella    
        tab = Table(righe_dt)
        #definizione di stili per la tabella
        stili_tb = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightblue),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTSIZE", (0, 0), (-1, -1), 7),
        ]
        #per ogni riga della tabella applica degli stili e degli allineamenti specifici
        for r in idx_metriche:
            stili_tb.append(("SPAN", (0, r), (-1, r)))
            stili_tb.append(("ALIGN", (0, r), (-1, r), "LEFT"))
            #applica gli stili alla tabella
        tab.setStyle(TableStyle(stili_tb))
        #titolo per la tabella, il titolo è posizionato prima dell'inizio della tabella
        voci.append(KeepTogether([Paragraph(f"Tabella dettagliata per {label}", stile_sottotitolo), tab, Spacer(1, 14)]))

    # Elenco ultimi GIORNI_CONTESTO giorni (se disponibile)
    #se le condizioni sono soddisfatte stampa la sezione di contesto. Ovvero le informazioni sulle temperature dei giorni precedenti la previsione
    if df_contesto is not None and not df_contesto.empty and inizio_prev_date is not None:
        #questo permette di inserire i giorni di contesto in una nuova pagina     
        voci.append(PageBreak())
        #caloclo delle date di inizio e difine, il Timedelta viene usato per sottrare un numero di giorni prestabilito e generare così la data
        data_iniz = (pd.to_datetime(inizio_prev_date) - pd.Timedelta(days=int(GIORNI_CONTESTO))).date().isoformat()
        data_fine = (pd.to_datetime(inizio_prev_date) - pd.Timedelta(days=1)).date().isoformat()
        #crea il titolo del paragrafo
        elenco_title = Paragraph(
            f"Elenco temperature degli ultimi <b>{int(GIORNI_CONTESTO)}</b> giorni "
            f"precedenti l'inizio della previsione ({data_iniz} \u2192 {data_fine})",
            stile_sottotitolo_piccolo
        )
        #definisce le intestazioni
        elenco_intestazione_tab = ["Data", "Tmax", "Tavg", "Tmin"]
        #crea la prima riga con le intestazioni e le altre con i dati
        elenco_data = [elenco_intestazione_tab] + df_contesto[["DATE", "Tmax_reale", "Tavg_reale", "Tmin_reale"]].values.tolist()
        #crea la tabella ed imposta le dimensioni delle colonne
        elenco_table = Table(elenco_data, colWidths=[90, 50, 50, 50])
        #definisce ed applica gli stili alla tabella
        elenco_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTSIZE", (0, 0), (-1, -1), 6),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        #aggiunge al flusso del documento il titolo e la tabella
        voci.append(KeepTogether([elenco_title, elenco_table]))

    #costruisce il pdf scrivendo tutti gli elementi contenuti in voci ed imposta le proprietà della prima pagina impostate ad inizio file.
    doc.build(voci, onFirstPage=on_first_page)
    print(f"PDF confronto salvato in: {save_path}")

    #prova a pulire il file png generato come supporto pere il grafico
    try:
        if os.path.exists(graph_path):
            os.remove(graph_path)
    #se non riesce non interrompe il flusso ma ignora l'errore
    except OSError:
        pass
   
    return save_path
   