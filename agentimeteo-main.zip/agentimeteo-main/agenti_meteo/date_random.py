'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Questo file non è parte del flusso previsionale, ma è stato un supporto per le fasi di test.
Genera delle date casuali tra quelle disponibili all'interno del dataset.
'''

import random
from datetime import datetime, timedelta


#converto le stringhe in oggetti datetime rispettando il formato indicato. In questo modo posso effettuare operazioni sulle date.
data_inizio = datetime.strptime("2010-01-01", "%Y-%m-%d")
data_fine = datetime.strptime("2025-06-30", "%Y-%m-%d")

# numero di giorni totali nell'intervallo
delta = (data_fine - data_inizio).days

# Estrazione di 15 date casuali uniche
date_random = set() #creo insieme vuoto per contenere le date
while len(date_random) < 15:
    
    #genero un numero intero casuale tra 0 e il numero di giorni dell'intervallo di date.
    giorno_random = random.randint(0, delta)
    
    #ricavo la data sommando alla data di inizio, il numero di giorni estratti randomicamente, e grazie alla funzione time delta restituisce una data
    # timedelta rappresenta un intervallo di tempo da sommare alla data iniziale, non è un numero puro. 
    date = data_inizio + timedelta(days=giorno_random)

    #converte la data in stringa e la aggiunge al set di date.
    date_random.add(date.strftime("%Y-%m-%d"))

# ordino le date del set e le stampo
for d in sorted(date_random):
    print(d)
