'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo confronti
In questo file è sviluppata la logica dei confronti tra dati previsi e dati osservati/simulati, inoltre qui avviene anche il calcolo
di tutti gli indicatori di accuratezza della previsione, MAE, MBE, RMSE, ACCURATEZZA
'''

import pandas as pd
import numpy as np

#definisce la funzione per sviluppare i confronti, alla quale vengono passati il dizionario con date e valore previsto,
#variabile che indica la grandezza da confrontare, ad esempio TMAX, il percorso del dataset con i dati osservati/simulati

def confronta_previsioni(previsioni_dict, variabile, real_path):
    
    #porta tutto il contenuto di var in maiuscolo
    var = variabile.upper().strip()

    # Carica dati rilevati/simulati da dataset storico
    df_real = pd.read_csv(real_path)
   
   
    #il blocco di verifica del campo DATE è integrato solo per sicurezza, nel caso in cui si carichi un dataset con questo campo non appropriato
    #ma se vengono usati i dataset standard del progetto questi controlli sono superflui.
    if "DATE" not in df_real.columns:
        raise ValueError("Nel dataset reale manca la colonna 'DATE'.")

    # converto le date in formato datetime
    df_real["DATE"] = pd.to_datetime(df_real["DATE"]).dt.strftime("%Y-%m-%d")


    # Quando riceve il contenuto di variabile associa a questo il reale nome della colonna
    colonne_possibili = { 
        "TMAX": "TMAX °C",
        "TMIN": "TMIN °C",
        "TAVG": "TAVG °C"
    }
    #se non ci sono campi corrispondenti solleva un errore
    if var not in colonne_possibili:
       raise ValueError(f"Variabile non riconosciuta: {variabile}. Nome colonna non corretto.")

    # qui è contenuto il nome del campo del dataset associato a var
    # ad esempio se var= TMAX il valore di colonna_reale è TMAX °C
    colonna_reale = colonne_possibili[var]
    
    #se non trova il nome della colonna solleva un errore
    if colonna_reale not in df_real.columns:
      raise ValueError(
        f"Nel dataset reale non ho trovato la colonna attesa per {var}: {colonna_reale}"
    )

    # Creo una lista vuota che conterrà le previsioni e gli scarti tra i valori predetti e quelli osservati
    # gli scarti saranno con e senza segno 
    righe = []
    #itero su tutte le coppie del dizionario delle previsioni
    for data, val_prev in previsioni_dict.items():
        #trasformo la data in un datetime
        data_norm = pd.to_datetime(str(data)).strftime("%Y-%m-%d")
        #seleziono nel DataFrame con i dati reali/simulati quelli con la data corripondente e ne salvo il valore
        match = df_real.loc[df_real["DATE"] == data_norm, colonna_reale]
        if not match.empty:
            #prende i valori e li converte in float
            val_reale = float(match.iloc[0])
            # calcolo errore con segno per MBE
            errore = float(val_prev) - val_reale  
            #aggiungo una riga per ogni data, il numero dopo la variabile all'interno di round, indica quanti decimali usare
            righe.append((data_norm,
                          round(float(val_prev), 1), #valore previsto
                          round(val_reale, 1), #valore rilevato
                          round(errore, 2), #errore MBE
                          round(abs(errore), 2))) #errore MAE derivato usando il valore assoluto su MBE
    #se non è stata aggiunta nessuna riga vuol dire che non c'è stata sovrapposizione temporale e quindi solleva un'eccezione e blocca il programma
    if not righe:
        raise ValueError(
            "Nessuna data in comune tra previsioni e dataset reale. "
            "Controllare il formato delle date (YYYY-MM-DD) e il periodo coperto."
        )

    #costruisce un DataFrame con le informazioni raccole usando le intestazioni contenute in columns
    df_risultato = pd.DataFrame(righe, columns=["DATE", "PREV", "REAL", "ERROR_SIGNED", "ERROR_ABS"])

    # Calcolo degli indicatori di errori su tutte le righe 
    mae = round(df_risultato["ERROR_ABS"].mean(), 2)
    rmse = round(np.sqrt((df_risultato["ERROR_SIGNED"]**2).mean()), 2)
    mbe = round(df_risultato["ERROR_SIGNED"].mean(), 2)
    accuratezza = round(100 - mae, 2)  # non considerata come indicatore standard

    # Stampa a terminale dei risultati
    print(f"\nConfronto {var}:")
    print(df_risultato.to_string(index=False))
    print(f"\nMAE = {mae:.{2}f} °C")
    print(f"RMSE = {rmse:.{2}f} °C")
    print(f"MBE = {mbe:.{2}f} °C")
    print(f"Accuratezza (100 - MAE) = {accuratezza:.{2}f}%")
    
    #ritorna i valori degli indicatori che possono essere usati indipendentemente dalla stampa a terminale.
    return {
        "MAE": mae,
        "RMSE": rmse,
        "MBE": mbe,
        "Accuratezza": accuratezza
    }
