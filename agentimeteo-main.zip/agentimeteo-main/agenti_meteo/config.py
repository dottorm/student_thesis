'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo di Configurazione
Il presente file contiene tutte le informazioni per le impostazioni del sistema. 
Ad esempio, opzioni per la configurazione degli agenti, percorsi dei dataset e dei report, parametri di inferenza del modello
'''



import pandas as pd
import os

# **** Configurazione modello LLM (Ollama) ****
OLLAMA_API_URL = "http://localhost:11434/api/generate" # endpoint per Ollama
  

OLLAMA_MODEL = "mistral"    # modello locale utilizzato di default  
OLLAMA_MODELB = "mistral"   # possibilità di utilizzare un modello secondario dove previsto            
OLLAMA_TEMPERATURE = 0.0   # massimo determinismo
OLLAMA_TOP_P = 0.0    #selezione solo dei token più probabili in base al valore della variabile
OLLAMA_PENALTY = 1.0 #penalizza ripetizione parole o frasi 1.0 di default
OLLAMA_SEED = 42 #valore iniziale per generazione casuale
OLLAMA_NUM_PREDICT = 96 #limite massimo di token generati, evita al sistema di bloccarsi in caso di loop
OLLAMA_NUM_PREDICT_INTERPRETE = 2000   #limite massimo di token generati dall'interprete, evita al sistema di bloccarsi in caso di loop              
# ***** FLAG ATTIVAZIONE MODELLI ****
#Quando impostato su true viene attivata la procedura per utilizzare un determinato modello dalla pagina modelli.py (USA_MISTRAL corrisponde sempre ad OLLAMA_MODEL anche se il modello è diverso, USA_MISTRAL si riferisce sempre al modello locale, gli altri sono modelli in cloud di prova)
USA_MISTRAL=True #mistral 7B (Ollama)



# **** FLAG ATTIVAZIONE AGENTI ****  

#SETTING PER AGENTE TMAX

USA_TMAX = True# attiva/disattiva agente previsioni temperature massime

VERBOSE_TMAX =False #stampa dell'intero prompt agente su terminale
CONFRONTO_TMAX = True #vista tabella confronto con mae e altri indicatori
VISTA_PREDIZIONE_TMAX = True #vista tabella previsione


# SETTING PER AGENTE TMIN

USA_TMIN = True #attiva/disattiva agente previsioni temperature minime

VERBOSE_TMIN = False #stampa dell'intero prompt su terminale
CONFRONTO_TMIN = True #vista tabella confronto con mae
VISTA_PREDIZIONE_TMIN = True #vista tabella previsione


#BARRA DI PROGRESSIONE PREVISIONE
PROGRESSO_TERMINALE=True #percentuale avanzamento prevsione
PROGRESSO_STIMA_SECONDI=20 # velocità avanzamento percentuale


#SETTING PER AGENTE TABELLA FINALE (Agente di sintesi previsioni)

USA_TABFINALE = True  # attiva/disattiva agente tabella finale
VISTA_TABFINALE = True #vista tabella previsione



#INTERPRETE NLP

USA_INTERPRETE = False  #attiva/disattiva agente interprete

VERBOSE_INTERPRETE = False #stampa dell'intero prompt su terminale
GIORNI_STORICO_INTERPRETE = 30  #numero giorni del dataset storico passati all'interprete, l'agente risponde solo sul numero di giorni forniti e sulle previsioni.


#AGENTE REPORT PREVISIONI

USA_REPORT_PREVISIONI = False # attiva/disattiva agente report previsioni

#AGENTE REPORT CONFRONTI
USA_REPORT_CONFRONTI = False # attiva/disattiva agente report confronti



# VARIABILI INIZIALIZZAZIONE SISTEMA PREVISIONALE 
DATA_INIZIO_PREVISIONE = "2010-07-18"  # INDICARE IL GIORNO PRECEDENTE l’inizio delle previsioni ad esempio 2014-08-24 -> inizio previsione 2014-08-25
PREVISIONI_GIORNI = 7 #numero giorni da prevedere
GIORNI_CONTESTO = 25 #numero di giorni di contesto da passare al modello
CITY = 'Roma' # nome luogo previsione
OPERATOR="Ignazio Aita" #operatore per la previsione, compare solo nei report


# PERCORSO DATASET, LOG, REPORT

DATASET_PATH = os.path.join("dataset", "dataset", "dataset_storico.csv")  # dataset storico
MEDIE_FINALI_PATH = os.path.join("dataset", "medie", "medie_mensili_finali.csv")  # valori generati dinamicamente ed usati per la previsione
REAL_PATH = os.path.join("dataset", "confronti", "rilevate.csv")  # valori generati dinamicamente usati per il confronto
PREVISIONI_PATH = os.path.join("dataset", "previsioni", "previsioni.csv")  # risultato previsione a disposizione per gli altri agenti
LOG_PREVISIONI_PATH = os.path.join("dataset", "previsioni", "log_previsioni.txt")  # dati previsionali utili per i report


REPORTS_ROOT = os.path.join("report") #indirizzo della cartella per i report
PREVISIONI_REPORT_DIR = os.path.join(REPORTS_ROOT, "previsioni") #percorso report previsioni
CONFRONTI_REPORT_DIR = os.path.join(REPORTS_ROOT, "confronti")#percorso report confronti


GLOSSARIO_INTERPRETE = os.path.join("dataset", "glossario.txt") #glossario per l'agente interprete




# funzione per il caricamento del datataset storico
def carica_dataset(path): 
    return pd.read_csv(path)

