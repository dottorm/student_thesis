'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo dei modelli
Questo modulo è essenziale per dialogare con il modello.
Contiene la gestione del prompt e della ricezione delle risposte, la definizione dei parametri di inferenza usati i cui valori
sono impostati dal modulo di configurazione.
Attualmente gestisce solo modelli locali tramite OLLAMA, ma può essere usato anche per modelli in cloud.
Tramite Ollama posso utilizzare anche altri modelli, basta cambiare il nome del modello.
'''


import json
import requests
#parametri di configurazione contenuti nel file config
from config import OLLAMA_API_URL, OLLAMA_MODEL, OLLAMA_MODELB, OLLAMA_TEMPERATURE, OLLAMA_TOP_P,OLLAMA_PENALTY,OLLAMA_SEED,OLLAMA_NUM_PREDICT, USA_MISTRAL,OLLAMA_NUM_PREDICT_INTERPRETE
    


#****MODELLI LOCALI ****

# Utilizzo mistral tramite ollama ( in realtà tramite OLLAMA_MODEL posso usare qualsiasi modello supportato da Ollama e dal sistema semplicemente indicandone il nome)
def ollama_llm(prompt: str) -> str: #la funzione prende in ingresso un prompt e restituisce una stringa come rispsota
    payload = {
        "model": OLLAMA_MODEL,
        "options": {
            "temperature": OLLAMA_TEMPERATURE, #risposte casuali o deterministiche
            "top_p": OLLAMA_TOP_P, #selezione solo dei token più probabili in base al valore della variabile
            "repeat_penalty": OLLAMA_PENALTY, #penalizza ripetizione parole o frasi
            "seed": OLLAMA_SEED, #valore iniziale per generazione casuale
            "num_predict": OLLAMA_NUM_PREDICT #limite massimo ditoken generati, evita al sistema di bloccarsi in caso di loop
        },
        "prompt": prompt,
    }
    try:#richiesta al modello di generare la risposta
        #viene inviata al server OLLAMA una richiesta tramite metodo POST all'endpoint indicato in OLLAMA_API_URL_e di seguito
        #riceve una risposta in streming in formato JSON ovvero tramite righe in questo formato
        response = requests.post(OLLAMA_API_URL, json=payload, stream=True) 
        
        risposta = "" #inizializzo stringa vuota
        for line in response.iter_lines(): #itero su ogni riga
            if line: #se non è vuota
                data = json.loads(line.decode("utf-8")) #decodifico la riga JSON
                risposta += data.get("response", "") #compongo il campo risposta
        return risposta.strip() #restituisco risposta ripulita da spazi
    except Exception as e: #errore nel caso ci siano problemi con il modello, esempio mancato avvio di OLLAMA o altri problemi correlati
        return f"Errore nella chiamata LLM: {e}"
    


#blocco dedicato al modello usato dall'interprete 
#si è inserita la possibilità di far usare all'interprete, durante la stessa esecuzione, un modello diverso da quello usato per le prevsione
#Questo da la possibilità di usare anche parametri di inferenza diversi.
#Il blocco funziona esattamente come quello  sopra ma il nome della funzione è diverso.
def ollama_llm_interprete(prompt: str) -> str:
    payload = {
        "model": OLLAMA_MODELB,
        "options": {
            "temperature": OLLAMA_TEMPERATURE, #risposte casuali o deterministiche
            "top_p": OLLAMA_TOP_P, #selezione solo dei token più probabili in base al valore della variabile
            "repeat_penalty": OLLAMA_PENALTY, #penalizza ripetizione parole o frasi
            "seed": OLLAMA_SEED, #valore iniziale per generazione casuale
            "num_predict": OLLAMA_NUM_PREDICT_INTERPRETE #limite massimo ditoken generati, evita al sistema di bloccarsi in caso di loop
            
        },
        "prompt": prompt,
    }
    try: #richiesta al modello di generare la risposta
        response = requests.post(OLLAMA_API_URL, json=payload, stream=True)
        risposta = ""
        for line in response.iter_lines():
            if line:
                data = json.loads(line.decode("utf-8"))
                risposta += data.get("response", "")
        return risposta.strip()
    except Exception as e:
        return f"Errore nella chiamata LLM interprete: {e}"




#*** SELETTORE MODELLI ****
#varibili configurabili da config
# Se presenti più modelli, è possibile usare questi flag per disabilitarli/abilitarli velocemente senza variare il codice di questo file
#Per il lavoro di tesi, è stato dimostrato il funzionamento del sistema utilizzando Mistra7B e quindi al momento è presente un solo selettore.
#ma è possibile inserite tanti flag quanti sono i modelli che vengono usati.

if USA_MISTRAL: #se il flag è True viene utilizzato il blocco
    llm = ollama_llm #associo al nome llm la funzione corrispondente, in questo modo poi nel modulo degli agenti potrò associarlo agli agenti stessi
    llm_interprete = ollama_llm_interprete #associo al nome llm_interprete la funzione corrispondente, in questo modo poi nel modulo degli agenti potrò associarlo all'agente interprete
    LLM_ATTIVO = "Mistral 7B (Ollama)" #questa stringa viene stampata a terminale all'avvio del sistema

else: #se non ci sono llm attivi ritorna questi messaggi informativi
    def llm(prompt): return " Nessun LLM attivo"
    def llm_interprete(prompt): return " Nessun LLM attivo"
    LLM_ATTIVO = "Nessun modello attivo"


def descrizione_llm_attivo(stampa=True) -> str: #stampa a terminale quale modello è attivo, funzione richiamata dal main
   
    messaggio = f"Modello attivo: {LLM_ATTIVO}" #compone il messaggio da visualizzare a terminale
    if stampa: #stampa è sempre true ma si potrebbe inserire un flag in config per attivarla/disattivarla
        print(messaggio) #stampa messaggio solo per controllo non necessario
    return messaggio #ritorna messaggio
