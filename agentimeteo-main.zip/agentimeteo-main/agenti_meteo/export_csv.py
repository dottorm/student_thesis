'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Agenti Meteo
Modulo di esportazione delle previsioni
Il presente file contiene è deputato all'esportazione in un file CSV dei risultati previsionali.
Richiamato dall'agente di sintesi alla fine della generazione della previsione completa
Inoltre lo stesso agente utilizza questo modulo per generare un log contenente diverse informazioni sulla previsione
ad esempio il modello usato, l'orario di previsione, il tempo impiegato dagli agenti per l'elaborazione.
'''

import os
import csv
from datetime import datetime
from config import CITY

#creazione del log contenente informazioni sulle previsioni (richiamato da agente sintesi)
def salva_log_generazione(previsione_csv_path, modello, date_da_prevedere,tempo_tmin_sec=None, tempo_tmax_sec=None):
    
    #estraggo l'ora attuale, in modo da inserirle nel log
    ora_attuale = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    #concatena le date da prevedere separandole con una virgola
    data_prev = ", ".join(date_da_prevedere) if isinstance(date_da_prevedere, list) else str(date_da_prevedere)

   #nome scelto per il log e definizione del percorso
    nome_file_log = "log_previsioni.txt"
    path_log = os.path.join(os.path.dirname(previsione_csv_path), nome_file_log)


   #salvataggio delle informazioni all'interno del fil log 
    with open(path_log, "w", encoding="utf-8") as f:
        f.write(f"Data/Ora generazione: {ora_attuale}\n")
        f.write(f"Modello usato: {modello}\n")
        f.write(f"Periodo previsione: {data_prev}\n")
        f.write(f"File CSV: {previsione_csv_path}\n")

       
        if tempo_tmin_sec is not None:
            f.write(f"tempo previsioni temperature minime: {tempo_tmin_sec:.2f} secondi\n")
        if tempo_tmax_sec is not None:
            f.write(f"tempo previsioni temperature massime: {tempo_tmax_sec:.2f} secondi\n")

        

#salvataggio risultato previsione su file previsioni.csv (agente sintesi)
def salva_tabella_finale_csv(risultati_finali, localita=CITY, cartella="dataset/previsioni",modello="DefaultModel", date_da_prevedere=None,tempo_tmin_sec=None, tempo_tmax_sec=None):
  
  #controllo se esiste la cartelli, altrimenti viene creata
    if not os.path.exists(cartella):
        os.makedirs(cartella)

    # Nome e percorrso file contenente le previsioni
    nome_file = "previsioni.csv"
    percorso_file = os.path.join(cartella, nome_file)
    
    #apre il file csv, se non esiste lo crea, evita righe vuote e scrive le intestazioni
    with open(percorso_file, mode="w", newline="", encoding="utf-8") as file_csv:
        writer = csv.writer(file_csv)
        #scrivo le intestazioni del file
        writer.writerow(["Data", "Località", "TMIN °C", "TMAX °C", "TAVG °C"])


        for riga in risultati_finali:

        #il blocco gestisce eventuali output diversi del modello, nel caso in cui risultati_finali dovesse contenere elementi non previsti evita di fare andare in errore il sistema
         #negli ultimi test il sistema non ha mai risentito di questi tipi di errore, quindi potrbbe essere eliminato per snellire il codice, ma nel caso in cui
         #si vogliano provare modelli diversi può essere un elemento di sicurezza se il modello non rispetta l'output definito nel prompt
         #lo stesso vale per il controllo dei nomi data,tmin,tmax ect....
            # può supportare tuple , list o dict, caso base caso [Data, Tmin, Tmax, Tavg], (da semplificare)
            if isinstance(riga, dict): #caso dizionario
                data = riga.get("Data") or riga.get("data")
                tmin = riga.get("Previsione Tmin") or riga.get("Tmin") or riga.get("tmin")
                tmax = riga.get("Previsione Tmax") or riga.get("Tmax") or riga.get("tmax")
                tavg = riga.get("Previsione Tavg") or riga.get("Tavg") or riga.get("tavg")
                writer.writerow([data, localita, tmin, tmax, tavg])
            elif isinstance(riga, (list, tuple)):#caso lista
                if len(riga) == 5: # se ci sono 5 elementi presumo che [Data,Località,Tmin, Tmax, Tavg]
                    writer.writerow(list(riga))
                elif len(riga) == 4:#se manca località
                    # se non c'è localtià la inserisco al secondo posto
                    data, tmin, tmax, tavg = riga
                    writer.writerow([data, localita, tmin, tmax, tavg])
                else:
                    #se la lunghezza non è 4 oppure 5 forza lo stesso il risultato
                    try:
                        data, tmin, tmax, tavg = riga[0], riga[1], riga[2], riga[3] #prende una riga e seleziona ogni elemento che la compone
                        
                        writer.writerow([data, localita, tmin, tmax, tavg])
                    except Exception:
                        # Se rileva errori, scrivi riga così com'è
                        writer.writerow(list(riga))
            else:
                # Tipo non previsto, se non ho un dict, list, o tupla scrive in una unica colonna il valore
                writer.writerow([riga])

    if date_da_prevedere is not None:
        salva_log_generazione(percorso_file, modello, date_da_prevedere,tempo_tmin_sec=tempo_tmin_sec, tempo_tmax_sec=tempo_tmax_sec)
        #salvataggio delle informazioni nel csv


