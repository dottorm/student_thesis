'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo filtraggio dei campi
Questo modulo raccoglie le funzioni per eliminare campi indesiderati dal dataset.
'''

import pandas as pd
from PySide6.QtWidgets import  QWidget, QVBoxLayout, QPushButton, QFileDialog,QLabel, QListWidget, QListWidgetItem, QMessageBox
from PySide6.QtCore import Qt

class editaColonneCSV(QWidget): #gestione interfaccia 
    def __init__(self):
        super().__init__() #inizializzo classe base
        self.setWindowTitle("Editor CSV - Rimuovi Campi") #titolo modulo
        self.setGeometry(300, 150, 700, 500) #dimensioni
        self.df = None #DataFrame vuoto inizialmente
        self.percorso_file = "" #percorso CSV
        self.init_ui() # costruzione iinterfaccia

    def init_ui(self): #costruzione layout principale
        layout = QVBoxLayout()

        #carica CSV tramite bottone
        self.carica_btn = QPushButton("Carica CSV")
        self.carica_btn.clicked.connect(self.carica_csv)
        layout.addWidget(self.carica_btn)

       
        self.elenco_colonne = QListWidget() #elementi da eliminare elencati tramite checkbox
        layout.addWidget(QLabel("Seleziona i campi da eliminare:"))
        layout.addWidget(self.elenco_colonne)

        
        self.salva_btn = QPushButton("Salva CSV (solo con colonne eliminate)") # Salvataggio del CSV modificato
        self.salva_btn.clicked.connect(self.salva_csv)
        layout.addWidget(self.salva_btn)

        self.setLayout(layout)

    def carica_csv(self): #funzione per il caricamento del csv
        file_dialog = QFileDialog(self)
        file_dialog.setNameFilter("CSV Files (*.csv)")
        if file_dialog.exec(): #dopo la scelta se si conferma la scelta apre il percorso
            self.percorso_file = file_dialog.selectedFiles()[0]
            try:
                self.df = pd.read_csv(self.percorso_file) #apre in un DataFrame tramite pandas
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Impossibile leggere il CSV:\n{e}")
                self.df = None
                return

            #popolo l'elenco delle colonne
            self.elenco_colonne.clear() #svuoto lista
            for col in self.df.columns:
                item = QListWidgetItem(col) #creo lista
                item.setCheckState(Qt.Unchecked) #nessuna selezione iniziale
                self.elenco_colonne.addItem(item)#aggiungo elemento alla lista

    def salva_csv(self): #salvatoggio del file csv con colonne rimosse
        if self.df is None:
            QMessageBox.warning(self, "Errore", "Nessun file CSV caricato.")
            return

        #rimuove solo le colonne selezionate, scandisce la lista ed elimina solo quelle spuntate
        da_rimuovere = [
            self.elenco_colonne.item(i).text()
            for i in range(self.elenco_colonne.count())
            if self.elenco_colonne.item(i).checkState() == Qt.Checked
        ]

        df_mod = self.df.drop(columns=da_rimuovere, errors='ignore') #eliminazione senza generazione di errore se colonne non esistono

        #salvataggio in file csv, con sovrascrittura del precedente
        percorso_s, _ = QFileDialog.getSaveFileName(self, "Salva file CSV", "", "CSV Files (*.csv)")
        if percorso_s:
            try:
                df_mod.to_csv(percorso_s, index=False)
                QMessageBox.information(self, "Successo", "File CSV salvato con successo.")
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Impossibile salvare il CSV:\n{e}")


