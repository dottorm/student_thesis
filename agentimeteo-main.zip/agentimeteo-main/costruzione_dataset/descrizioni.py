'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Descrizioni
Questo modulo contiene alcune descrizioni climatiche della città oggetto della simulazione. Inoltre sono presenti diversi range di valori
per temperatura, vento, pressione, deviazione rumore, picchi ed altro. Questi valori vengono passati al modello per arricchire il prompt
'''

DESCRIZIONI_LOCALITA = {
    "Roma": {
        "nome_completo": "Roma, Italia",
        "coordinate": {"latitudine": 41.890210, "longitudine": 12.490007},# Colosseo
        "altitudine_m": 21,
        "zona_climatica": "Clima tipico delle regioni costiere dell'Italia centrale, con inverni miti e umidi ed estati calde e asciutte.",
        "macro_area": "Italia Centrale - Area costiera del versante tirrenico",

        "descrizione_climatica": (
            "Roma ha un clima mite per la maggior parte dell'anno. "
            "Gli inverni sono piuttosto umidi ma raramente troppo freddi, con temperature che di rado "
            "scendono sotto lo zero. Le estati sono calde e soleggiate, con giornate asciutte "
            "e temperature che spesso superano i 30 gradi. Le precipitazioni sono maggiormente concentrate "
            "tra l'autunno e l'inizio della primavera, mentre i mesi estivi sono per lo più secchi. "
            "L'umidità resta moderata per gran parte dell'anno e la pressione atmosferica è stabile."
        ),

        "parametri_medi": { #valori stimati
           
          
            "temperatura_media_annua": [16.0, 18.0], #in °C
            "ampiezza_termica_annuale": [8.0, 10.0],
            
            "pressione_media_annua": [990.0, 1005.0], #in millibar valore calibrato per avere un pressione coerente con le temperature
            
            "variazione_stagionale_pressione": [0.5, 2.0], #indica quanto varia mediamente la pressione atmosferica nel corso dell'anno
            # tra pressione più alta e quella più bassa

            "umidita_media_annua_percento": [65.0, 75.0], # in %

            "velocita_media_vento_kmh": [0.0, 16.0],
            "moltiplicatore_raffica": [2.0, 5.8], #fattore moltiplicativo che serve per calcolare le raffiche a partire dal vento medio

           "visibilita_km": [2.5, 16.0],


           #dati per il modello per la generazione di eventi casuali
            "deviazione_rumore_range": [0.10, 0.50],  #generatore di rumore per la variabilità dei valori per i singoli giorni
            "percentuale_nan_range": [0.000, 0.005],    #percentuale di valori NaN in tutto il dataset per simulare buchi
            "percentuale_picchi_range": [0.000, 0.010], #percentuale di picchi, ovvero esempi isolati 
            "intensita_picchi_range": [2.0, 6.0],         #intensità dei picchi

            #questi due parametri servono a simulare il cambiamento climatico, facendo in modo che le temperature salgano e l'umidità scenda
            #avendo osservato il clima reale sembra un andamento coerente con la realtà
            "deriva_t_annua_range": [0.06, 0.08],   # range per la temperatura
            "deriva_rh_annua_range": [-0.6, -0.2],  # range per l'umidità
    
        }

       

        
        
    }
}
