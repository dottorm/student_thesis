'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Simulatore
Questo modulo è il cuore del processo di simulazione. Raccoglie tutte le regole necessarie per simulare le variabili atmosferiche
'''

import numpy as np
import pandas as pd
import os
from datetime import datetime

LOCALITA_FISSA = "Roma" #località predefinita per ora unica scelta
GIORNO_PICCO_T = 200 #segna il giorno di calendario in cui per il simulatore cade il picco estivo (19 luglio) ovvero il giorno più caldo
GIORNO_PICCO_P = 15 # segna il giorno in cui cade il massimo valore stagionale di pressione, ovvero il 15 gennaio (ipotesi inizio inverno metà mese)


#calcola le stagioni astronomiche in funzione delle date convenzionali, Inverno, Estate etc
def stagioni_convenzionali(d):
    
    m, g = d.month, d.day #estrae mese e giorno
    if (m == 12 and g >= 21) or m in (1, 2) or (m == 3 and g < 21):
        return "Winter"
    elif (m == 3 and g >= 21) or m in (4, 5) or (m == 6 and g < 21):
        return "Spring"
    elif (m == 6 and g >= 21) or m in (7, 8) or (m == 9 and g < 23):
        return "Summer"
    elif (m == 9 and g >= 23) or m in (10, 11) or (m == 12 and g < 21):
        return "Autumn"


#calcolo punto rugiada tramite temperatura e umidità relativa
def dewpoint_c(t_c: float, rh_pct: float) -> float:
    # mi assicuro che l'umidità relativa stia dentro limiti naturali
    rh = max(1.0, min(100.0, float(rh_pct)))
    return float(t_c) - (100.0 - rh) / 5.0 
# applico formula T - (100 - UR)/5 dove T= temperatura e UR umidità relativa


#arrotonda valori senza però considerare i NaN e rispetta le condizioni
def arrotonda_intero(x):
    return np.where(np.isnan(x), np.nan, np.round(x)).astype(float) 


def genera_dati(p):
    # parametri passati dall'agente e definiti in descrizioni.py
    inizio, fine, seme = str(p["start"]), str(p["end"]), int(p["seed"]) #seme per generazione
    t_media_annua, t_ampiezza = float(p["t_media_annua"]), float(p["t_amp"])
    p_media, p_ampiezza = float(p["p_media"]), float(p["p_amp"])
    #il valore della pressione che arriva dal modello è di norma troppo alto, così lo decremento di un fattore costante 4.5
    p_media = p_media - 4.5  
    sigma_rumore = float(p["deviazione_rumore"]) #deviazione standard del rumore, additiva
    perc_nan = float(p["percentuale_nan"]) #percentuale di valori NaN sul totale
    perc_picchi = float(p["percentuale_picchi"]) #percentuale di giorni con picchi termici
    amp_picchi = float(p["intensita_picchi"]) #intensità dei picchi

    #range passati dal modello, rappresentano due valori, un minimo ed un massimo
    v_min, v_max = p["velocita_media_vento_kmh"]
    mol_raff_min, mol_raff_max = p["moltiplicatore_raffica"]
    vis_min, vis_max = p["visibilita_km"]
    u_min, u_max = p["umidita_media_annua_percento"]

    #creazione della serie con variabile inizio e fine e frequenza giornaliera
    date = pd.date_range(inizio, fine, freq="D") 
    #numero di giorni simulati, passando il parametro date definisco tutto il periodo
    n = len(date) 
   
    #estrae i giorni'anno
    giorno_anno = date.dayofyear.values 

    #mesi = date.month.values
    
    #array contenente gli anni per ciascun giorno
    Y = pd.DatetimeIndex(date).year.values 
    #ricava gli anni unici e per ogni giorno e li salva in Yunique, invece idx è un array di interi
    # che fa corrispondere ogni giorno giorno all'indice di Yunique al quale appartiene
    #esempio se le date sono ad esempio Y=[2010,2010,2010, .... 2011,2011....2012,2012]
    # Yunique = [2010,2011,2012]  idx=[0,0,0,1,1,2,2], giorni associati ad ogni anno unico
    #in questo modo posso applicare successivamente offset o modifiche specifiche per ogni anno
    Yuniq, idx = np.unique(Y, return_inverse=True) 

 
    # Variazione casuale annuale per rompere la ripetitività per la temperatura
    #a parità di periodo faccio cambiare le temperature se no sarebbero uguali anno per anno
    #si è reso necessario perchè se no a parità di mese dell'anno, per anni diversi, le temperature
    #sarebbero state quasi uguali.Quindi variazione casuale del clima tra un anno ed un altro

    #creo un dizionario che associa un valore random da sommare alla temperatura di quell'anno
    variazione_annuale = {a: np.random.normal(0.0, 0.8) for a in Yuniq}  # 0.0 è la maedia +o-0.8 °C deviazione standard
    #ricreo un array di date in cui ogni giorno prende l'offset dell'anno corrispondente.
    offset_annuale = np.array([variazione_annuale[a] for a in pd.DatetimeIndex(date).year])
    
    #creo un valore casuale partendo dallo stesso seme dato dal modello
    #ed aggiungo un numero in questo caso 77, per differenziarlo dagli altri generatori
    rng_var = np.random.default_rng(seme + 77)

    #ognuna delle seguenti variabili genera tanti valori casuali quanti sono gli anni unici
    #ogni anno ha così un offset tra la media esempio 0.0 e la deviazione standard esempio 2.0
    #dopo con idx associa quell'offset ad ogni giorno dell'anno
    offH  = rng_var.normal(0.0, 2.0, size=Yuniq.size)[idx]   #+o-2% umidità relativa
    offV  = rng_var.normal(0.0, 0.6, size=Yuniq.size)[idx] # +o-0.6 km/h vento medio
    offG  = rng_var.normal(0.0, 1.0, size=Yuniq.size)[idx]  # +o-1.0 km/h raffiche
    offVIS= rng_var.normal(0.0, 0.3, size=Yuniq.size)[idx]  # +o-0.3 km visibilità

    
   
    # calcolo delle derive annuee ovvero incrementi di temperatura per ogni anno e decrementi di umidità per cercare di simulare un lieve cambiamento climatico
    # i valori medi soggetti a deriva variano di quel valore ogni anno, e si accumulano di anno in anno
    # valore della deriva presa dal modello (temperatura), ne non è presente uso 0.07 come predefinito
    deriva_t = float(p.get("deriva_t_annua", 0.07))  
    #  valore della deriva presa dal modello (umidità relativa), ne non è presente uso -0.25 come predefinito
    deriva_rh = float(p.get("deriva_rh_annua", -0.25))  
    
    #genertori pseudo casuali per le derive
    rng = np.random.default_rng(seme + 5) 
    rng_p = np.random.default_rng(seme + 7)


    # Offset annuo (anni mediamente più alti/più bassi) per le pressioni
    #genera l'offset per gli anni unici e poi tramite idx lo riporta sui giorni di quell'anno
    p_offset_year = rng_p.normal(0.0, 1.2, size=Yuniq.size)
    p_offset = p_offset_year[idx]

    # viste le variazioni annuali, questo codice sposta il picco di pressione stabilito all'inizio con GIORNI_PICCO_P
    # quindi tramite idx si associa ad ogni giorno un picco per il suo anno
    # questo serve per simulare la variabilità stagionale diversa per ogni anno
    p_phase_shift_year = rng_p.integers(-5, 6, size=Yuniq.size) #oscilla tra -5 e +5 limitato a 6 che non esce mai
    p_phase = GIORNO_PICCO_P + p_phase_shift_year[idx]

   

    # calcol della deriva annua distribuita su ogni giorno

    #variabilità tra gli anni sono le deviazioni standard risptto alle derive date dal modello
    #ovvero quanto variano le derive di anno in anno rispetto ai valori deriva_t e deriva_rh
    std_t, std_rh = 0.05, 0.40 

    #derive generate per gli i-esimi anni 
    dT_year  = rng.normal(deriva_t,  std_t,  size=Yuniq.size) #Yunuq.size rappresenta il numero di anni distinti a cui applicare la deriva
    dRH_year = rng.normal(deriva_rh, std_rh, size=Yuniq.size)

    # questa parte simula un effetto accumulo per ogni anno che si ripercuote sugli anni successivi somma gli offset per ogni anno
    # esempio se ho una deriva per gli anni unici del tipo [0.11,0.04,0.09] avrò poi il seguente effetto accumulo [0.11,0.15,0.24]
    #il primo anno parte senza accumulo
    offT  = np.concatenate(([0.0], np.cumsum(dT_year)[:-1])) #[:-1] accumula fino ad anno precedente
    offRH = np.concatenate(([0.0], np.cumsum(dRH_year)[:-1]))

    #stabilisco quanto dell'anno è già trascorso 0.0 inizo anno 1.0 fine anno, in modo da distribuire piano piano su ogni giorno la deriva
    #estraggo inizialmente il numero progressivo del giorno
    giorno_a  = pd.DatetimeIndex(date).dayofyear.values.astype(float)  
    #costruisco un array con il numero di giorni pere ogni anno                                                           
    dimY = pd.to_datetime([f"{y}-12-31" for y in Y]).dayofyear.to_numpy(dtype=float) 
    # questo torna quindi la frazione dell'anno che non è mai negativa grazie a clip                                                            
    frac = (giorno_a - 1.0) / np.clip(dimY, 1.0, None) 
    # per esempio giorno_a =1, dimY = 365, frac 0.000 oppure giorno_a = 182, dimY = 365, frac = 0.496
    #frac è la percentuale decimale della deriva totale fino a quel determinato giorno

    # derive giornaliere finali con tutti i componenti
    deriva_T_giornaliera  = offT[idx]  + dT_year[idx]  * frac
    deriva_RH_giornaliera = offRH[idx] + dRH_year[idx] * frac

    #**** modello armonico per la variazione termica ****
    #simulo andamento giornaliero delle temperature tramite una curva cosinusoidale che rappresenta l'andamento medio delle temperature durante l'anno
    #più alte in estate più basse in inverno, funzione di Numpy - t_base è un array
    #tbase è un array lungo quanto tutto il dataset
    t_base = t_media_annua + t_ampiezza * np.cos(2 * np.pi * (giorno_anno - GIORNO_PICCO_T) / 365.25) #365.25 è il valore per un anno solare reale
    #tbase è data dalla formula che comprende la temperatura media annuale, l'ampiezza dell'osscillazione delle temperature
    #np.cos funzione coseno che in questo caso parte da 1 scende a -1 e ritorna a +1 dopo una rotazione di 360°, quindi la parte dentro
    #np.cos serve a trasformare i giorni in angoli. Considerando che il coseno parte da 0 radianti giorno_anno - GIORNO_PICCO_T sposta il massimo della curva nel giorno di picco giusto 
    #se non lo avessi fatto sarei partito dal primo gennaio(cos(0)=1), si sarebbero invertite le stagioni quindi per sistemare il problema si è usato giorno_anno - GIORNO_PICCO_T
     #e a spostare il punto di massimo della curva al giorno corretto.
    #inoltre la funzione converte i giorni dell’anno in angoli, la divisione per 365.25 trasforma il giorno in frazione di anno e  moltiplicare per 2pi converte la frazione in radianti
     
    #nel concreto la funzione parte dal picco massimo, cioè dai valori più alti di temperatura (estate),
    #poi il coseno diminuisce fino a raggiungere il minimo in inverno e successivamente risale,
    # simulando l’alternarsi stagionale delle temperature durante l’anno
  
    
    #sposto di 4.5 gradi in basso la tbase e aggiungo l'offset annuale e rumore casuale per rendere diversi i  giorni tra loro media =0 deviazione 1°C n=numero di giorni
    tmin = t_base - 4.5 + offset_annuale + np.random.normal(0.0, 1.0, n) #più il valore numerico (4.5 in questo caso) è grando più le temp min diminuiscono
    # come sopra ma sposto in alto di 4.2 e calcolo tmax
    tmax = t_base + 4.2 +  offset_annuale + np.random.normal(0.0, 1.0, n) #più il valore numerico (4.2 in questo caso) è grando più le temp max aumentano

    # deriva climatica per simulare riscaldamento globale
    tmin = tmin + deriva_T_giornaliera  #applico incremento annuale "deriva"
    tmax = tmax + deriva_T_giornaliera #applico incremento annuale "deriva"
  
    # creo una dipendenza tra la pressione e la temperatura
     #determina quanto la pressione varia con la temp media, il valore negativo significa che se la temperatura aumente la pressione diminusice
    alpha_p = -0.40
    tavg_sim = 0.5 * (tmin + tmax) #calcolo temp media
    #calcolo l'effetto sulla pressione ad esempio se la giornata è più calda della media, la pressione diminuisce di quel fattore negativo e viceversa
    p_temp_effect = alpha_p * (tavg_sim - t_media_annua)
    
    #genero rumore casuale per ogni giorno usando sempre media e deviazione standard
    rumore_p = rng_p.normal(0.0, 1.2, len(date))
    #calcolo la pressione usando lo stesso modello usato per le temperature applicando le altre variabili che ne influenzano l'andamento
    pressione = (p_media + p_offset)  + p_ampiezza * np.cos(2 * np.pi * (giorno_anno - p_phase) / 365.25) + p_temp_effect + rumore_p

    #faccio in modo di rendere più regolare la curva con meno picchi.
    # prima converto l'array in una serie pandas e poi uso una media mobile su 3 giorni centrata per calcolare il valore del giorno considerato
    pressione = pd.Series(pressione).rolling(3, center=True, min_periods=1).mean().to_numpy() 
    #verifico che la variabile esista e sia un array numpy, inserito come controllo a causa di alcuni errori
    assert 'pressione' in locals() and isinstance(pressione, np.ndarray), "pressione non definita"
    #print("DEBUG pressione:", pressione[:3]) # stampo le prime tre righe
    
    #creazione del DataFrame con le informazioni ricavate, con il calcolo di TAVG
    df = pd.DataFrame({
        "DATE": date,
        "LOCATION": LOCALITA_FISSA,
        "TMIN °C": tmin,
        "TMAX °C": tmax,
        "TAVG °C": (tmin + tmax) / 2,
        "PRESSURE mb": pressione
    }) 

    # aggiungo rumore per simulare dinamismo nelle previsioni
    if sigma_rumore > 0: #se la deviazione standard del rumore è >0
       #generatore rumore
        gen_rumore = np.random.default_rng(seme + 10) 
        #ciclo su tutte le colonne per ogni giorno e aggiungo rumore casuale tramite un generatore normale con media 0.0 e deviazione standard = sigma rumore
        for c in ["TMIN °C", "TMAX °C", "TAVG °C"]:
            df[c] += gen_rumore.normal(0.0, sigma_rumore, n) 

    # aggiunta di picchi artificiali per simulare sbalzi termici ( fenomeni impulsivi ed isolati non legati alla stagione)
    # calocolo numero di picchi da inserire usando n numero giorni e percentuale picchi impostato dal sistema
    k_pic = int(round(n * perc_picchi))
    if k_pic > 0 and amp_picchi > 0: #se ci sono picchi  e l'ampiezza è >0
        gen_picchi = np.random.default_rng(seme + 20) #generatore casuale 
        for c in ["TMIN °C", "TMAX °C"]: #cicla su colonne
            #scelgo il numero giorni a cui dare i picchi
            idx = gen_picchi.choice(n, size=min(k_pic, n), replace=False) 
            #n=giorni, k_pic=numero picchi ovvero giorni da alterare,
            #  size=min(k_pic, n) serve per garantire che K_pic non superi il numero di giorni del dataset, replace=Fase evita ripetizioni
            #sceglie se avere un picco negativo o positivo len(idx) numero di giorni selezionati per il picco
            segno = gen_picchi.choice([-1, 1], size=len(idx)) 
            #aggiunge o sottrae alle righe contrassegnate con idx nella colonna scelta il valore  amp_picchi moltiplicato per -1 oppure 1
            df.loc[df.index[idx], c] += segno * amp_picchi 

   
    # genero dei valori NaN per simulare errori o buchi nelle rilevazioni, come avviene nella realtà

    #sceglie alcuni giorni e azzera i valori mettendo NaN in temperature e/o pressione
    k_nan = int(round(n * perc_nan)) #numero di giorni che avranno un valore mancante
    if k_nan > 0: #se maggiore di 0
        gen_nan = np.random.default_rng(seme + 30) #generatore per NaN
        #scegli a quali giorni applicare, stesso funzionamento dei picchi
        giorni_nan = gen_nan.choice(n, size=min(k_nan, n), replace=False) 
        variabili_nan = ["TMIN °C", "TMAX °C", "PRESSURE mb"] #colonne a cui poter applicare il NaN
      
        for g in giorni_nan:
            #scelta della cella e colonna a cui applicare il NaN
            df.at[df.index[g], variabili_nan[gen_nan.integers(0, len(variabili_nan))]] = np.nan 
             #df.at[] modifico cella, df.index[] trsformo un etichetta in idice se g=1 df.index[g]="2010-01-02"
             #variabili_nan[gen_nan.integers(0, len(variabili_nan))] sceglie colonna casuale tra TMIN, TMAX e PRESSURE grazie al numero random che esce fuori
 
 
    # questo blocco fa si che le temperature restino coerenti tra loro dopo l'inserimento del rumore
    df["TMIN °C"] = np.minimum(df["TMIN °C"], df["TMAX °C"]) #temperatura minima non deve superare la massima scandisce array e se la minima è superiore alla massima le inverte
    df["TMAX °C"] = np.maximum(df["TMIN °C"], df["TMAX °C"]) #La massima non deve essere minore della minima, funziona come sopra
    ok = df["TMIN °C"].notna() & df["TMAX °C"].notna() #individua le righe in cui entrambi i valori non sono NaN è un booleano
    df.loc[ok, "TAVG °C"] = 0.5 * (df.loc[ok, "TMIN °C"] + df.loc[ok, "TMAX °C"]) # calcola le temp medie solo per le righe valide ovvero dove ok è True
    df.loc[~ok, "TAVG °C"] = np.nan # operatore bitwise (~) selezione in questo caso le righe dove manca almeno un dato tra TMIN e TMAX e mette NaN in TAVG

    
    # GENERO LE ALTRE VARIABILI

    gen = np.random.default_rng(seme + 99) #genero numeri casuali

    #aggiungo colonna SEASON_NAME per tutte le date simulate inserendo il valore corrispondente di stagione
    #creo un nuovo DataFrame e ciclo su ogni giorno richiamando la funzione per la conversione dei giorni in stagioni
    df["SEASON_NAME"] = [stagioni_convenzionali(d) for d in date] 

    # genero un numero casuale uniforme tra i due range u_min e u_max e creo un valore base per l'umidità
    u_base = gen.uniform(u_min, u_max)  
    # questa riga genera l’andamento giornaliero dell’umidità relativa (%) 
    u = u_base + 8.0 * np.cos(2 * np.pi * (giorno_anno - 30) / 365.25) + gen.normal(0.0, 3.0, n) 
    #stessa formula vista per le temperature e la pressione con parametri diversi
    #u_base= valore base umidità. 8.0 mi dice di quanti punti percentuale l'umidità varia mediamente tra valori minimi e massimi rispetto a u_base il valore è una stima arbitraria di compromesso
    # cos(...) simula la salita o la discesa dell'umidità in base alla stagione. (giorno_anno - 30) / 365.25 indica quando l'umidità ha un picco in basso o in alto
    # gen.normal(0.0, 3.0, n) aggiunge variazioni casuali giornaliere con medi  0.0 e deviazione standard 3.0

    #aggiunge la deriva annuale dell'umidità esattamente come fatto per la temperatura
    u = u + deriva_RH_giornaliera + offH 

    # pone un limite all'umidità in percentuale,deve restare entro quei valori 
    u = np.clip(u, 20.0, 100.0) 
    df["HUMIDITY %"] = np.round(u).astype(float) #arrotonda i valori all'intero più vicino e salva i valori nella colonna corrispondente per ogni giorno
 
    #genero il vento medio per ogni giorno, n valori casuali, uno per giorno
    vento_medio = gen.normal((v_min + v_max) / 2.0, max(1.0, (v_max - v_min) / 6.0), n)
    #v_min + v_max) / 2.0 media range del vento tipico - (v_max - v_min) / 6.0 deviazione standard - max(1.0, garantisce che la deviazione sia almeno 1kmh - n lunghezza dataset ovvero numero giorni
    #uso 6.0 perchè rappresenta 1/6 dell'intervallo così il 99% dei valori cadrà dentro itervallo v_min,v_max
   
    #il vento medio non può essere negativo, forzo i valor negativi a diventare 0, None= nessun limite superiore   
    vento_medio = np.clip(vento_medio + offV, 0.0, None) 
    df["WINDAVG km/h"] = np.round(vento_medio).astype(float) #salvo i valori arrotondati nella colonna corrispondente

    
    
    # inserimento di anomalie controlla aggiunte a circa il 3% dei giorni
    #si cerca di simulare fenomeni tipici stagionali che alterano anche più variabili insieme

    gen_anom = np.random.default_rng(seme + 200) #generatore numeri asuali
    #ciclo su ogni riga del DataFrame alla ricerca del nome della stagione
    for i, riga in df.iterrows():
        stagione = riga["SEASON_NAME"].lower() 

        # probabilità evento anomalo, se il numero random è < di 0.03 viene inserita un'anomalia
        if gen_anom.random() < 0.03:  
            if stagione == "winter":
       #se la stagione è inverno, avrò circa il 60% dei casi di abbassare le temperature 
       # se no ho la restante possibilitò di abbasare la pressione          
                if gen_anom.random() < 0.6:
                    df.at[i, "TMIN °C"] -= gen_anom.uniform(2, 6)
                    df.at[i, "TMAX °C"] -= gen_anom.uniform(2, 6)
                else:
                    df.at[i, "PRESSURE mb"] -= gen_anom.uniform(8, 15)

            elif stagione == "summer": #se siamo in estate
            #simula ondata di calore oppure alta pressione. Nel caso di ondata di calore scende anche la pressione
           #se il numero random è < 0.7 alza tmin e tmax di un valore compreso nei range, 
           # fa lo stesso con Humidity però abbassandola, se >0.7 agisce sulla pressione in millib
                if gen_anom.random() < 0.7:
                    df.at[i, "TMAX °C"] += gen_anom.uniform(4, 8)
                    df.at[i, "TMIN °C"] += gen_anom.uniform(2, 5)
                    df.at[i, "HUMIDITY %"] -= gen_anom.uniform(10, 20)
                else:
                    df.at[i, "PRESSURE mb"] += gen_anom.uniform(6, 12)

            elif stagione == "spring":
                # simulo sbalzi termici e rinforzo del vento
                #se <0.5 agisce abbassando TMIN e alzzando TMAX, altrimenti agisce sul vento
                if gen_anom.random() < 0.5:
                    df.at[i, "TMIN °C"] -= gen_anom.uniform(3, 6)
                    df.at[i, "TMAX °C"] += gen_anom.uniform(3, 6)
                else:
                    df.at[i, "WINDAVG km/h"] += gen_anom.uniform(10, 20)

            elif stagione == "autumn":
                # vengono simulati momenti di nebbia o forte umidità e passaggi di bassa pressione
                # agisce sull'umidità se <0.5 se no sulla pressione abbassandola
                if gen_anom.random() < 0.5:
                    df.at[i, "HUMIDITY %"] += gen_anom.uniform(10, 20)
                
                else:
                    df.at[i, "PRESSURE mb"] -= gen_anom.uniform(5, 10)

        #tutti i valori tra parentesi rappresentano un range all'interno del quale estrarre un valore
        #i range sono stati definiti empiricamente



    # controllo correttezza dei vincoli delle variabili

    df["HUMIDITY %"] = df["HUMIDITY %"].clip(20, 100) #limita nel range 20-100
    df["WINDAVG km/h"] = df["WINDAVG km/h"].clip(lower=0) #mi assicuro che il valore del vento non sia <0
    df["TMIN °C"], df["TMAX °C"] = np.minimum(df["TMIN °C"], df["TMAX °C"]), np.maximum(df["TMIN °C"], df["TMAX °C"]) #Tmin sempre < Tmax
    ok2 = df["TMIN °C"].notna() & df["TMAX °C"].notna() #ricavo i giorni validi senza NaN
    df.loc[ok2, "TAVG °C"] = 0.5 * (df.loc[ok2, "TMIN °C"] + df.loc[ok2, "TMAX °C"]) #ricalcolo Temp media
    df.loc[~ok2, "TAVG °C"] = np.nan #aggiungo NaN alla temperatura media se mancano Tmin o Tmax


    

    # Raffiche e visibilità (dipendono anche da anomalie)
    #moltiplica per ogni giorno vento medio per il valore casuale generato nell'intervallo di raffiche
    raffiche = vento_medio * gen.uniform(mol_raff_min, mol_raff_max, n)
    #applico un offset e faccio in modo che i valori siano >0
    raffiche = np.clip(raffiche + offG, 0.0, None) 
    # Azzera raffiche nell'90% dei giorni, valore stimato osservando andamento reale
    azzera_raffiche = gen.random(n) < 0.9
    raffiche[azzera_raffiche] = 0

    # Raffiche forti nel 1% dei giorni usando dei moltiplicatori arbitrari
    #crea un array lungo n dove 1% dei giorni sarò true ovvero avranno raffiche forti
    raffiche_forti = gen.random(n) < 0.01
    raffiche[raffiche_forti] *= gen.uniform(1.8, 2.5, size=raffiche_forti.sum()) #size=raffiche_forti.sum() ovvero il numero di True in raffiche forti
    df["GUST km/h"] = np.round(raffiche).astype(float)  #arrotonda e salva i valori

    #calcolo la visibilità, aumenta se diminuisce l'umidità e viceversa
    vis = vis_max - (df["HUMIDITY %"].to_numpy() - 60.0) * 0.06 + gen.normal(0.0, 0.8, n) 
    #base 60% umidità, ogni +1% di umidità la visibilità scende di 0.06km e viceversa
    #infine aggiungo rumore casuale

    #fisso un range dentro il quale i valori devono stare e salvo nella colonna
    vis = np.clip(vis + offVIS, vis_min, vis_max)
    df["VISIBILITY km"] = np.round(vis, 1)

   #caloclo del punto di rugiada DEWPOINT

    temp_media = df["TAVG °C"].to_numpy() #creazione array temp media
    umidita = df["HUMIDITY %"].to_numpy() #creazione array umidità

    #creo una lista vuota per accumulare i risultati
    valori_dewpoint = []

    for t, h in zip(temp_media, umidita): #zip combina due array in coppie per ogni giorno i valori di temp_media e umidità (t e h nel ciclo)
        # Controlla che entrambi siano numerici e non NaN
        if np.isfinite(t) and np.isfinite(h): #se non sono NaN
           valore = dewpoint_c(t, h)  # Calcola il punto di rugiada tramite la funzione apposita
        else:
          valore = np.nan       # Se uno dei due manca, metti NaN
        valori_dewpoint.append(valore) #aggiungi alla lista
     #Converti la lista in array NumPy
    dp = np.array(valori_dewpoint) #array di dewpoint per ogni giorno del dataframe
    df["DEWPOINT °C"] = arrotonda_intero(dp) #salvataggio in colonna

    # creazione di fenomeni particolari in base alla stagione e alle variabili
    #crea fenomeni testuali come ad esempio pioggia, neve, nebbia oppure none se non ci sono fenomenti rilevanti
    fenomeni = []
    for tmin_val, tmax_val, hum, vis_km, vento_kmh, nome_stagione in zip(
        df["TMIN °C"], df["TMAX °C"], df["HUMIDITY %"], df["VISIBILITY km"],
        df["WINDAVG km/h"], df["SEASON_NAME"]
        #tramite zip scorro le colonne e per ogni giorno prendo i valori di interesse
    ):
        stagione = str(nome_stagione).lower()
        #in funzione delle stagioni e delle combinazioni di valori attribuisco un fenomeno preciso
        if stagione == "summer":
            if hum > 85 and vis_km < 6:
                p = "nebbia"
            elif hum > 70 and vis_km < 8:
                p = "pioggia"
            elif hum > 75 and vento_kmh > 25 and tmax_val > 26:
                p = "pioggia e temporale"
            elif tmax_val > 28 and hum > 60 and vento_kmh > 20:
                p = "temporale"
            elif 15 <= tmax_val <= 25 and hum > 70 and vento_kmh > 25:
                p = "grandine"
            elif hum > 70 and vis_km < 10:
                p = "pioggia"   
            else:
                p = "none"

        elif stagione == "winter":
            if tmin_val < 0 and hum > 80:
                p = "neve"
            elif hum > 85 and vis_km < 8:
                p = "nebbia"
            elif hum > 80 and vis_km < 6 and tmin_val < 5:
                p = "pioggia e nebbia"
            elif hum > 75 and tmin_val < 10:
                p = "pioggia"
            elif hum > 60 and vis_km < 10:
                p = "nuvoloso"
            else:
                p = "none"

        elif stagione == "spring":
            if hum > 85 and vis_km < 7 and tmin_val < 8:
                p = "pioggia e nebbia"
            elif hum > 75 and vento_kmh > 25 and tmax_val > 20:
                p = "pioggia e temporale"
            elif 15 <= tmax_val <= 25 and hum > 70 and vento_kmh > 20:
                p = "temporale"
            elif hum > 70 and tmin_val < 10:
                p = "pioggia"
            elif hum > 70 and vis_km < 10:
                p = "pioggia"   
            else:
                p = "none"

        elif stagione == "autumn":
            if hum > 85 and vis_km < 6:
                p = "nebbia"
            elif hum > 75 and tmin_val < 10 and vis_km < 8:
                p = "pioggia"
            elif hum > 80 and vento_kmh > 20 and tmax_val > 18:
                p = "pioggia e temporale"
            elif hum > 80 and vis_km < 7:
                p = "pioggia e nebbia"
            elif hum > 60 and vis_km < 10:
                p = "nuvoloso"
            else:
                p = "none"

        fenomeni.append(p) #salvo riga per riga nella lista fenomeni

    df["PHENOMENA"] = fenomeni #attribuisco il valore alla riga corrispondente
    
# -------------------------------------------------------------------------------

    for c in ["TMIN °C", "TMAX °C", "TAVG °C", "PRESSURE mb"]: #arrotondo i valori
        df[c] = arrotonda_intero(df[c]) #salvo i valori

    return df #ritorno il DataFrame

def salva_csv(df): #salvo il risultato
    os.makedirs("output", exist_ok=True) #crea directory output e exist_ok=true serve per evitare errori se la cartella già esiste
    nome = f"output/dati_simulati_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv" #compone il nome del file'
    cols = [
        "DATE", "LOCATION", "SEASON_NAME",
        "TMIN °C", "TMAX °C", "TAVG °C", "PRESSURE mb",
        "WINDAVG km/h", "GUST km/h", "VISIBILITY km", "HUMIDITY %", "DEWPOINT °C", "PHENOMENA"
    ] #definisce l'ordine delle colonne da salvare
    df[cols].to_csv(nome, index=False, na_rep="NaN") 
    #esporta in csv, nome=percorso, index = False non inserisce l'incide pandas, na_rep scive esplicitamente NaN se mancano valori
    return nome #restituisce nome percorso
