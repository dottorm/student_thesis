'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Decomposizione Stagionale
Questo modulo applica la decomposizione stagionale alle variabili termiche della serie temporale. Usa la funzione seasonal_decompose di statsmodels
'''

import pandas as pd
import os
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton,QFileDialog, QTextEdit, QMessageBox
from statsmodels.tsa.seasonal import seasonal_decompose


 #classe per la gestione dell'interfaccia', inizializzazione, dimensioni,titolo
class decomposizione(QWidget):
    def __init__(self): 
       
        
        super().__init__()
        self.setWindowTitle("Decomposizione Stagionale delle Temperature")
        self.setMinimumSize(700, 500)
 
       # creazione del layout, etichette e dei pulsanti
        self.layout = QVBoxLayout()
        self.label = QLabel("Carica un file CSV")
        self.carica_btn = QPushButton("Carica CSV e Applica Decomposizione")
        self.log_output = QTextEdit() #finestr di log
        self.log_output.setReadOnly(True) #sola loettura
        
       #inserimento dei componenti nel layout
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.carica_btn)
       
        self.layout.addWidget(self.log_output)
        self.setLayout(self.layout)

        self.carica_btn.clicked.connect(self.caricamento_decomposizione) #pulsante per avvio decomposizione
        

    
    #carica il dataset in formato csv e applica la seasonal_decompose della libreria statsmodels
    def caricamento_decomposizione(self): 
        percorsp, _ = QFileDialog.getOpenFileName(self, "Seleziona un file CSV", "", "CSV Files (*.csv)") #scelta csv
        if percorsp:
            try: #verifiche se il percorso è giusto e se nel dataset è presente la colonna DATE
                df = pd.read_csv(percorsp)

                if 'DATE' not in df.columns:
                    raise ValueError("Il file deve contenere una colonna 'DATE'.")
                #trasformo data in oggetto datetime 
                df['DATE'] = pd.to_datetime(df['DATE']) 
                df.set_index('DATE', inplace=True) #la imposta come indice 

                #lista per memorizzare eventuali campi del log
                campi_log = [" Decomposizione in corso...."] 
                #scelta dei campi da decomporre
                campi = ['TAVG °C', 'TMIN °C', 'TMAX °C']
                modificato = False #var booleana, verifica se almento una decomposizione è stata fatta

                #questo ciclo è la parte che effettivamente che si occupa della decomposizione su tutto il dataset
                for field in campi: #cicla tra i campi 
                    if field in df.columns: #controlla se la colonna con il nome del campo esiste nel csv
                        elimina_c = field.replace(" °C", "")  # elimina la stringa " °C"
                        result = seasonal_decompose(df[field], model='additive', period=365) #applica la decomposizione 
                       #aggiunta dei nuovi campi per ogni variabile di temperatura considerata
                        df[f'{elimina_c} TREND'] = result.trend
                        df[f'{elimina_c} SEASONALITY'] = result.seasonal
                        df[f'{elimina_c} RESIDUAL'] = result.resid
                        campi_log.append(f"- Decomposizione completata per {elimina_c}") #aggiornamento del log
                        modificato = True #indica che almeno un campo è stato oggetto della decomposzione
                    else:
                        campi_log.append(f"- Campo mancante: {field}")
                        
                #in caso di decomposizione salva il file con il suffisso decomposed. Il salvataggio avviene dal 2010-01-01 in poi
                #non considerando l'anno precedente servito per decomporre.
                if modificato: 
                    
                    df = df[df.index >= '2010-01-01'] 
                    percorso_out = os.path.splitext(percorsp)[0] + "_decomposed.csv"
                    df.to_csv(percorso_out)
                    campi_log.append(f" File salvato come: {percorso_out}")
                else:
                    QMessageBox.information(self, "Nessun campo valido", "Nessuna variabile trovata per la decomposizione.")

                self.log_output.setText("\n".join(campi_log))

            except Exception as e:
                self.log_output.setText(f"Errore durante l'elaborazione: {e}")
