'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Agente Simulatore
Questo modulo racchiude la logica dell'Agente Simulatore, che fa da ponte tra le richieste dell'utente, il modello linguistico e l'algoritmo di simulazione
'''


import sys
import json, re, requests
from simulatore import genera_dati, salva_csv
from descrizioni import DESCRIZIONI_LOCALITA

# parametri di configurazione del modello
OLLAMA_API_URL = "http://localhost:11434/api/generate" #endpoint Ollama
OLLAMA_MODEL = "mistral" #nome modello
#parametri di inferenza 
OLLAMA_TEMPERATURE = 0.5 # varietà dell'output con 0.0 massimo determinismo -> stesso input stesso output
OLLAMA_TOP_P = 0.85 # selezione token più probabile, con temperature 0.0 ininfluente
OLLAMA_PENALTY = 0.9 #penalizza ripetizione parole o frasi 1.0 di default nessun penalty
OLLAMA_SEED = 42 #valore iniziale per generazione casuale
OLLAMA_NUM_PREDICT = 2000 #limite massimo di token generati



# Invio del prompt al modello che restituisce la risposta testuale.
def chiama_llm(prompt: str) -> str:
    #parametri di inferenza
    payload = {
        "model": OLLAMA_MODEL, #nome modello in uso
        "options": {
            "temperature": OLLAMA_TEMPERATURE,#risposte casuali o deterministiche
            "top_p": OLLAMA_TOP_P,#selezione solo dei token più probabili in base al valore della variabile
            "repeat_penalty": OLLAMA_PENALTY,#penalizza ripetizione parole o frasi
            "seed": OLLAMA_SEED,#valore iniziale per generazione casuale
            "num_predict": OLLAMA_NUM_PREDICT  #limite massimo ditoken generati, evita al sistema di bloccarsi in caso di loop
        },
        "prompt": prompt #prompt da inviare
    }
    try:
        risposta = ""
        #chiamata streaming ad olllama
        r = requests.post(OLLAMA_API_URL, json=payload, stream=True, timeout=120) 
        #ciclo per leggere la risposta riga per riga, ogni riga è composta da un JSON
        for linea in r.iter_lines(): 
            if linea:
                #converte da json a testo leggibile 
                data = json.loads(linea.decode("utf-8"))
                # il JSON ha come chiave response
                risposta += data.get("response", "") 
                #testo generato e "pulito"
        return risposta.strip() 
    except Exception as e:
        #errore, ad esempio se Ollama non è stato avviato 
        sys.exit(f"Errore nella chiamata LLM: {e}") 

#estrazione delle informazioni su localitè e data
def estrai_localita_e_date(testo: str): 
    testo_basso = testo.lower()
    localita = None #località non trovata
    #scorre il file descrizioni per trovare il nome della località
    for nome in DESCRIZIONI_LOCALITA: 
        if nome.lower() in testo_basso: #se lo trova esce
            localita = nome
            break

    #estrae le date tramite espressione regolare, cerca formato YYYY-MM-DD    
    date = re.findall(r"\d{4}-\d{2}-\d{2}", testo) 
    start = date[0] if len(date) > 0 else None #prima data trovata
    end = date[1] if len(date) > 1 else None #seconda data
    return localita, start, end

#costruisce il prompt tramite unione di diverse parti
def costruisci_prompt(localita: str, testo_utente: str) -> str: 
    #info sulla località da descrizioni, per ora recupero fisso e non intercettato da prompt
    info = DESCRIZIONI_LOCALITA[localita] 
    p = info["parametri_medi"]

    contesto = ( #una parte del contesto è generato usando i dati contenuti nel file descrizioni

        "************ USA QUESTE INFORMAZIONI COME CONOSCENZA DI BASE PER LE PREVISIONI **************"
        #questa parte del contesto è generato usando i dati contenuti nel file descrizioni
        f"\n\nSimula i dati per la città di {info['nome_completo']}\n"
        f"\nUsa le seguenti informazioni di contesto: \n{info['descrizione_climatica']}\n"
        f"Temperatura media annua (°C): {p['temperatura_media_annua']}\n"
        f"Ampiezza termica annua (°C): {p['ampiezza_termica_annuale']}\n"
        f"Pressione media (mb): {p['pressione_media_annua']}\n"
        f"Variazione stagionale pressione (mb): {p['variazione_stagionale_pressione']}\n"
        f"Umidità media annua (%): {p['umidita_media_annua_percento']}\n"
        f"Vento medio (km/h): {p['velocita_media_vento_kmh']}\n"
        f"Moltiplicatore raffica: {p['moltiplicatore_raffica']}\n"
        f"Visibilità (km): {p['visibilita_km']}\n"
        f"Deviazione rumore (std): {p['deviazione_rumore_range']}\n"
        f"Percentuale NaN: {p['percentuale_nan_range']}\n"
        f"Percentuale picchi: {p['percentuale_picchi_range']}\n"
        f"Intensità picchi: {p['intensita_picchi_range']}\n"
        f"Deriva temperatura (°C/anno): {p['deriva_t_annua_range']}\n"
        f"Deriva umidità relativa (%/anno): {p['deriva_rh_annua_range']}\n"
        
    )
     
    #output di esempio con valori fissi come ad esempio percentuale_nan ed altri variabili in funzione delle scelte del modello
    output = """

    ***** ISTRUZIONI PER L'OUTPUT *********

RESTITUISCI SOLO un JSON con le seguenti chiavi e valori NUMERICI.
I numeri qui sotto sono SOLO ESEMPI di formato, non valori fissi.
{
  "start": "YYYY-MM-DD",
  "end": "YYYY-MM-DD",
  "seed": 42,

  "t_media_annua": 17.0,
  "t_amp": 9.0,

  "p_media": 1015.0,
  "p_amp": 4.0,

  "t_media_annua_range": {p['temperatura_media_annua']},
  "t_amp_range": {p['ampiezza_termica_annuale']},
  "umidita_media_annua_percento": {p['umidita_media_annua_percento']},
  "velocita_media_vento_kmh": {p['velocita_media_vento_kmh']},
  "moltiplicatore_raffica": {p['moltiplicatore_raffica']},
  "visibilita_km": {p['visibilita_km']},

  "deviazione_rumore_range": {p['deviazione_rumore_range']},
  "deviazione_rumore": scegli il valore all'interno di deviazione_rumore_range,

  "percentuale_nan_range": {p['percentuale_nan_range']},
  "percentuale_nan": scegli il valore all'interno di percentuale_nan_range,

  "percentuale_picchi_range": {p['percentuale_picchi_range']},
  "percentuale_picchi": scegli il valore all'interno di percentuale_picchi_range,

  "intensita_picchi_range": {p['intensita_picchi_range']},
  "intensita_picchi": scegli il valore all'interno di intensita_picchi_range,

  "deriva_t_annua_range": {p['deriva_t_annua_range']},
  "deriva_t_annua": scegli il valore all'interno di deriva_t_annua_range,

  "deriva_rh_annua_range": {p['deriva_rh_annua_range']},
  "deriva_rh_annua": scegli il valore all'interno di deriva_rh_annua_range,
}

- DEVI variare tutti i valori dell'esempio.
- Fornire RANGE a due elementi (lista [min, max]). Niente scalari per queste quattro chiavi.
- "velocita_media_vento_kmh e umidita_media_annua_percento e moltiplicatore_raffica" DEVONO essere una lista [min, max]".
- Gli scalari (t_media_annua, t_amp, deviazione_rumore, percentuale_nan, percentuale_picchi, intensita_picchi, deriva_t_annua, deriva_rh_annua) devono cadere dentro i rispettivi range.
"""
    istruzioni = ("***** ISTRUZIONI PER LA SIMULAZIONE *********\n"
                  
        "- Interpreta la richiesta dell'utente.\n"
        "- Usa le informazioni fornite per scegliere i valori\n"
        "- Usa i range forniti per scegliere valori realistici.\n"
        "- Non scrivere testo fuori dal JSON.\n"
        "- Sostituisci gli esempi con numeri coerenti con il contesto.\n"
    )
    #vengono concatenati tutti i pezzi per creare il prompt
    return f"Sei un Agente specializzato nella simulazione di dati meteorologici.\n{testo_utente}\n\n{contesto}\n{istruzioni}\n{output}"

# ----------------- Main -----------------
def main():
    print("Agente Simulatore Meteo - scrivi una richiesta completa (invio vuoto per uscire).")
    print("\nEsempio: Simula dati meteorologici per la città di Roma dal 2010-01-01 al 2010-06-01")

    richiesta = input("\nRichiesta: ").strip()
    if not richiesta: #intercetta se l'utente ha inserito qualcosa oppure no
        print("Uscita.")
        return

    localita, d_inizio, d_fine = estrai_localita_e_date(richiesta)
    if not localita: #per ora il sistema non considera località diverse da Roma vista anche l'assenza di descrizioni di altre città
        localita = "Roma"
        print("Località non indicata nel testo → uso 'Roma' come predefinita.")

    print(f"Località: {localita}") #stampa località
    if d_inizio and d_fine:
        print(f"Intervallo: {d_inizio} → {d_fine}") #stampa date inizio e fine
    print("\nSto costruendo i valori da passare al simulatore.....")
    prompt = costruisci_prompt(localita, richiesta) #crea la variabile prompt da mandare al modello
    #print("\n--- PROMPT COMPLETO INVIATO AL MODELLO ---\n") #per debug lasciata sempre attiva
    #print(prompt)
    print("\n------------------------------------------\n")

    risposta = chiama_llm(prompt) #contiene la risposta del modello, invia al modello il prompt completo
    print("\n--- TESTO RICEVUTO DAL MODELLO ---\n")
    print(risposta)
    print("\n----------------------------------\n")
    try:
      parametri = json.loads(risposta) # provo a convertire direttamente l'output del modello
    except json.JSONDecodeError: #se non riesce perchè magari il modello non torna un formato corretto
      payload = re.search(r"\{[\s\S]*\}", risposta).group(0) # uso dei regex e cerco se il testo è compreso in { }
      payload = re.sub(r",\s*([}\]])", r"\1", payload)# uso dei regex per correggere il testo al di fuori e inserire la risposta dentro { }
      parametri = json.loads(payload) #conversione della risposta in un dizionario python


    # unisce tutti i parametri della località (range vento/visibilità/umidità/fenomeni)
   #parametri.update(DESCRIZIONI_LOCALITA[localita]["parametri_medi"]) #aggiunge al dizionario parametri i valori climatici relativi alla "localita"
    #mi assicuro che i parametri siano tutti passati al simulatore
    obbligatorie = ["start","end","seed",
    "t_media_annua_range","t_amp_range","t_media_annua","t_amp",
    "p_media","p_amp",
    "umidita_media_annua_percento","velocita_media_vento_kmh",
    "moltiplicatore_raffica","visibilita_km",
    "deviazione_rumore","percentuale_nan","percentuale_picchi","intensita_picchi","deviazione_rumore_range","deviazione_rumore",
    "percentuale_nan_range","percentuale_nan",
    "percentuale_picchi_range","percentuale_picchi",
    "intensita_picchi_range","intensita_picchi"]
    mancanti = [k for k in obbligatorie if k not in parametri]
    if mancanti:
      raise ValueError(f"Mancano chiavi nel JSON del modello: {mancanti}")


    #print("Parametri generati:")
    #print(json.dumps(parametri, indent=2, ensure_ascii=False)) # stampa i paramentri finali usciti dal modello che saranno
    #usati dal simulatore ad esempio, p_media, visibilità_media convertendoli prima in JSON usando codifica ACII con indent = 2 porto a capo i valori dando spazio

    #print("\nSto generando i dati, attendere...")
    df = genera_dati(parametri) #richiama genera dati dallo strumento simulatore(simulatore_algoritmo.py) che elabora la simulazione con i parametri passati
    percorso = salva_csv(df) #salvataggio

    print(f"\nSimulazione completata. File salvato in: {percorso}")
    print("\nAnteprima (prime 10 righe):")
    print(df.head(10).to_string(index=False)) #stampa di 10 righe di dati senza indice

    return  # termina dopo una singola simulazione, senza questo return il sistema conituna a funzionare in loop dopo ogni simulazione

if __name__ == "__main__":
    main()
