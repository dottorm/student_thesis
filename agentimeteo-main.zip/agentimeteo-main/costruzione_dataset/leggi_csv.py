'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Lettura
Questo strumento non è parte del processo di creazione del dataset, ma è utile per la lettura di file csv
'''

import os
import pandas as pd
from PySide6.QtWidgets import QMainWindow, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QFileDialog, QPushButton

#creo la finestra principale per visualizzare il csv
class visualizzatoreCSV(QMainWindow):
    #inizializzo la classe
    def __init__(self):
        super().__init__()

        #dimensioni e titolo
        self.setWindowTitle("visualizzatoreCSV CSV")
        self.setGeometry(100, 100, 900, 600)

        # Bottone per selezionare un file CSV
        self.carica_csv_btn = QPushButton("Seleziona CSV")
        self.carica_csv_btn.clicked.connect(self.carica_csv)

        # Crea il widget per la tabella dove mostrare il csv
        self.tabella = QTableWidget()

        # Layout principale
        layout = QVBoxLayout()
        layout.addWidget(self.carica_csv_btn)
        layout.addWidget(self.tabella)

        # Imposta il layout  centrale creando il widget
        container = QWidget() #widget contenitore
        container.setLayout(layout)
        self.setCentralWidget(container)

    #caricamento e stampa a video del csv
    def carica_csv(self):
        file_dialog = QFileDialog() #creazione della finistra di dialogo
        percorso_csv, _ = file_dialog.getOpenFileName(self, "Seleziona un file CSV", "", "CSV Files (*.csv)")

        if percorso_csv:
            self.setWindowTitle(f"visualizzatoreCSV CSV - {os.path.basename(percorso_csv)}") #aggiorno titolo finestra
            self.mostra_csv(percorso_csv) #mostra contentuo richiamando la funzione

    def mostra_csv(self, percorso_csv): #la funzione legge il csv e lo carica in un DataFrame con pandas
        self.df = pd.read_csv(percorso_csv)

       #ricava il numero di righe e imposta la tabella
        righe, colonne = self.df.shape
        self.tabella.setRowCount(righe)
        self.tabella.setColumnCount(colonne)
        self.tabella.setHorizontalHeaderLabels(self.df.columns) #intestazione colonne

        for row in range(righe): #popola la tabella
            for col in range(colonne):
                item = QTableWidgetItem(str(self.df.iat[row, col])) #creazione cella
                self.tabella.setItem(row, col, item)

        # Adatta le intestazioni ed il contenuto per essere allineati
        self.tabella.resizeColumnsToContents()


