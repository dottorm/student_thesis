'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Interpolazione
Tramite questo modulo è possibile dare un valore ai campi vouoti del dataset e valorizzati con NaN.
Tramite l'interpolazione lineare è possibile colmare questi vuoi con dei valori coerenti. Usa la funzione interpolate di pandas
'''

import pandas as pd
import os
from PySide6.QtWidgets import  QWidget, QVBoxLayout, QLabel,QPushButton, QFileDialog, QTextEdit, QMessageBox
from PySide6.QtCore import QDateTime


class interpolazione_lineare(QWidget): 
     #interfaccia grafica, inizializzazione,titolo, dimensioni
     
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Interpolatore CSV - Correzione NAN")
        self.setMinimumSize(700, 500)
    #creazione del layoyt etichette, pulsanti e finestra di dialogo per log, bottone per il caricamento del csv
        self.layout = QVBoxLayout()
        self.label = QLabel("Carica un file CSV per correggere i valori mancanti")
        self.carica_btn = QPushButton("Carica CSV")
        
        self.log_output = QTextEdit() #finestra dialogo
        self.log_output.setReadOnly(True)
        #aggiunta dei widget al layout
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.carica_btn)
        
        self.layout.addWidget(self.log_output)
        self.setLayout(self.layout)

        self.carica_btn.clicked.connect(self.carica_csv) #connessione al pulsante di caricamento del csv
        


    
    def carica_csv(self):  # caricamento del csv
        percorso_file, _ = QFileDialog.getOpenFileName(self, "Seleziona un file CSV", "", "CSV Files (*.csv)") #scelta del file
        if not percorso_file:
            return

        try:
            df = pd.read_csv(percorso_file)
            righe_interpolazione = []
            #elementi per il log finale
            timestamp = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
            elementi_log = [f"LOG {timestamp}"]
            elementi_log.append(f"File analizzato: {os.path.basename(percorso_file)}")

            # conversione della colonna DATE in datetime
            df["DATE"] = pd.to_datetime(df["DATE"])

            # selezione delle sole colonne numeriche
            colonne_numeriche = df.select_dtypes(include=["float64", "int64"]).columns

            # ciclo di interpolazione
            for col in colonne_numeriche:
                indici_nan = df[df[col].isna()].index.tolist() #identifico gli indici delle righe in cui ci sono Nan
                if not indici_nan:
                    continue
                
                #interpolazione con la funzione interpolate di pandas
                serie_interpolate = df[col].interpolate(method="linear", limit_direction="both")

                for idx in indici_nan: #ciclo su ogni NaN trovato per creazione log
                    new_value = serie_interpolate.iloc[idx] #nuovo valore dopo interpolazione

                    # trova la riga precedente e successiva non NaN
                    prec_idx = next( #riga precedente al NaN
                        (i for i in range(idx - 1, -1, -1) if not pd.isna(df[col].iloc[i])),
                        None,
                    )
                    succ_idx = next(#riga succesiva al NaN
                        (i for i in range(idx + 1, len(df)) if not pd.isna(df[col].iloc[i])),
                        None,
                    )
                    #valori riga precedente e successiva al NaN
                    prec_val = df[col].iloc[prec_idx] if prec_idx is not None else None
                    succ_val = df[col].iloc[succ_idx] if succ_idx is not None else None

                    if prec_idx is not None and succ_idx is not None: #calcolo peso tra i due punti noti, precedenti e successivi
                        distanza_totale = succ_idx - prec_idx
                        peso = (idx - prec_idx) / distanza_totale if distanza_totale != 0 else 0.5
                    else:
                        peso = None

                    # messaggio di log per ogni interpolazione
                    msg = (
                        f"[Colonna: {col}] Data: {df.at[idx, 'DATE'].strftime('%Y-%m-%d')} → "
                        f"NaN sostituito con {round(new_value, 2)}\n"
                        f"   Calcolato tra: "
                        f"{df.at[prec_idx, 'DATE'].strftime('%Y-%m-%d') if prec_idx is not None else 'N/A'} "
                        f"(val={prec_val}) e "
                        f"{df.at[succ_idx, 'DATE'].strftime('%Y-%m-%d') if succ_idx is not None else 'N/A'} "
                        f"(val={succ_val})\n"
                        f"   Peso temporale: {round(peso, 3) if peso is not None else 'N/A'}"
                    )
                    righe_interpolazione.append(msg)
                    elementi_log.append(msg)
               
                #sostituzione della colonna con quella interpolata
                df[col] = serie_interpolate 
                elementi_log.append(f"- Interpolati {len(indici_nan)} NaN in '{col}'") #msg di riepilogo della sostituzione

            # salvataggio del file interpolato
            percorso_output = os.path.splitext(percorso_file)[0] + "_interpolato.csv"
            if righe_interpolazione:
                df.to_csv(percorso_output, index=False)
                elementi_log.append(f"- File CSV corretto salvato come: {percorso_output}")
             #creazione di un file con i dettagli sull'interpolazione
                log_percorso_file = os.path.splitext(percorso_file)[0] + "_log_interpolazioni.txt"
                with open(log_percorso_file, "w", encoding="utf-8") as f:
                    f.write("\n".join(righe_interpolazione))
                elementi_log.append(f"- Log dettagliato salvato in: {log_percorso_file}")
            else: #messaggi nel caso in cui non ci siano valori da interpolare
                elementi_log.append("- Nessun valore NaN da interpolare: nessun log creato.")
                QMessageBox.information(
                    self, "Nessuna Interpolazione", "Non sono stati trovati valori NaN da interpolare."
                )

            self.log_output.setText("\n".join(elementi_log)) #vista del log delle interpolazioni nella finestra di dialogo

        except Exception as e:
            self.log_output.setText(f"Errore durante l'elaborazione: {e}")