'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo Simula Indice Nao
Questo modulo contiene la logica usata per simulare l'indice NAO
'''

import os
import numpy as np
import pandas as pd
from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QFileDialog, QLabel, QTextEdit, QMessageBox

# costruzione interfaccia, inizializzazione, titolo, dimensioni
class indice_NAO(QWidget):  
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Aggiungi NAO_INDEX")
        self.setMinimumSize(700, 500)  

        self.dataset = None
        self.percorso_dataset = None

        #costruzione del layout, etichette attribuzione pulsanti
        self.layout = QVBoxLayout()

        self.label = QLabel("Carica un file CSV per aggiungere NAO_INDEX ")
        self.layout.addWidget(self.label)

        self.carica_btn = QPushButton("Carica CSV")
        self.layout.addWidget(self.carica_btn)

        self.nao_btn = QPushButton("Calcola e aggiungi NAO_INDEX ")
        self.layout.addWidget(self.nao_btn)

        self.log_output = QTextEdit() #finestra di log
        self.log_output.setReadOnly(True)
        self.layout.addWidget(self.log_output)

        self.setLayout(self.layout)

        #pulsanti per il carimento e l'applicazione del NAO richiamano le rispettive funzioni
        self.carica_btn.clicked.connect(self.carica_csv)
        self.nao_btn.clicked.connect(self.applica_nao)

    #caricamento del cvs con funzioni di controllo su percorso e formattazione data
    def carica_csv(self): 
        percorso_file, _ = QFileDialog.getOpenFileName(self, "Seleziona un file CSV", "", "CSV Files (*.csv)"  )
        if not percorso_file:
            return

        try:#prova ad aprire il csv con il percorso indicato
            df = pd.read_csv(percorso_file, dtype=str, keep_default_na=False)

            #trasformo la data in oggetto datetime
            df["DATE"] = pd.to_datetime(df["DATE"])

            #ordinamento per data
            ord_idx = df["DATE"].sort_values().index
            df = df.loc[ord_idx].reset_index(drop=True) #riordina il dataset

            self.dataset = df #salva dataset
            self.percorso_dataset = percorso_file #salva percorso dataset
            self.log_output.setText(f"Dataset caricato (solo lettura): {percorso_file}")

        except Exception as e: # se si verifica qualche errore azzera il DataFrame
            self.dataset = None
            self.percorso_dataset = None
            self.log_output.setText(f"Errore caricamento CSV: {e}")
   
    #SIMULATORE NAO, tiene conto della pressione e del vento, letti dal dataset simulato in modo da provare
    #a generare valori NAO coerenti

     # la funzione calcola lo z-score mensile, cioè quanto ogni valore si discosta dalla media del proprio mese.
     #parametri: serie_num ovvero una colonna numerica del DataFrame (es. pressione, vento)
     #mesi ovvero una Serie contenente il numero del mese, serie_num ovvero i valori giornalieri.
     # Restituisce una nuova Serie con gli z-score corrispondenti, usando le funzioni pandas. 
     # lo zeta score consente di portare tutte le variabili con scale diverse su una scala comune ovvero deviazioni standard  
     #zeta score è la variabiel standardizzata z della distribuzione normale z=x-media_mese/deviazione_mese dove x=valore giornaliero di pressione o vento
    def zscore_mensile(self, serie_num: pd.Series, mesi: pd.Series) -> pd.Series: 
        # calcola la media del mese per ogni valore della serie
        media_mese = serie_num.groupby(mesi).transform("mean") 
        # stesso principio di media_mese ma per la deviazione standard mensile, con replace per evitare errori di divisione per 0, viene sostituito 0 con NaN
        std_mese = serie_num.groupby(mesi).transform("std").replace(0, np.nan) 
        z = (serie_num - media_mese) / std_mese #calcolo zeta score
        return z.fillna(0.0) #ritorna lo zeta score sostituendo i NaN con 0.0

    #funzione di simulazione
    def simula_nao(self, df_str: pd.DataFrame) -> pd.Series:
        
        mesi = pd.to_datetime(df_str["DATE"], errors="coerce").dt.month #converto in oggetto datetime i mesi estratti dal dataset. Ottengo il numero del mese

        componenti = [] #zscore dei componenti
        pesi = [] #pesi associati ai componenti
 
      #se il campo pressione è presente converte da stinga a numerico
        if "PRESSURE mb" in df_str.columns:
            p_num = pd.to_numeric(df_str["PRESSURE mb"], errors="coerce") #coerce = durante la conversione se trova valori non convertibili li salva come NaN
            z_p = self.zscore_mensile(p_num, mesi) #calcolo della zscore per il mese
            componenti.append(z_p);#aggiunge lo zetascore mensile
            pesi.append(0.6) #aggiunge un peso scelto da me in varie prove, e indica quanto incida la pressione sul calcolo complessivo
       
        #come sopra ma per il vento medio
        if "WINDAVG km/h" in df_str.columns: 
            #converto in numerico
            v_num = pd.to_numeric(df_str["WINDAVG km/h"], errors="coerce")
            #calcolo zeta_score
            z_v = self.zscore_mensile(v_num, mesi)
            #attribuisco un peso
            componenti.append(z_v); pesi.append(0.8)

        # se i componenti non sono presenti solleva errore
        if not componenti:
            raise ValueError("Servono le colonne 'PRESSURE mb' e/o 'WINDAVG km/h' per simulare la NAO.") 
        #converte la lista dei pesi in un array Numpy di float
        pesi = np.array(pesi, dtype=float) 
        
        nao = 0

        #formula nao= somma dei prodotti tra ciascuna variabile normalizzata e il proprio peso,divisa per la somma totale dei pesi
        #per ogni ciclo, prende la componente pressione e la moltiplica per il peso, poi prende la componente vento e la moltiplica per il peso
        #fa la somma dei precedenti valori. esempio zip(componenti,pesi), questo è un componente iterabile contenenti tutte le coppie del dataset:
        #esempio di una riga [(z_p, 0.6),(z_v, 0.8)] ogni giro prende una coppia fa il prodotto e poi somma

        for c, p in zip(componenti, pesi): #zip permette di associare ogni serie al proprio peso esempio lo zscore del vento con il peso del vento
          nao += c * p # c e p sono i valori in coppia uno è una Serie pandas e l'altro è il valore del peso

        #normalizzazzo dividendo per la somma totale dei pesi, in questo modo evito che i valori siano troppo grandi
        #rendo la media corretta avendo sommato varibili con pesi diversi
        nao = nao / pesi.sum() 
        
        #rendo la scala uniforme così avrò valori nè troppo grandi nè troppo piccoli
        std = nao.std(ddof=0) #deviazione standard della serie nao con pandas, ddof=0 non campionaria, stimo su tutta la popolazione, ritorna un float
        if std and std > 0: #controllo per evitare divisione per 0
            nao = nao / std

        nao_str = nao.astype(float).map(lambda x: f"{x:.3f}") #mi assicuro che sia un float con tre cifre decimali.
        return nao_str.rename("NAO_INDEX") #rinomino con il nome che ho scelto per la colonna

    #funzione per aggiungere la colonna NAO_INDEX
    def applica_nao(self): 
        if self.dataset is None:
            QMessageBox.warning(self, "Attenzione", "Nessun dataset caricato.")
            return

        try:
            df_str = self.dataset.copy() #creo copia dataset originale
            nao_col = self.simula_nao(df_str) #valori nao simulati da inserire nella colonna

            df_str["NAO_INDEX"] = nao_col #effettiva aggiunta dei valori

           #salvataggio del file con suffisso _NAO non include gli indici di riga inseriti da Pandas "index=False"
            nome_file = os.path.basename(self.percorso_dataset)
            base, _ = os.path.splitext(nome_file)
            nome_finale = f"{base}_NAO.csv"
            df_str.to_csv(nome_finale, index=False)
         
          #costruzione del log
            date_dt = pd.to_datetime(self.dataset["DATE"], errors="coerce")
            min_s = (date_dt.min()).strftime("%Y-%m-%d")
            max_s = (date_dt.max()).strftime("%Y-%m-%d")

            log_msg = [
                "NAO_INDEX calcolato ",
                f"Intervallo: {min_s} → {max_s}",
                f"File salvato come: {nome_finale}",
            ]
            self.log_output.setText("\n".join(log_msg))

        except Exception as e:
            self.log_output.setText(f"Errore nell'aggiunta di NAO_INDEX: {e}")
