
'''
Aita Ignazio - matricola: 3060HHHINGINFO
Università Telematica Internazionale Uninettuno.
Facoltà di Ingegneria
Corso di Laurea in Ingegneria Informatica.
Tesi di Laurea : Predizione di variabili meteorologiche tramite l'utilizzo di LLM e dati storici.
Anno accademico 2025/2026
'''


'''
Sezione Costruzione dataset
Modulo principale
Questo è il modulo di accesso allo strumento di creazione. Racchiude tutti i bottoni per raggiungere le singole funzioni.
Mostra tutto tramite un'interfaccia grafica minimale
'''


import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QStackedWidget, QVBoxLayout, QWidget, QGridLayout
from leggi_csv import visualizzatoreCSV
from pulisci_csv import editaColonneCSV
from decomposizione_stagionale import decomposizione
from indice_nao import indice_NAO
from interpolazione_nan import interpolazione_lineare


#La funzione viene chiamata quando si clicca sul bottone "1-Agente Simulatore" 
#ed apre una finestra di terminale di windows dalla quale è possibile usare il simulatore
def apri_simulatore():
    import subprocess, sys, os

    script_path = os.path.join(os.path.dirname(__file__), "agente_simulatore.py") #percorso e verifica esistenza file agente simulatore
    if not os.path.exists(script_path):
        print(f"[ERRORE] File non trovato: {script_path}")
        return

    subprocess.Popen( #avvia il nuovo processo nel terminale windows(cmd) e con k impongo di lasciare la finestra aperta
        ["cmd", "/k", f"{sys.executable} {script_path}"],
        creationflags=subprocess.CREATE_NEW_CONSOLE #apre il terminale
    )




# creazione della finestra iniziale per la creazione e manipolazione del dataset

class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Home Dataset") #titolo pagina
        self.setGeometry(100, 100, 800, 600) #dimensioni iniziali
        
        #crazione del widget centrale e schermata home
        self.widget_centrale = QStackedWidget()
        self.setCentralWidget(self.widget_centrale)

        self.schermata_home = self.crea_home()
        self.widget_centrale.addWidget(self.schermata_home)

        self.moduli = { #moduli dell'applicazione collegate ai file
            "leggi": self.wrap_in_widget(visualizzatoreCSV()), #leggi csv
            "filtra": self.wrap_in_widget(editaColonneCSV()),   #filtra colonne
             "nao": self.wrap_in_widget(indice_NAO()),   #indice Nao simulato
            "nanfix": self.wrap_in_widget(interpolazione_lineare()), #interpolazione lineare
            "seasonal": self.wrap_in_widget(decomposizione()), #decomposizione stagionale
            # il richiamo all'agente simulatore è direttamente sul pulsante
            
            
            
        }
        
        for module in self.moduli.values(): #ciclo all'interno dei moduli (leggi, nai, etc..)
            self.add_navigation(module) #cre il pulsante torna alla home nelle singole schermate
            self.widget_centrale.addWidget(module) #contenitore per le schermate dell'app richiamato dai bottoni e legato a self.moduli

    def crea_home(self): #creazione della schermata home con widget(finestra principale) e schermata a griglia
        home_widget = QWidget()
        layout = QGridLayout()

        # creazione dei bottoni per la selezione dei moduli
        
        btn_leggi = QPushButton("Leggi Dataset") #creazione del pulsante con etichetta, in questo caso, "Leggi Dataset"
        btn_leggi.setFixedSize(120, 120) #dimensione in pixel per il pulsante
        # quando si clicca sul pulsante, viene richiamato il widget centrale e dentro è caricato il modulo corrispondente al pulsante
        btn_leggi.clicked.connect(lambda: self.widget_centrale.setCurrentWidget(self.moduli["leggi"])) 
        
        layout.addWidget(btn_leggi, 0, 0) #aggiunte questo pulsante alla griglia di pulsanti che appare appena caricato il main

        #stesse funzioni per gli altri bottoni

        btn_simulatore = QPushButton("1-Agente Simulatore")
        btn_simulatore.setFixedSize(120, 120)
        #questo bottone si collega direttamente alla funzione apri_simulaotre e non fa parte di self.moduli
        btn_simulatore.clicked.connect(apri_simulatore) 
        layout.addWidget(btn_simulatore, 0, 1)




        btn_nan = QPushButton("2-Interpolazione")
        btn_nan.setFixedSize(120, 120)
        btn_nan.clicked.connect(lambda: self.widget_centrale.setCurrentWidget(self.moduli["nanfix"]))
        layout.addWidget(btn_nan, 1, 0)

        btn_seasonal = QPushButton("3-Decomposizione")
        btn_seasonal.setFixedSize(120, 120)
        btn_seasonal.clicked.connect(lambda: self.widget_centrale.setCurrentWidget(self.moduli["seasonal"]))
        layout.addWidget(btn_seasonal, 1, 1)

        btn_nao = QPushButton("4-Simula NAO")
        btn_nao.setFixedSize(120, 120)
        btn_nao.clicked.connect(lambda: self.widget_centrale.setCurrentWidget(self.moduli["nao"]))
        layout.addWidget(btn_nao, 2, 0)

        btn_filtra = QPushButton("5-Filtra colonne")
        btn_filtra.setFixedSize(120, 120)
        btn_filtra.clicked.connect(lambda: self.widget_centrale.setCurrentWidget(self.moduli["filtra"]))
        layout.addWidget(btn_filtra, 2, 1)

       
        home_widget.setLayout(layout) #applica alla home il layout a griglia per i pulsanti
        return home_widget

    def wrap_in_widget(self, module): #La funzione serve per inserire un modulo dentro un widget con un layout specifico
        container = QWidget() #widget contenitore principale
        layout = QVBoxLayout() #layout verticale per inserire gli elementi incolonnti
        layout.addWidget(module) # aggiunta del modulo al layout
        container.setLayout(layout) #applica il layout al contenitore
        return container

    def add_navigation(self, module): #aggiunta del pulsante torna alla home richiamato nei singoli moduli
        back_button = QPushButton("Torna alla Home")
        back_button.clicked.connect(lambda: self.widget_centrale.setCurrentWidget(self.schermata_home))
        layout = module.layout() #recupero layout
        layout.addWidget(back_button) #aggiunta effettiva del pulsante 

if __name__ == "__main__":
    #creazione dell'istanza principale e creazione/chiusura finestra principale
    app = QApplication(sys.argv) #istanza in PySide
    window = MainApp()
    window.show()
    sys.exit(app.exec())
