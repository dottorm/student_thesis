AITA IGNAZIO MATRICOLA 3060HHHINGINFO

TESI DI LAUREA TRIENNALE - CORSO DI INGEGNERIA INFORMATICA ANNO ACCADEMICO 2025/2026

PREVISIONI DI VARIABILI METEOROLOGICHE BASATE SULL'USO DI LLM E DATI STORICI.


---------------------------------------------------------------------------------------

Questo documento illustra il contenuto della directory contenente gli allegati digitali alla tesi
Talvolta, nei documenti allegati, i valori simulati potrebbero anche essere chiamati, reali, osservati o rilevati, intendendo sempre simulati
nel contesto di questo elaborato


1) DIRECTORY AGENTI_METEO

Questa directory raccoglie tutti i file contenenti il codice sorgente scritto in Python, il dataset e gli elementi che costituiscono il progetto principale grazie al quale è
possibile effettuare le previsioni.



2) DIRECTORY COSTRUIZIONE_DATASET

In questa directory sono presenti i file che costituiscono l'applicazione di supporto al progetto principale. 
Questa applicazione è utilizzata per costruire il dataset storico a partire dal simulatore delle serie temporali.



3) REPORT_CONFRONTI

All'interno di questa directory sono contenuti i report in formato pdf di ogni confronto tra temperature previste e osservate. I file rappresentano il supporto dettagliato per ogni singolo test di affidabilità discusso nell'elaborato principale, in quanto contengono al loro interno, i risultati dei confronti tra previsioni e dati simulati, gli indicatori di affidabilità, il grafico, e i giorni di contesto usati per la previsione. Ogni documento è rinominato nel seguente modo:
Report_confronto_<data_inizio_previsione>.pdf



4) DOCUMENTAZIONE_AGENTI_METEO

Questo documento descrive la struttura del progetto agenti meteo, ne espone le librerie utilizzate, la struttura del progetto, il flusso di esecuzione dell'applicazione
Contiene inoltre, la descrizione dei singoli moduli suddivisi in più file e le istruzioni per l'utilizzo.



5) DOCUMENTAZIONE_COSTRUZIONE_DATASET

Esattamente come per il precedente punto, questo documento descrive l'applicazione per la costruzione del dataset, le librerie che sono state usate, la struttura del progetto,
il flusso di lavoro per arrivare alla creazione del dataset, la descrizione dei singoli file che compongono il progetto, le istruzioni per l'utilizzo.



6) DESCRIZIONI_DATASET

In questo documento sono descritti i dataset e le altre fonti di dati utilizzati nel progetto. Vengono elencati e descritti i campi dei dataset necessari per il funzionamento del sistema.



7) PROMPT_AGENTI

Sono riportati esempi completi di prompt utilizzati dagli agenti. Come spiegato all'interno del documento, essendo il prompt costituito da una parte statica e da parti dinamiche
generate in run time, non è possibile descrivere tutti i possibili prompt, quindi quelli riportati ne rappresentano un esempio significativo.


8) DIRECTORY IMMAGINI ALLEGATE 

La directory contiene tutte le immagini utilizzate nell'elaborato principale e negli allegati, il tutto è suddiviso all'interno di cartelle rinominate in base al documento di riferimento


9) DIRECTORY DATASET_STORICO

In questa directory è contenuta una copia del dataset simulato, salvato nel file dataset_storico.csv.
Un duplicato dello stesso è presente anche nella directory dedicata del progetto Agenti Meteo.


